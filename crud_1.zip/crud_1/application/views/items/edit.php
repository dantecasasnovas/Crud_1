<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Editar | CRUD</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container mt-5">
        <h2>Actualice sus Datos</h2>
        <form action="<?php echo site_url('items/update/'.$item['id']); ?>" method="post">
            <div class="row">
            <div class="col-md-4 form-group">
                <label for="name">Nombre:</label>
                <input type="text" class="form-control" name="name" id="name" value="<?php echo $item['name']; ?>">
            </div>
            <div class="col-md-4 form-group">
                <label for="apellido">Apellido:</label>
                <input type="text" class="form-control" name="apellido" id="apellido" value="<?php echo $item['apellido']; ?>">
            </div>
            <div class="col-md-4 form-group">
                <label for="cedula">Cédula:</label>
                <input type="text" class="form-control" name="cedula" id="cedula" value="<?php echo $item['cedula']; ?>">
            </div>
            </div>
            <div class="form-group">
                <label for="direccion">Descripción:</label>
                <textarea class="form-control" id="direccion" name="direccion"><?php echo $item['direccion']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>

    <div class="container mt-5">
        <!-- <a href="<?php echo site_url('items/create'); ?>" class="btn btn-primary">Crear Ítem</a> -->
        <table class="table table-striped table-bordered table-hover mb-5" cellspacing="0" style="overflow: scroll; max-height: 50px; overflow-y: auto;">
            <thead>
                <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">Nombre</th>
                    <th class="text-center">Apellido</th>
                    <th class="text-center">Cédula</th>
                    <th class="text-center">Dirección</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($items)): ?>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?php echo $item['id']; ?></td>
                            <td><?php echo $item['name']; ?></td>
                            <td><?php echo $item['apellido']; ?></td>
                            <td><?php echo $item['cedula']; ?></td>
                            <td><?php echo $item['direccion']; ?></td>
                            <td>
                                <a href="<?php echo site_url('items/edit/'.$item['id']); ?>" class="btn btn-warning"><i class="fa fa-edit" aria-hidden="true" style="font-size: 20px "></i>Editar</a>
                                <a href="<?php echo site_url('items/delete/'.$item['id']); ?>" class="btn btn-danger">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No se encontraron ítems.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">Nombre</th>
                    <th class="text-center">Apellido</th>
                    <th class="text-center">Cédula</th>
                    <th class="text-center">Dirección</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </tfoot>
        </table>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>