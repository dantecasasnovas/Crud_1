<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-04 03:23:04 --> Config Class Initialized
INFO - 2024-11-04 03:23:04 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:04 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:04 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:04 --> URI Class Initialized
INFO - 2024-11-04 03:23:04 --> Router Class Initialized
INFO - 2024-11-04 03:23:04 --> Output Class Initialized
INFO - 2024-11-04 03:23:04 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:04 --> Input Class Initialized
INFO - 2024-11-04 03:23:04 --> Language Class Initialized
INFO - 2024-11-04 03:23:04 --> Loader Class Initialized
INFO - 2024-11-04 03:23:04 --> Helper loaded: url_helper
INFO - 2024-11-04 03:23:04 --> Database Driver Class Initialized
INFO - 2024-11-04 03:23:04 --> Controller Class Initialized
INFO - 2024-11-04 03:23:04 --> Model "Item_model" initialized
INFO - 2024-11-04 03:23:04 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:23:04 --> Final output sent to browser
DEBUG - 2024-11-04 03:23:04 --> Total execution time: 0.2431
INFO - 2024-11-04 03:23:04 --> Config Class Initialized
INFO - 2024-11-04 03:23:04 --> Hooks Class Initialized
INFO - 2024-11-04 03:23:04 --> Config Class Initialized
DEBUG - 2024-11-04 03:23:04 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:04 --> Hooks Class Initialized
INFO - 2024-11-04 03:23:04 --> Utf8 Class Initialized
DEBUG - 2024-11-04 03:23:04 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:04 --> URI Class Initialized
INFO - 2024-11-04 03:23:04 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:04 --> Router Class Initialized
INFO - 2024-11-04 03:23:04 --> URI Class Initialized
INFO - 2024-11-04 03:23:04 --> Output Class Initialized
INFO - 2024-11-04 03:23:04 --> Router Class Initialized
INFO - 2024-11-04 03:23:04 --> Security Class Initialized
INFO - 2024-11-04 03:23:04 --> Output Class Initialized
DEBUG - 2024-11-04 03:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:04 --> Security Class Initialized
INFO - 2024-11-04 03:23:04 --> Input Class Initialized
DEBUG - 2024-11-04 03:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:04 --> Language Class Initialized
INFO - 2024-11-04 03:23:04 --> Input Class Initialized
ERROR - 2024-11-04 03:23:04 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-04 03:23:04 --> Language Class Initialized
ERROR - 2024-11-04 03:23:04 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:23:06 --> Config Class Initialized
INFO - 2024-11-04 03:23:06 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:06 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:06 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:06 --> URI Class Initialized
INFO - 2024-11-04 03:23:06 --> Router Class Initialized
INFO - 2024-11-04 03:23:06 --> Output Class Initialized
INFO - 2024-11-04 03:23:06 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:06 --> Input Class Initialized
INFO - 2024-11-04 03:23:06 --> Language Class Initialized
INFO - 2024-11-04 03:23:06 --> Loader Class Initialized
INFO - 2024-11-04 03:23:06 --> Helper loaded: url_helper
INFO - 2024-11-04 03:23:06 --> Database Driver Class Initialized
INFO - 2024-11-04 03:23:06 --> Controller Class Initialized
INFO - 2024-11-04 03:23:06 --> Model "Item_model" initialized
INFO - 2024-11-04 03:23:06 --> File loaded: C:\wamp64\www\crud_1\application\views\items/create.php
INFO - 2024-11-04 03:23:06 --> Final output sent to browser
DEBUG - 2024-11-04 03:23:06 --> Total execution time: 0.2306
INFO - 2024-11-04 03:23:07 --> Config Class Initialized
INFO - 2024-11-04 03:23:07 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:07 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:07 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:07 --> URI Class Initialized
INFO - 2024-11-04 03:23:07 --> Router Class Initialized
INFO - 2024-11-04 03:23:07 --> Output Class Initialized
INFO - 2024-11-04 03:23:07 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:07 --> Input Class Initialized
INFO - 2024-11-04 03:23:07 --> Language Class Initialized
ERROR - 2024-11-04 03:23:07 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-04 03:23:16 --> Config Class Initialized
INFO - 2024-11-04 03:23:16 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:16 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:16 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:16 --> URI Class Initialized
INFO - 2024-11-04 03:23:16 --> Router Class Initialized
INFO - 2024-11-04 03:23:16 --> Output Class Initialized
INFO - 2024-11-04 03:23:16 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:16 --> Input Class Initialized
INFO - 2024-11-04 03:23:16 --> Language Class Initialized
INFO - 2024-11-04 03:23:16 --> Loader Class Initialized
INFO - 2024-11-04 03:23:16 --> Helper loaded: url_helper
INFO - 2024-11-04 03:23:16 --> Database Driver Class Initialized
INFO - 2024-11-04 03:23:16 --> Controller Class Initialized
INFO - 2024-11-04 03:23:16 --> Model "Item_model" initialized
INFO - 2024-11-04 03:23:16 --> Config Class Initialized
INFO - 2024-11-04 03:23:16 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:16 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:16 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:16 --> URI Class Initialized
INFO - 2024-11-04 03:23:16 --> Router Class Initialized
INFO - 2024-11-04 03:23:16 --> Output Class Initialized
INFO - 2024-11-04 03:23:16 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:16 --> Input Class Initialized
INFO - 2024-11-04 03:23:16 --> Language Class Initialized
INFO - 2024-11-04 03:23:16 --> Loader Class Initialized
INFO - 2024-11-04 03:23:16 --> Helper loaded: url_helper
INFO - 2024-11-04 03:23:16 --> Database Driver Class Initialized
INFO - 2024-11-04 03:23:16 --> Controller Class Initialized
INFO - 2024-11-04 03:23:16 --> Model "Item_model" initialized
INFO - 2024-11-04 03:23:16 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:23:16 --> Final output sent to browser
DEBUG - 2024-11-04 03:23:16 --> Total execution time: 0.2194
INFO - 2024-11-04 03:23:17 --> Config Class Initialized
INFO - 2024-11-04 03:23:17 --> Config Class Initialized
INFO - 2024-11-04 03:23:17 --> Hooks Class Initialized
INFO - 2024-11-04 03:23:17 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:17 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:23:17 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:17 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:17 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:17 --> URI Class Initialized
INFO - 2024-11-04 03:23:17 --> URI Class Initialized
INFO - 2024-11-04 03:23:17 --> Router Class Initialized
INFO - 2024-11-04 03:23:17 --> Router Class Initialized
INFO - 2024-11-04 03:23:17 --> Output Class Initialized
INFO - 2024-11-04 03:23:17 --> Output Class Initialized
INFO - 2024-11-04 03:23:17 --> Security Class Initialized
INFO - 2024-11-04 03:23:17 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:17 --> Input Class Initialized
INFO - 2024-11-04 03:23:17 --> Input Class Initialized
INFO - 2024-11-04 03:23:17 --> Language Class Initialized
INFO - 2024-11-04 03:23:17 --> Language Class Initialized
ERROR - 2024-11-04 03:23:17 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:23:17 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:23:19 --> Config Class Initialized
INFO - 2024-11-04 03:23:19 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:19 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:19 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:19 --> URI Class Initialized
INFO - 2024-11-04 03:23:19 --> Router Class Initialized
INFO - 2024-11-04 03:23:19 --> Output Class Initialized
INFO - 2024-11-04 03:23:19 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:19 --> Input Class Initialized
INFO - 2024-11-04 03:23:19 --> Language Class Initialized
INFO - 2024-11-04 03:23:19 --> Loader Class Initialized
INFO - 2024-11-04 03:23:19 --> Helper loaded: url_helper
INFO - 2024-11-04 03:23:19 --> Database Driver Class Initialized
INFO - 2024-11-04 03:23:20 --> Controller Class Initialized
INFO - 2024-11-04 03:23:20 --> Model "Item_model" initialized
INFO - 2024-11-04 03:23:20 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 03:23:20 --> Final output sent to browser
DEBUG - 2024-11-04 03:23:20 --> Total execution time: 0.2091
INFO - 2024-11-04 03:23:20 --> Config Class Initialized
INFO - 2024-11-04 03:23:20 --> Config Class Initialized
INFO - 2024-11-04 03:23:20 --> Hooks Class Initialized
INFO - 2024-11-04 03:23:20 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:23:20 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:20 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:20 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:20 --> URI Class Initialized
INFO - 2024-11-04 03:23:20 --> URI Class Initialized
INFO - 2024-11-04 03:23:20 --> Router Class Initialized
INFO - 2024-11-04 03:23:20 --> Router Class Initialized
INFO - 2024-11-04 03:23:20 --> Output Class Initialized
INFO - 2024-11-04 03:23:20 --> Output Class Initialized
INFO - 2024-11-04 03:23:20 --> Security Class Initialized
INFO - 2024-11-04 03:23:20 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:20 --> Input Class Initialized
INFO - 2024-11-04 03:23:20 --> Input Class Initialized
INFO - 2024-11-04 03:23:20 --> Language Class Initialized
INFO - 2024-11-04 03:23:20 --> Language Class Initialized
ERROR - 2024-11-04 03:23:20 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:23:20 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:23:24 --> Config Class Initialized
INFO - 2024-11-04 03:23:24 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:24 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:24 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:24 --> URI Class Initialized
INFO - 2024-11-04 03:23:24 --> Router Class Initialized
INFO - 2024-11-04 03:23:24 --> Output Class Initialized
INFO - 2024-11-04 03:23:24 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:24 --> Input Class Initialized
INFO - 2024-11-04 03:23:24 --> Language Class Initialized
INFO - 2024-11-04 03:23:24 --> Loader Class Initialized
INFO - 2024-11-04 03:23:24 --> Helper loaded: url_helper
INFO - 2024-11-04 03:23:24 --> Database Driver Class Initialized
INFO - 2024-11-04 03:23:24 --> Controller Class Initialized
INFO - 2024-11-04 03:23:24 --> Model "Item_model" initialized
INFO - 2024-11-04 03:23:24 --> Config Class Initialized
INFO - 2024-11-04 03:23:24 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:24 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:24 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:24 --> URI Class Initialized
INFO - 2024-11-04 03:23:24 --> Router Class Initialized
INFO - 2024-11-04 03:23:24 --> Output Class Initialized
INFO - 2024-11-04 03:23:24 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:24 --> Input Class Initialized
INFO - 2024-11-04 03:23:24 --> Language Class Initialized
INFO - 2024-11-04 03:23:24 --> Loader Class Initialized
INFO - 2024-11-04 03:23:24 --> Helper loaded: url_helper
INFO - 2024-11-04 03:23:24 --> Database Driver Class Initialized
INFO - 2024-11-04 03:23:24 --> Controller Class Initialized
INFO - 2024-11-04 03:23:25 --> Model "Item_model" initialized
INFO - 2024-11-04 03:23:25 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:23:25 --> Final output sent to browser
DEBUG - 2024-11-04 03:23:25 --> Total execution time: 0.1979
INFO - 2024-11-04 03:23:25 --> Config Class Initialized
INFO - 2024-11-04 03:23:25 --> Config Class Initialized
INFO - 2024-11-04 03:23:25 --> Hooks Class Initialized
INFO - 2024-11-04 03:23:25 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:23:25 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:23:25 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:23:25 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:25 --> Utf8 Class Initialized
INFO - 2024-11-04 03:23:25 --> URI Class Initialized
INFO - 2024-11-04 03:23:25 --> URI Class Initialized
INFO - 2024-11-04 03:23:25 --> Router Class Initialized
INFO - 2024-11-04 03:23:25 --> Router Class Initialized
INFO - 2024-11-04 03:23:25 --> Output Class Initialized
INFO - 2024-11-04 03:23:25 --> Output Class Initialized
INFO - 2024-11-04 03:23:25 --> Security Class Initialized
INFO - 2024-11-04 03:23:25 --> Security Class Initialized
DEBUG - 2024-11-04 03:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:23:25 --> Input Class Initialized
INFO - 2024-11-04 03:23:25 --> Input Class Initialized
INFO - 2024-11-04 03:23:25 --> Language Class Initialized
INFO - 2024-11-04 03:23:25 --> Language Class Initialized
ERROR - 2024-11-04 03:23:25 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:23:25 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:29:19 --> Config Class Initialized
INFO - 2024-11-04 03:29:19 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:29:19 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:29:19 --> Utf8 Class Initialized
INFO - 2024-11-04 03:29:19 --> URI Class Initialized
INFO - 2024-11-04 03:29:19 --> Router Class Initialized
INFO - 2024-11-04 03:29:19 --> Output Class Initialized
INFO - 2024-11-04 03:29:19 --> Security Class Initialized
DEBUG - 2024-11-04 03:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:29:19 --> Input Class Initialized
INFO - 2024-11-04 03:29:20 --> Language Class Initialized
INFO - 2024-11-04 03:29:20 --> Loader Class Initialized
INFO - 2024-11-04 03:29:20 --> Helper loaded: url_helper
INFO - 2024-11-04 03:29:20 --> Database Driver Class Initialized
INFO - 2024-11-04 03:29:20 --> Controller Class Initialized
INFO - 2024-11-04 03:29:20 --> Model "Item_model" initialized
INFO - 2024-11-04 03:29:20 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:29:20 --> Final output sent to browser
DEBUG - 2024-11-04 03:29:20 --> Total execution time: 0.1881
INFO - 2024-11-04 03:29:20 --> Config Class Initialized
INFO - 2024-11-04 03:29:20 --> Config Class Initialized
INFO - 2024-11-04 03:29:20 --> Hooks Class Initialized
INFO - 2024-11-04 03:29:20 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:29:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:29:20 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:29:20 --> Utf8 Class Initialized
INFO - 2024-11-04 03:29:20 --> Utf8 Class Initialized
INFO - 2024-11-04 03:29:20 --> URI Class Initialized
INFO - 2024-11-04 03:29:20 --> URI Class Initialized
INFO - 2024-11-04 03:29:20 --> Router Class Initialized
INFO - 2024-11-04 03:29:20 --> Router Class Initialized
INFO - 2024-11-04 03:29:20 --> Output Class Initialized
INFO - 2024-11-04 03:29:20 --> Output Class Initialized
INFO - 2024-11-04 03:29:20 --> Security Class Initialized
INFO - 2024-11-04 03:29:20 --> Security Class Initialized
DEBUG - 2024-11-04 03:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:29:20 --> Input Class Initialized
INFO - 2024-11-04 03:29:20 --> Input Class Initialized
INFO - 2024-11-04 03:29:20 --> Language Class Initialized
INFO - 2024-11-04 03:29:20 --> Language Class Initialized
ERROR - 2024-11-04 03:29:20 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:29:20 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:31:23 --> Config Class Initialized
INFO - 2024-11-04 03:31:23 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:31:23 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:31:23 --> Utf8 Class Initialized
INFO - 2024-11-04 03:31:23 --> URI Class Initialized
INFO - 2024-11-04 03:31:23 --> Router Class Initialized
INFO - 2024-11-04 03:31:23 --> Output Class Initialized
INFO - 2024-11-04 03:31:23 --> Security Class Initialized
DEBUG - 2024-11-04 03:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:31:23 --> Input Class Initialized
INFO - 2024-11-04 03:31:23 --> Language Class Initialized
INFO - 2024-11-04 03:31:23 --> Loader Class Initialized
INFO - 2024-11-04 03:31:23 --> Helper loaded: url_helper
INFO - 2024-11-04 03:31:23 --> Database Driver Class Initialized
INFO - 2024-11-04 03:31:23 --> Controller Class Initialized
INFO - 2024-11-04 03:31:23 --> Model "Item_model" initialized
INFO - 2024-11-04 03:31:23 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:31:23 --> Final output sent to browser
DEBUG - 2024-11-04 03:31:23 --> Total execution time: 0.2263
INFO - 2024-11-04 03:31:23 --> Config Class Initialized
INFO - 2024-11-04 03:31:23 --> Config Class Initialized
INFO - 2024-11-04 03:31:23 --> Hooks Class Initialized
INFO - 2024-11-04 03:31:23 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:31:23 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:31:23 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:31:23 --> Utf8 Class Initialized
INFO - 2024-11-04 03:31:23 --> Utf8 Class Initialized
INFO - 2024-11-04 03:31:23 --> URI Class Initialized
INFO - 2024-11-04 03:31:23 --> URI Class Initialized
INFO - 2024-11-04 03:31:23 --> Router Class Initialized
INFO - 2024-11-04 03:31:23 --> Router Class Initialized
INFO - 2024-11-04 03:31:23 --> Output Class Initialized
INFO - 2024-11-04 03:31:23 --> Output Class Initialized
INFO - 2024-11-04 03:31:23 --> Security Class Initialized
INFO - 2024-11-04 03:31:23 --> Security Class Initialized
DEBUG - 2024-11-04 03:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:31:23 --> Input Class Initialized
INFO - 2024-11-04 03:31:23 --> Input Class Initialized
INFO - 2024-11-04 03:31:23 --> Language Class Initialized
INFO - 2024-11-04 03:31:23 --> Language Class Initialized
ERROR - 2024-11-04 03:31:24 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:31:24 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:32:53 --> Config Class Initialized
INFO - 2024-11-04 03:32:53 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:32:53 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:32:53 --> Utf8 Class Initialized
INFO - 2024-11-04 03:32:53 --> URI Class Initialized
INFO - 2024-11-04 03:32:53 --> Router Class Initialized
INFO - 2024-11-04 03:32:53 --> Output Class Initialized
INFO - 2024-11-04 03:32:53 --> Security Class Initialized
DEBUG - 2024-11-04 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:32:53 --> Input Class Initialized
INFO - 2024-11-04 03:32:53 --> Language Class Initialized
INFO - 2024-11-04 03:32:53 --> Loader Class Initialized
INFO - 2024-11-04 03:32:53 --> Helper loaded: url_helper
INFO - 2024-11-04 03:32:53 --> Database Driver Class Initialized
INFO - 2024-11-04 03:32:53 --> Controller Class Initialized
INFO - 2024-11-04 03:32:53 --> Model "Item_model" initialized
INFO - 2024-11-04 03:32:53 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:32:53 --> Final output sent to browser
DEBUG - 2024-11-04 03:32:53 --> Total execution time: 0.1812
INFO - 2024-11-04 03:32:53 --> Config Class Initialized
INFO - 2024-11-04 03:32:53 --> Config Class Initialized
INFO - 2024-11-04 03:32:53 --> Hooks Class Initialized
INFO - 2024-11-04 03:32:53 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:32:53 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:32:53 --> Utf8 Class Initialized
INFO - 2024-11-04 03:32:53 --> Utf8 Class Initialized
INFO - 2024-11-04 03:32:53 --> URI Class Initialized
INFO - 2024-11-04 03:32:53 --> URI Class Initialized
INFO - 2024-11-04 03:32:53 --> Router Class Initialized
INFO - 2024-11-04 03:32:53 --> Router Class Initialized
INFO - 2024-11-04 03:32:53 --> Output Class Initialized
INFO - 2024-11-04 03:32:53 --> Output Class Initialized
INFO - 2024-11-04 03:32:53 --> Security Class Initialized
INFO - 2024-11-04 03:32:53 --> Security Class Initialized
DEBUG - 2024-11-04 03:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:32:53 --> Input Class Initialized
INFO - 2024-11-04 03:32:53 --> Input Class Initialized
INFO - 2024-11-04 03:32:53 --> Language Class Initialized
INFO - 2024-11-04 03:32:53 --> Language Class Initialized
ERROR - 2024-11-04 03:32:53 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:32:53 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:34:53 --> Config Class Initialized
INFO - 2024-11-04 03:34:53 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:34:53 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:34:53 --> Utf8 Class Initialized
INFO - 2024-11-04 03:34:53 --> URI Class Initialized
INFO - 2024-11-04 03:34:53 --> Router Class Initialized
INFO - 2024-11-04 03:34:53 --> Output Class Initialized
INFO - 2024-11-04 03:34:53 --> Security Class Initialized
DEBUG - 2024-11-04 03:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:34:53 --> Input Class Initialized
INFO - 2024-11-04 03:34:53 --> Language Class Initialized
INFO - 2024-11-04 03:34:53 --> Loader Class Initialized
INFO - 2024-11-04 03:34:53 --> Helper loaded: url_helper
INFO - 2024-11-04 03:34:53 --> Database Driver Class Initialized
INFO - 2024-11-04 03:34:53 --> Controller Class Initialized
INFO - 2024-11-04 03:34:53 --> Model "Item_model" initialized
INFO - 2024-11-04 03:34:53 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:34:53 --> Final output sent to browser
DEBUG - 2024-11-04 03:34:53 --> Total execution time: 0.2573
INFO - 2024-11-04 03:34:53 --> Config Class Initialized
INFO - 2024-11-04 03:34:53 --> Config Class Initialized
INFO - 2024-11-04 03:34:53 --> Hooks Class Initialized
INFO - 2024-11-04 03:34:53 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:34:53 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:34:53 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:34:53 --> Utf8 Class Initialized
INFO - 2024-11-04 03:34:53 --> Utf8 Class Initialized
INFO - 2024-11-04 03:34:53 --> URI Class Initialized
INFO - 2024-11-04 03:34:53 --> URI Class Initialized
INFO - 2024-11-04 03:34:53 --> Router Class Initialized
INFO - 2024-11-04 03:34:53 --> Router Class Initialized
INFO - 2024-11-04 03:34:53 --> Output Class Initialized
INFO - 2024-11-04 03:34:53 --> Output Class Initialized
INFO - 2024-11-04 03:34:53 --> Security Class Initialized
INFO - 2024-11-04 03:34:53 --> Security Class Initialized
DEBUG - 2024-11-04 03:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:34:53 --> Input Class Initialized
INFO - 2024-11-04 03:34:53 --> Input Class Initialized
INFO - 2024-11-04 03:34:53 --> Language Class Initialized
INFO - 2024-11-04 03:34:53 --> Language Class Initialized
ERROR - 2024-11-04 03:34:53 --> 404 Page Not Found: Bootstrap/js
ERROR - 2024-11-04 03:34:53 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-04 03:41:43 --> Config Class Initialized
INFO - 2024-11-04 03:41:43 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:41:43 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:41:43 --> Utf8 Class Initialized
INFO - 2024-11-04 03:41:43 --> URI Class Initialized
INFO - 2024-11-04 03:41:43 --> Router Class Initialized
INFO - 2024-11-04 03:41:43 --> Output Class Initialized
INFO - 2024-11-04 03:41:43 --> Security Class Initialized
DEBUG - 2024-11-04 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:41:43 --> Input Class Initialized
INFO - 2024-11-04 03:41:43 --> Language Class Initialized
INFO - 2024-11-04 03:41:43 --> Loader Class Initialized
INFO - 2024-11-04 03:41:43 --> Helper loaded: url_helper
INFO - 2024-11-04 03:41:43 --> Database Driver Class Initialized
INFO - 2024-11-04 03:41:43 --> Controller Class Initialized
INFO - 2024-11-04 03:41:43 --> Model "Item_model" initialized
INFO - 2024-11-04 03:41:43 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:41:43 --> Final output sent to browser
DEBUG - 2024-11-04 03:41:43 --> Total execution time: 0.1229
INFO - 2024-11-04 03:41:43 --> Config Class Initialized
INFO - 2024-11-04 03:41:43 --> Config Class Initialized
INFO - 2024-11-04 03:41:43 --> Hooks Class Initialized
INFO - 2024-11-04 03:41:43 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:41:43 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:41:43 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:41:43 --> Utf8 Class Initialized
INFO - 2024-11-04 03:41:43 --> Utf8 Class Initialized
INFO - 2024-11-04 03:41:43 --> URI Class Initialized
INFO - 2024-11-04 03:41:43 --> URI Class Initialized
INFO - 2024-11-04 03:41:43 --> Router Class Initialized
INFO - 2024-11-04 03:41:43 --> Router Class Initialized
INFO - 2024-11-04 03:41:43 --> Output Class Initialized
INFO - 2024-11-04 03:41:43 --> Output Class Initialized
INFO - 2024-11-04 03:41:43 --> Security Class Initialized
INFO - 2024-11-04 03:41:43 --> Security Class Initialized
DEBUG - 2024-11-04 03:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:41:43 --> Input Class Initialized
INFO - 2024-11-04 03:41:43 --> Input Class Initialized
INFO - 2024-11-04 03:41:43 --> Language Class Initialized
INFO - 2024-11-04 03:41:43 --> Language Class Initialized
ERROR - 2024-11-04 03:41:43 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:41:43 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:41:46 --> Config Class Initialized
INFO - 2024-11-04 03:41:46 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:41:46 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:41:46 --> Utf8 Class Initialized
INFO - 2024-11-04 03:41:46 --> URI Class Initialized
INFO - 2024-11-04 03:41:46 --> Router Class Initialized
INFO - 2024-11-04 03:41:46 --> Output Class Initialized
INFO - 2024-11-04 03:41:46 --> Security Class Initialized
DEBUG - 2024-11-04 03:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:41:46 --> Input Class Initialized
INFO - 2024-11-04 03:41:46 --> Language Class Initialized
INFO - 2024-11-04 03:41:46 --> Loader Class Initialized
INFO - 2024-11-04 03:41:46 --> Helper loaded: url_helper
INFO - 2024-11-04 03:41:46 --> Database Driver Class Initialized
INFO - 2024-11-04 03:41:46 --> Controller Class Initialized
INFO - 2024-11-04 03:41:46 --> Model "Item_model" initialized
INFO - 2024-11-04 03:41:46 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:41:46 --> Final output sent to browser
DEBUG - 2024-11-04 03:41:46 --> Total execution time: 0.1202
INFO - 2024-11-04 03:41:47 --> Config Class Initialized
INFO - 2024-11-04 03:41:47 --> Config Class Initialized
INFO - 2024-11-04 03:41:47 --> Hooks Class Initialized
INFO - 2024-11-04 03:41:47 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:41:47 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:41:47 --> Utf8 Class Initialized
INFO - 2024-11-04 03:41:47 --> Utf8 Class Initialized
INFO - 2024-11-04 03:41:47 --> URI Class Initialized
INFO - 2024-11-04 03:41:47 --> URI Class Initialized
INFO - 2024-11-04 03:41:47 --> Router Class Initialized
INFO - 2024-11-04 03:41:47 --> Router Class Initialized
INFO - 2024-11-04 03:41:47 --> Output Class Initialized
INFO - 2024-11-04 03:41:47 --> Output Class Initialized
INFO - 2024-11-04 03:41:47 --> Security Class Initialized
INFO - 2024-11-04 03:41:47 --> Security Class Initialized
DEBUG - 2024-11-04 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:41:47 --> Input Class Initialized
INFO - 2024-11-04 03:41:47 --> Input Class Initialized
INFO - 2024-11-04 03:41:47 --> Language Class Initialized
INFO - 2024-11-04 03:41:47 --> Language Class Initialized
ERROR - 2024-11-04 03:41:47 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:41:47 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:42:14 --> Config Class Initialized
INFO - 2024-11-04 03:42:14 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:42:14 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:42:14 --> Utf8 Class Initialized
INFO - 2024-11-04 03:42:14 --> URI Class Initialized
INFO - 2024-11-04 03:42:14 --> Router Class Initialized
INFO - 2024-11-04 03:42:14 --> Output Class Initialized
INFO - 2024-11-04 03:42:14 --> Security Class Initialized
DEBUG - 2024-11-04 03:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:42:14 --> Input Class Initialized
INFO - 2024-11-04 03:42:14 --> Language Class Initialized
INFO - 2024-11-04 03:42:14 --> Loader Class Initialized
INFO - 2024-11-04 03:42:14 --> Helper loaded: url_helper
INFO - 2024-11-04 03:42:14 --> Database Driver Class Initialized
INFO - 2024-11-04 03:42:14 --> Controller Class Initialized
INFO - 2024-11-04 03:42:14 --> Model "Item_model" initialized
INFO - 2024-11-04 03:42:14 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:42:14 --> Final output sent to browser
DEBUG - 2024-11-04 03:42:14 --> Total execution time: 0.2294
INFO - 2024-11-04 03:42:14 --> Config Class Initialized
INFO - 2024-11-04 03:42:14 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:42:14 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:42:14 --> Utf8 Class Initialized
INFO - 2024-11-04 03:42:14 --> URI Class Initialized
INFO - 2024-11-04 03:42:14 --> Router Class Initialized
INFO - 2024-11-04 03:42:14 --> Output Class Initialized
INFO - 2024-11-04 03:42:14 --> Security Class Initialized
DEBUG - 2024-11-04 03:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:42:14 --> Input Class Initialized
INFO - 2024-11-04 03:42:14 --> Language Class Initialized
ERROR - 2024-11-04 03:42:14 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:42:17 --> Config Class Initialized
INFO - 2024-11-04 03:42:17 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:42:17 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:42:17 --> Utf8 Class Initialized
INFO - 2024-11-04 03:42:17 --> URI Class Initialized
INFO - 2024-11-04 03:42:17 --> Router Class Initialized
INFO - 2024-11-04 03:42:17 --> Output Class Initialized
INFO - 2024-11-04 03:42:17 --> Security Class Initialized
DEBUG - 2024-11-04 03:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:42:17 --> Input Class Initialized
INFO - 2024-11-04 03:42:17 --> Language Class Initialized
INFO - 2024-11-04 03:42:17 --> Loader Class Initialized
INFO - 2024-11-04 03:42:17 --> Helper loaded: url_helper
INFO - 2024-11-04 03:42:18 --> Database Driver Class Initialized
INFO - 2024-11-04 03:42:18 --> Controller Class Initialized
INFO - 2024-11-04 03:42:18 --> Model "Item_model" initialized
INFO - 2024-11-04 03:42:18 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:42:18 --> Final output sent to browser
DEBUG - 2024-11-04 03:42:18 --> Total execution time: 0.2953
INFO - 2024-11-04 03:42:18 --> Config Class Initialized
INFO - 2024-11-04 03:42:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:42:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:42:18 --> Utf8 Class Initialized
INFO - 2024-11-04 03:42:18 --> URI Class Initialized
INFO - 2024-11-04 03:42:18 --> Router Class Initialized
INFO - 2024-11-04 03:42:18 --> Output Class Initialized
INFO - 2024-11-04 03:42:18 --> Security Class Initialized
DEBUG - 2024-11-04 03:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:42:18 --> Input Class Initialized
INFO - 2024-11-04 03:42:18 --> Language Class Initialized
ERROR - 2024-11-04 03:42:18 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:44:20 --> Config Class Initialized
INFO - 2024-11-04 03:44:20 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:44:20 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:44:20 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:20 --> URI Class Initialized
INFO - 2024-11-04 03:44:20 --> Router Class Initialized
INFO - 2024-11-04 03:44:20 --> Output Class Initialized
INFO - 2024-11-04 03:44:20 --> Security Class Initialized
DEBUG - 2024-11-04 03:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:44:20 --> Input Class Initialized
INFO - 2024-11-04 03:44:20 --> Language Class Initialized
INFO - 2024-11-04 03:44:20 --> Loader Class Initialized
INFO - 2024-11-04 03:44:20 --> Helper loaded: url_helper
INFO - 2024-11-04 03:44:20 --> Database Driver Class Initialized
INFO - 2024-11-04 03:44:20 --> Controller Class Initialized
INFO - 2024-11-04 03:44:20 --> Model "Item_model" initialized
INFO - 2024-11-04 03:44:20 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:44:20 --> Final output sent to browser
DEBUG - 2024-11-04 03:44:20 --> Total execution time: 0.1754
INFO - 2024-11-04 03:44:20 --> Config Class Initialized
INFO - 2024-11-04 03:44:20 --> Config Class Initialized
INFO - 2024-11-04 03:44:20 --> Hooks Class Initialized
INFO - 2024-11-04 03:44:20 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:44:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:44:20 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:44:20 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:20 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:20 --> URI Class Initialized
INFO - 2024-11-04 03:44:20 --> URI Class Initialized
INFO - 2024-11-04 03:44:20 --> Router Class Initialized
INFO - 2024-11-04 03:44:20 --> Router Class Initialized
INFO - 2024-11-04 03:44:20 --> Output Class Initialized
INFO - 2024-11-04 03:44:20 --> Output Class Initialized
INFO - 2024-11-04 03:44:21 --> Security Class Initialized
INFO - 2024-11-04 03:44:21 --> Security Class Initialized
DEBUG - 2024-11-04 03:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:44:21 --> Input Class Initialized
INFO - 2024-11-04 03:44:21 --> Input Class Initialized
INFO - 2024-11-04 03:44:21 --> Language Class Initialized
INFO - 2024-11-04 03:44:21 --> Language Class Initialized
ERROR - 2024-11-04 03:44:21 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:44:21 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:44:24 --> Config Class Initialized
INFO - 2024-11-04 03:44:24 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:44:24 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:44:24 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:24 --> URI Class Initialized
INFO - 2024-11-04 03:44:24 --> Router Class Initialized
INFO - 2024-11-04 03:44:24 --> Output Class Initialized
INFO - 2024-11-04 03:44:24 --> Security Class Initialized
DEBUG - 2024-11-04 03:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:44:24 --> Input Class Initialized
INFO - 2024-11-04 03:44:24 --> Language Class Initialized
INFO - 2024-11-04 03:44:24 --> Loader Class Initialized
INFO - 2024-11-04 03:44:24 --> Helper loaded: url_helper
INFO - 2024-11-04 03:44:24 --> Database Driver Class Initialized
INFO - 2024-11-04 03:44:24 --> Controller Class Initialized
INFO - 2024-11-04 03:44:24 --> Model "Item_model" initialized
INFO - 2024-11-04 03:44:24 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:44:24 --> Final output sent to browser
DEBUG - 2024-11-04 03:44:24 --> Total execution time: 0.2781
INFO - 2024-11-04 03:44:25 --> Config Class Initialized
INFO - 2024-11-04 03:44:25 --> Config Class Initialized
INFO - 2024-11-04 03:44:25 --> Hooks Class Initialized
INFO - 2024-11-04 03:44:25 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:44:25 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:44:25 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:25 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:25 --> URI Class Initialized
INFO - 2024-11-04 03:44:25 --> URI Class Initialized
INFO - 2024-11-04 03:44:25 --> Router Class Initialized
INFO - 2024-11-04 03:44:25 --> Router Class Initialized
INFO - 2024-11-04 03:44:25 --> Output Class Initialized
INFO - 2024-11-04 03:44:25 --> Output Class Initialized
INFO - 2024-11-04 03:44:25 --> Security Class Initialized
INFO - 2024-11-04 03:44:25 --> Security Class Initialized
DEBUG - 2024-11-04 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:44:25 --> Input Class Initialized
INFO - 2024-11-04 03:44:25 --> Input Class Initialized
INFO - 2024-11-04 03:44:25 --> Language Class Initialized
INFO - 2024-11-04 03:44:25 --> Language Class Initialized
ERROR - 2024-11-04 03:44:25 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:44:25 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:44:29 --> Config Class Initialized
INFO - 2024-11-04 03:44:29 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:44:29 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:44:29 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:29 --> URI Class Initialized
DEBUG - 2024-11-04 03:44:29 --> No URI present. Default controller set.
INFO - 2024-11-04 03:44:29 --> Router Class Initialized
INFO - 2024-11-04 03:44:29 --> Output Class Initialized
INFO - 2024-11-04 03:44:29 --> Security Class Initialized
DEBUG - 2024-11-04 03:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:44:29 --> Input Class Initialized
INFO - 2024-11-04 03:44:29 --> Language Class Initialized
INFO - 2024-11-04 03:44:29 --> Loader Class Initialized
INFO - 2024-11-04 03:44:30 --> Helper loaded: url_helper
INFO - 2024-11-04 03:44:30 --> Database Driver Class Initialized
INFO - 2024-11-04 03:44:30 --> Controller Class Initialized
INFO - 2024-11-04 03:44:30 --> Model "Item_model" initialized
INFO - 2024-11-04 03:44:30 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:44:30 --> Final output sent to browser
DEBUG - 2024-11-04 03:44:30 --> Total execution time: 0.1970
INFO - 2024-11-04 03:44:30 --> Config Class Initialized
INFO - 2024-11-04 03:44:30 --> Config Class Initialized
INFO - 2024-11-04 03:44:30 --> Hooks Class Initialized
INFO - 2024-11-04 03:44:30 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:44:30 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:44:30 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:44:30 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:30 --> Utf8 Class Initialized
INFO - 2024-11-04 03:44:30 --> URI Class Initialized
INFO - 2024-11-04 03:44:30 --> URI Class Initialized
INFO - 2024-11-04 03:44:30 --> Router Class Initialized
INFO - 2024-11-04 03:44:30 --> Router Class Initialized
INFO - 2024-11-04 03:44:30 --> Output Class Initialized
INFO - 2024-11-04 03:44:30 --> Output Class Initialized
INFO - 2024-11-04 03:44:30 --> Security Class Initialized
INFO - 2024-11-04 03:44:30 --> Security Class Initialized
DEBUG - 2024-11-04 03:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:44:30 --> Input Class Initialized
INFO - 2024-11-04 03:44:30 --> Input Class Initialized
INFO - 2024-11-04 03:44:30 --> Language Class Initialized
INFO - 2024-11-04 03:44:30 --> Language Class Initialized
ERROR - 2024-11-04 03:44:30 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:44:30 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:45:14 --> Config Class Initialized
INFO - 2024-11-04 03:45:14 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:45:14 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:45:14 --> Utf8 Class Initialized
INFO - 2024-11-04 03:45:14 --> URI Class Initialized
DEBUG - 2024-11-04 03:45:14 --> No URI present. Default controller set.
INFO - 2024-11-04 03:45:14 --> Router Class Initialized
INFO - 2024-11-04 03:45:14 --> Output Class Initialized
INFO - 2024-11-04 03:45:14 --> Security Class Initialized
DEBUG - 2024-11-04 03:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:45:14 --> Input Class Initialized
INFO - 2024-11-04 03:45:14 --> Language Class Initialized
INFO - 2024-11-04 03:45:14 --> Loader Class Initialized
INFO - 2024-11-04 03:45:14 --> Helper loaded: url_helper
INFO - 2024-11-04 03:45:14 --> Database Driver Class Initialized
INFO - 2024-11-04 03:45:14 --> Controller Class Initialized
INFO - 2024-11-04 03:45:14 --> Model "Item_model" initialized
INFO - 2024-11-04 03:45:14 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:45:14 --> Final output sent to browser
DEBUG - 2024-11-04 03:45:14 --> Total execution time: 0.2901
INFO - 2024-11-04 03:45:15 --> Config Class Initialized
INFO - 2024-11-04 03:45:15 --> Config Class Initialized
INFO - 2024-11-04 03:45:15 --> Hooks Class Initialized
INFO - 2024-11-04 03:45:15 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:45:15 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:45:15 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:45:15 --> Utf8 Class Initialized
INFO - 2024-11-04 03:45:15 --> Utf8 Class Initialized
INFO - 2024-11-04 03:45:15 --> URI Class Initialized
INFO - 2024-11-04 03:45:15 --> URI Class Initialized
INFO - 2024-11-04 03:45:15 --> Router Class Initialized
INFO - 2024-11-04 03:45:15 --> Router Class Initialized
INFO - 2024-11-04 03:45:15 --> Output Class Initialized
INFO - 2024-11-04 03:45:15 --> Output Class Initialized
INFO - 2024-11-04 03:45:15 --> Security Class Initialized
INFO - 2024-11-04 03:45:15 --> Security Class Initialized
DEBUG - 2024-11-04 03:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:45:15 --> Input Class Initialized
INFO - 2024-11-04 03:45:15 --> Input Class Initialized
INFO - 2024-11-04 03:45:15 --> Language Class Initialized
INFO - 2024-11-04 03:45:15 --> Language Class Initialized
ERROR - 2024-11-04 03:45:15 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:45:15 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 03:48:52 --> Config Class Initialized
INFO - 2024-11-04 03:48:52 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:48:52 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:48:52 --> Utf8 Class Initialized
INFO - 2024-11-04 03:48:52 --> URI Class Initialized
DEBUG - 2024-11-04 03:48:52 --> No URI present. Default controller set.
INFO - 2024-11-04 03:48:52 --> Router Class Initialized
INFO - 2024-11-04 03:48:52 --> Output Class Initialized
INFO - 2024-11-04 03:48:52 --> Security Class Initialized
DEBUG - 2024-11-04 03:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:48:52 --> Input Class Initialized
INFO - 2024-11-04 03:48:52 --> Language Class Initialized
INFO - 2024-11-04 03:48:52 --> Loader Class Initialized
INFO - 2024-11-04 03:48:52 --> Helper loaded: url_helper
INFO - 2024-11-04 03:48:52 --> Database Driver Class Initialized
INFO - 2024-11-04 03:48:52 --> Controller Class Initialized
INFO - 2024-11-04 03:48:52 --> Model "Item_model" initialized
INFO - 2024-11-04 03:48:52 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:48:52 --> Final output sent to browser
DEBUG - 2024-11-04 03:48:52 --> Total execution time: 0.2236
INFO - 2024-11-04 03:48:59 --> Config Class Initialized
INFO - 2024-11-04 03:48:59 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:48:59 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:48:59 --> Utf8 Class Initialized
INFO - 2024-11-04 03:48:59 --> URI Class Initialized
INFO - 2024-11-04 03:48:59 --> Router Class Initialized
INFO - 2024-11-04 03:48:59 --> Output Class Initialized
INFO - 2024-11-04 03:48:59 --> Security Class Initialized
DEBUG - 2024-11-04 03:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:48:59 --> Input Class Initialized
INFO - 2024-11-04 03:48:59 --> Language Class Initialized
INFO - 2024-11-04 03:48:59 --> Loader Class Initialized
INFO - 2024-11-04 03:48:59 --> Helper loaded: url_helper
INFO - 2024-11-04 03:48:59 --> Database Driver Class Initialized
INFO - 2024-11-04 03:48:59 --> Controller Class Initialized
INFO - 2024-11-04 03:48:59 --> Model "Item_model" initialized
INFO - 2024-11-04 03:48:59 --> File loaded: C:\wamp64\www\crud_1\application\views\items/create.php
INFO - 2024-11-04 03:48:59 --> Final output sent to browser
DEBUG - 2024-11-04 03:48:59 --> Total execution time: 0.2393
INFO - 2024-11-04 03:48:59 --> Config Class Initialized
INFO - 2024-11-04 03:48:59 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:48:59 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:48:59 --> Utf8 Class Initialized
INFO - 2024-11-04 03:48:59 --> URI Class Initialized
INFO - 2024-11-04 03:48:59 --> Router Class Initialized
INFO - 2024-11-04 03:48:59 --> Output Class Initialized
INFO - 2024-11-04 03:48:59 --> Security Class Initialized
DEBUG - 2024-11-04 03:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:49:00 --> Input Class Initialized
INFO - 2024-11-04 03:49:00 --> Language Class Initialized
ERROR - 2024-11-04 03:49:00 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-04 03:53:59 --> Config Class Initialized
INFO - 2024-11-04 03:53:59 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:53:59 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:53:59 --> Utf8 Class Initialized
INFO - 2024-11-04 03:53:59 --> URI Class Initialized
DEBUG - 2024-11-04 03:53:59 --> No URI present. Default controller set.
INFO - 2024-11-04 03:53:59 --> Router Class Initialized
INFO - 2024-11-04 03:53:59 --> Output Class Initialized
INFO - 2024-11-04 03:53:59 --> Security Class Initialized
DEBUG - 2024-11-04 03:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:53:59 --> Input Class Initialized
INFO - 2024-11-04 03:53:59 --> Language Class Initialized
INFO - 2024-11-04 03:53:59 --> Loader Class Initialized
INFO - 2024-11-04 03:53:59 --> Helper loaded: url_helper
INFO - 2024-11-04 03:53:59 --> Database Driver Class Initialized
INFO - 2024-11-04 03:54:00 --> Controller Class Initialized
INFO - 2024-11-04 03:54:00 --> Model "Item_model" initialized
INFO - 2024-11-04 03:54:00 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 03:54:00 --> Final output sent to browser
DEBUG - 2024-11-04 03:54:00 --> Total execution time: 0.3262
INFO - 2024-11-04 03:54:00 --> Config Class Initialized
INFO - 2024-11-04 03:54:00 --> Config Class Initialized
INFO - 2024-11-04 03:54:00 --> Hooks Class Initialized
INFO - 2024-11-04 03:54:00 --> Hooks Class Initialized
DEBUG - 2024-11-04 03:54:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 03:54:00 --> UTF-8 Support Enabled
INFO - 2024-11-04 03:54:00 --> Utf8 Class Initialized
INFO - 2024-11-04 03:54:00 --> Utf8 Class Initialized
INFO - 2024-11-04 03:54:00 --> URI Class Initialized
INFO - 2024-11-04 03:54:00 --> URI Class Initialized
INFO - 2024-11-04 03:54:00 --> Router Class Initialized
INFO - 2024-11-04 03:54:00 --> Router Class Initialized
INFO - 2024-11-04 03:54:00 --> Output Class Initialized
INFO - 2024-11-04 03:54:00 --> Output Class Initialized
INFO - 2024-11-04 03:54:00 --> Security Class Initialized
INFO - 2024-11-04 03:54:00 --> Security Class Initialized
DEBUG - 2024-11-04 03:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 03:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 03:54:00 --> Input Class Initialized
INFO - 2024-11-04 03:54:00 --> Input Class Initialized
INFO - 2024-11-04 03:54:00 --> Language Class Initialized
INFO - 2024-11-04 03:54:00 --> Language Class Initialized
ERROR - 2024-11-04 03:54:00 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 03:54:00 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:02:05 --> Config Class Initialized
INFO - 2024-11-04 04:02:05 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:02:05 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:02:05 --> Utf8 Class Initialized
INFO - 2024-11-04 04:02:05 --> URI Class Initialized
INFO - 2024-11-04 04:02:05 --> Router Class Initialized
INFO - 2024-11-04 04:02:05 --> Output Class Initialized
INFO - 2024-11-04 04:02:05 --> Security Class Initialized
DEBUG - 2024-11-04 04:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:02:05 --> Input Class Initialized
INFO - 2024-11-04 04:02:05 --> Language Class Initialized
ERROR - 2024-11-04 04:02:05 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-04 04:02:07 --> Config Class Initialized
INFO - 2024-11-04 04:02:07 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:02:07 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:02:07 --> Utf8 Class Initialized
INFO - 2024-11-04 04:02:07 --> URI Class Initialized
INFO - 2024-11-04 04:02:07 --> Router Class Initialized
INFO - 2024-11-04 04:02:07 --> Output Class Initialized
INFO - 2024-11-04 04:02:07 --> Security Class Initialized
DEBUG - 2024-11-04 04:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:02:07 --> Input Class Initialized
INFO - 2024-11-04 04:02:07 --> Language Class Initialized
ERROR - 2024-11-04 04:02:07 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-04 04:02:10 --> Config Class Initialized
INFO - 2024-11-04 04:02:10 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:02:10 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:02:10 --> Utf8 Class Initialized
INFO - 2024-11-04 04:02:10 --> URI Class Initialized
DEBUG - 2024-11-04 04:02:10 --> No URI present. Default controller set.
INFO - 2024-11-04 04:02:10 --> Router Class Initialized
INFO - 2024-11-04 04:02:10 --> Output Class Initialized
INFO - 2024-11-04 04:02:10 --> Security Class Initialized
DEBUG - 2024-11-04 04:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:02:10 --> Input Class Initialized
INFO - 2024-11-04 04:02:10 --> Language Class Initialized
INFO - 2024-11-04 04:02:10 --> Loader Class Initialized
INFO - 2024-11-04 04:02:10 --> Helper loaded: url_helper
INFO - 2024-11-04 04:02:10 --> Database Driver Class Initialized
INFO - 2024-11-04 04:02:10 --> Controller Class Initialized
INFO - 2024-11-04 04:02:10 --> Model "Item_model" initialized
INFO - 2024-11-04 04:02:10 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:02:10 --> Final output sent to browser
DEBUG - 2024-11-04 04:02:10 --> Total execution time: 0.1144
INFO - 2024-11-04 04:02:11 --> Config Class Initialized
INFO - 2024-11-04 04:02:11 --> Config Class Initialized
INFO - 2024-11-04 04:02:11 --> Hooks Class Initialized
INFO - 2024-11-04 04:02:11 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:02:11 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 04:02:11 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:02:11 --> Utf8 Class Initialized
INFO - 2024-11-04 04:02:11 --> Utf8 Class Initialized
INFO - 2024-11-04 04:02:11 --> URI Class Initialized
INFO - 2024-11-04 04:02:11 --> URI Class Initialized
INFO - 2024-11-04 04:02:11 --> Router Class Initialized
INFO - 2024-11-04 04:02:11 --> Router Class Initialized
INFO - 2024-11-04 04:02:11 --> Output Class Initialized
INFO - 2024-11-04 04:02:11 --> Output Class Initialized
INFO - 2024-11-04 04:02:11 --> Security Class Initialized
INFO - 2024-11-04 04:02:11 --> Security Class Initialized
DEBUG - 2024-11-04 04:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 04:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:02:11 --> Input Class Initialized
INFO - 2024-11-04 04:02:11 --> Input Class Initialized
INFO - 2024-11-04 04:02:11 --> Language Class Initialized
INFO - 2024-11-04 04:02:11 --> Language Class Initialized
ERROR - 2024-11-04 04:02:11 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 04:02:11 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:08:03 --> Config Class Initialized
INFO - 2024-11-04 04:08:03 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:03 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:03 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:03 --> URI Class Initialized
DEBUG - 2024-11-04 04:08:03 --> No URI present. Default controller set.
INFO - 2024-11-04 04:08:03 --> Router Class Initialized
INFO - 2024-11-04 04:08:03 --> Output Class Initialized
INFO - 2024-11-04 04:08:03 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:03 --> Input Class Initialized
INFO - 2024-11-04 04:08:03 --> Language Class Initialized
INFO - 2024-11-04 04:08:03 --> Loader Class Initialized
INFO - 2024-11-04 04:08:03 --> Helper loaded: url_helper
INFO - 2024-11-04 04:08:03 --> Database Driver Class Initialized
INFO - 2024-11-04 04:08:03 --> Controller Class Initialized
INFO - 2024-11-04 04:08:03 --> Model "Item_model" initialized
INFO - 2024-11-04 04:08:03 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:08:03 --> Final output sent to browser
DEBUG - 2024-11-04 04:08:03 --> Total execution time: 0.2896
INFO - 2024-11-04 04:08:04 --> Config Class Initialized
INFO - 2024-11-04 04:08:04 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:04 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:04 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:04 --> URI Class Initialized
INFO - 2024-11-04 04:08:04 --> Router Class Initialized
INFO - 2024-11-04 04:08:04 --> Output Class Initialized
INFO - 2024-11-04 04:08:04 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:04 --> Input Class Initialized
INFO - 2024-11-04 04:08:04 --> Language Class Initialized
ERROR - 2024-11-04 04:08:04 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:08:14 --> Config Class Initialized
INFO - 2024-11-04 04:08:14 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:14 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:14 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:14 --> URI Class Initialized
DEBUG - 2024-11-04 04:08:14 --> No URI present. Default controller set.
INFO - 2024-11-04 04:08:14 --> Router Class Initialized
INFO - 2024-11-04 04:08:14 --> Output Class Initialized
INFO - 2024-11-04 04:08:14 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:14 --> Input Class Initialized
INFO - 2024-11-04 04:08:14 --> Language Class Initialized
INFO - 2024-11-04 04:08:14 --> Loader Class Initialized
INFO - 2024-11-04 04:08:14 --> Helper loaded: url_helper
INFO - 2024-11-04 04:08:14 --> Database Driver Class Initialized
INFO - 2024-11-04 04:08:14 --> Controller Class Initialized
INFO - 2024-11-04 04:08:14 --> Model "Item_model" initialized
INFO - 2024-11-04 04:08:14 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:08:14 --> Final output sent to browser
DEBUG - 2024-11-04 04:08:14 --> Total execution time: 0.2785
INFO - 2024-11-04 04:08:15 --> Config Class Initialized
INFO - 2024-11-04 04:08:15 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:15 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:15 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:15 --> URI Class Initialized
INFO - 2024-11-04 04:08:15 --> Router Class Initialized
INFO - 2024-11-04 04:08:15 --> Output Class Initialized
INFO - 2024-11-04 04:08:15 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:15 --> Input Class Initialized
INFO - 2024-11-04 04:08:15 --> Language Class Initialized
ERROR - 2024-11-04 04:08:15 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:08:18 --> Config Class Initialized
INFO - 2024-11-04 04:08:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:18 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:18 --> URI Class Initialized
DEBUG - 2024-11-04 04:08:18 --> No URI present. Default controller set.
INFO - 2024-11-04 04:08:18 --> Router Class Initialized
INFO - 2024-11-04 04:08:18 --> Output Class Initialized
INFO - 2024-11-04 04:08:18 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:18 --> Input Class Initialized
INFO - 2024-11-04 04:08:18 --> Language Class Initialized
INFO - 2024-11-04 04:08:18 --> Loader Class Initialized
INFO - 2024-11-04 04:08:18 --> Helper loaded: url_helper
INFO - 2024-11-04 04:08:18 --> Database Driver Class Initialized
INFO - 2024-11-04 04:08:18 --> Controller Class Initialized
INFO - 2024-11-04 04:08:18 --> Model "Item_model" initialized
INFO - 2024-11-04 04:08:18 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:08:18 --> Final output sent to browser
DEBUG - 2024-11-04 04:08:18 --> Total execution time: 0.1237
INFO - 2024-11-04 04:08:18 --> Config Class Initialized
INFO - 2024-11-04 04:08:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:18 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:18 --> URI Class Initialized
INFO - 2024-11-04 04:08:18 --> Router Class Initialized
INFO - 2024-11-04 04:08:18 --> Output Class Initialized
INFO - 2024-11-04 04:08:18 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:18 --> Input Class Initialized
INFO - 2024-11-04 04:08:18 --> Language Class Initialized
ERROR - 2024-11-04 04:08:18 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:08:38 --> Config Class Initialized
INFO - 2024-11-04 04:08:38 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:38 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:38 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:38 --> URI Class Initialized
DEBUG - 2024-11-04 04:08:38 --> No URI present. Default controller set.
INFO - 2024-11-04 04:08:38 --> Router Class Initialized
INFO - 2024-11-04 04:08:38 --> Output Class Initialized
INFO - 2024-11-04 04:08:38 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:38 --> Input Class Initialized
INFO - 2024-11-04 04:08:38 --> Language Class Initialized
INFO - 2024-11-04 04:08:38 --> Loader Class Initialized
INFO - 2024-11-04 04:08:38 --> Helper loaded: url_helper
INFO - 2024-11-04 04:08:38 --> Database Driver Class Initialized
INFO - 2024-11-04 04:08:38 --> Controller Class Initialized
INFO - 2024-11-04 04:08:38 --> Model "Item_model" initialized
INFO - 2024-11-04 04:08:38 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:08:38 --> Final output sent to browser
DEBUG - 2024-11-04 04:08:38 --> Total execution time: 0.1260
INFO - 2024-11-04 04:08:39 --> Config Class Initialized
INFO - 2024-11-04 04:08:39 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:39 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:39 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:39 --> URI Class Initialized
INFO - 2024-11-04 04:08:39 --> Router Class Initialized
INFO - 2024-11-04 04:08:39 --> Output Class Initialized
INFO - 2024-11-04 04:08:39 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:39 --> Input Class Initialized
INFO - 2024-11-04 04:08:39 --> Language Class Initialized
ERROR - 2024-11-04 04:08:39 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:08:44 --> Config Class Initialized
INFO - 2024-11-04 04:08:44 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:44 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:44 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:44 --> URI Class Initialized
DEBUG - 2024-11-04 04:08:44 --> No URI present. Default controller set.
INFO - 2024-11-04 04:08:44 --> Router Class Initialized
INFO - 2024-11-04 04:08:44 --> Output Class Initialized
INFO - 2024-11-04 04:08:44 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:44 --> Input Class Initialized
INFO - 2024-11-04 04:08:44 --> Language Class Initialized
INFO - 2024-11-04 04:08:44 --> Loader Class Initialized
INFO - 2024-11-04 04:08:44 --> Helper loaded: url_helper
INFO - 2024-11-04 04:08:44 --> Database Driver Class Initialized
INFO - 2024-11-04 04:08:44 --> Controller Class Initialized
INFO - 2024-11-04 04:08:44 --> Model "Item_model" initialized
INFO - 2024-11-04 04:08:44 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:08:44 --> Final output sent to browser
DEBUG - 2024-11-04 04:08:44 --> Total execution time: 0.2018
INFO - 2024-11-04 04:08:44 --> Config Class Initialized
INFO - 2024-11-04 04:08:44 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:08:44 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:08:44 --> Utf8 Class Initialized
INFO - 2024-11-04 04:08:44 --> URI Class Initialized
INFO - 2024-11-04 04:08:44 --> Router Class Initialized
INFO - 2024-11-04 04:08:44 --> Output Class Initialized
INFO - 2024-11-04 04:08:44 --> Security Class Initialized
DEBUG - 2024-11-04 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:08:44 --> Input Class Initialized
INFO - 2024-11-04 04:08:44 --> Language Class Initialized
ERROR - 2024-11-04 04:08:44 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:09:21 --> Config Class Initialized
INFO - 2024-11-04 04:09:21 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:09:21 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:09:21 --> Utf8 Class Initialized
INFO - 2024-11-04 04:09:21 --> URI Class Initialized
DEBUG - 2024-11-04 04:09:21 --> No URI present. Default controller set.
INFO - 2024-11-04 04:09:21 --> Router Class Initialized
INFO - 2024-11-04 04:09:21 --> Output Class Initialized
INFO - 2024-11-04 04:09:21 --> Security Class Initialized
DEBUG - 2024-11-04 04:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:09:21 --> Input Class Initialized
INFO - 2024-11-04 04:09:21 --> Language Class Initialized
INFO - 2024-11-04 04:09:21 --> Loader Class Initialized
INFO - 2024-11-04 04:09:21 --> Helper loaded: url_helper
INFO - 2024-11-04 04:09:21 --> Database Driver Class Initialized
INFO - 2024-11-04 04:09:21 --> Controller Class Initialized
INFO - 2024-11-04 04:09:21 --> Model "Item_model" initialized
INFO - 2024-11-04 04:09:21 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:09:21 --> Final output sent to browser
DEBUG - 2024-11-04 04:09:21 --> Total execution time: 0.2432
INFO - 2024-11-04 04:09:21 --> Config Class Initialized
INFO - 2024-11-04 04:09:21 --> Config Class Initialized
INFO - 2024-11-04 04:09:21 --> Hooks Class Initialized
INFO - 2024-11-04 04:09:21 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:09:21 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 04:09:21 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:09:21 --> Utf8 Class Initialized
INFO - 2024-11-04 04:09:21 --> Utf8 Class Initialized
INFO - 2024-11-04 04:09:21 --> URI Class Initialized
INFO - 2024-11-04 04:09:21 --> URI Class Initialized
INFO - 2024-11-04 04:09:21 --> Router Class Initialized
INFO - 2024-11-04 04:09:21 --> Router Class Initialized
INFO - 2024-11-04 04:09:21 --> Output Class Initialized
INFO - 2024-11-04 04:09:21 --> Output Class Initialized
INFO - 2024-11-04 04:09:21 --> Security Class Initialized
INFO - 2024-11-04 04:09:21 --> Security Class Initialized
DEBUG - 2024-11-04 04:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 04:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:09:21 --> Input Class Initialized
INFO - 2024-11-04 04:09:21 --> Input Class Initialized
INFO - 2024-11-04 04:09:21 --> Language Class Initialized
INFO - 2024-11-04 04:09:21 --> Language Class Initialized
ERROR - 2024-11-04 04:09:21 --> 404 Page Not Found: Crud_1/bootstrap
ERROR - 2024-11-04 04:09:22 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:09:34 --> Config Class Initialized
INFO - 2024-11-04 04:09:34 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:09:34 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:09:34 --> Utf8 Class Initialized
INFO - 2024-11-04 04:09:34 --> URI Class Initialized
DEBUG - 2024-11-04 04:09:34 --> No URI present. Default controller set.
INFO - 2024-11-04 04:09:34 --> Router Class Initialized
INFO - 2024-11-04 04:09:34 --> Output Class Initialized
INFO - 2024-11-04 04:09:34 --> Security Class Initialized
DEBUG - 2024-11-04 04:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:09:34 --> Input Class Initialized
INFO - 2024-11-04 04:09:34 --> Language Class Initialized
INFO - 2024-11-04 04:09:34 --> Loader Class Initialized
INFO - 2024-11-04 04:09:34 --> Helper loaded: url_helper
INFO - 2024-11-04 04:09:34 --> Database Driver Class Initialized
INFO - 2024-11-04 04:09:34 --> Controller Class Initialized
INFO - 2024-11-04 04:09:34 --> Model "Item_model" initialized
INFO - 2024-11-04 04:09:34 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:09:34 --> Final output sent to browser
DEBUG - 2024-11-04 04:09:34 --> Total execution time: 0.2670
INFO - 2024-11-04 04:09:35 --> Config Class Initialized
INFO - 2024-11-04 04:09:35 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:09:35 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:09:35 --> Utf8 Class Initialized
INFO - 2024-11-04 04:09:35 --> URI Class Initialized
INFO - 2024-11-04 04:09:35 --> Router Class Initialized
INFO - 2024-11-04 04:09:35 --> Output Class Initialized
INFO - 2024-11-04 04:09:35 --> Security Class Initialized
DEBUG - 2024-11-04 04:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:09:35 --> Input Class Initialized
INFO - 2024-11-04 04:09:35 --> Language Class Initialized
ERROR - 2024-11-04 04:09:35 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:10:16 --> Config Class Initialized
INFO - 2024-11-04 04:10:16 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:10:16 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:10:16 --> Utf8 Class Initialized
INFO - 2024-11-04 04:10:16 --> URI Class Initialized
DEBUG - 2024-11-04 04:10:16 --> No URI present. Default controller set.
INFO - 2024-11-04 04:10:16 --> Router Class Initialized
INFO - 2024-11-04 04:10:16 --> Output Class Initialized
INFO - 2024-11-04 04:10:16 --> Security Class Initialized
DEBUG - 2024-11-04 04:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:10:16 --> Input Class Initialized
INFO - 2024-11-04 04:10:16 --> Language Class Initialized
INFO - 2024-11-04 04:10:16 --> Loader Class Initialized
INFO - 2024-11-04 04:10:16 --> Helper loaded: url_helper
INFO - 2024-11-04 04:10:16 --> Database Driver Class Initialized
INFO - 2024-11-04 04:10:16 --> Controller Class Initialized
INFO - 2024-11-04 04:10:16 --> Model "Item_model" initialized
INFO - 2024-11-04 04:10:16 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:10:16 --> Final output sent to browser
DEBUG - 2024-11-04 04:10:16 --> Total execution time: 0.1441
INFO - 2024-11-04 04:10:16 --> Config Class Initialized
INFO - 2024-11-04 04:10:16 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:10:16 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:10:16 --> Utf8 Class Initialized
INFO - 2024-11-04 04:10:16 --> URI Class Initialized
INFO - 2024-11-04 04:10:16 --> Router Class Initialized
INFO - 2024-11-04 04:10:16 --> Output Class Initialized
INFO - 2024-11-04 04:10:16 --> Security Class Initialized
DEBUG - 2024-11-04 04:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:10:16 --> Input Class Initialized
INFO - 2024-11-04 04:10:16 --> Language Class Initialized
ERROR - 2024-11-04 04:10:16 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:10:31 --> Config Class Initialized
INFO - 2024-11-04 04:10:31 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:10:31 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:10:31 --> Utf8 Class Initialized
INFO - 2024-11-04 04:10:31 --> URI Class Initialized
DEBUG - 2024-11-04 04:10:31 --> No URI present. Default controller set.
INFO - 2024-11-04 04:10:31 --> Router Class Initialized
INFO - 2024-11-04 04:10:31 --> Output Class Initialized
INFO - 2024-11-04 04:10:31 --> Security Class Initialized
DEBUG - 2024-11-04 04:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:10:31 --> Input Class Initialized
INFO - 2024-11-04 04:10:31 --> Language Class Initialized
INFO - 2024-11-04 04:10:31 --> Loader Class Initialized
INFO - 2024-11-04 04:10:31 --> Helper loaded: url_helper
INFO - 2024-11-04 04:10:31 --> Database Driver Class Initialized
INFO - 2024-11-04 04:10:31 --> Controller Class Initialized
INFO - 2024-11-04 04:10:31 --> Model "Item_model" initialized
INFO - 2024-11-04 04:10:31 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:10:31 --> Final output sent to browser
DEBUG - 2024-11-04 04:10:31 --> Total execution time: 0.2150
INFO - 2024-11-04 04:10:31 --> Config Class Initialized
INFO - 2024-11-04 04:10:31 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:10:31 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:10:31 --> Utf8 Class Initialized
INFO - 2024-11-04 04:10:31 --> URI Class Initialized
INFO - 2024-11-04 04:10:31 --> Router Class Initialized
INFO - 2024-11-04 04:10:31 --> Output Class Initialized
INFO - 2024-11-04 04:10:32 --> Security Class Initialized
DEBUG - 2024-11-04 04:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:10:32 --> Input Class Initialized
INFO - 2024-11-04 04:10:32 --> Language Class Initialized
ERROR - 2024-11-04 04:10:32 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:10:50 --> Config Class Initialized
INFO - 2024-11-04 04:10:50 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:10:50 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:10:50 --> Utf8 Class Initialized
INFO - 2024-11-04 04:10:50 --> URI Class Initialized
DEBUG - 2024-11-04 04:10:50 --> No URI present. Default controller set.
INFO - 2024-11-04 04:10:50 --> Router Class Initialized
INFO - 2024-11-04 04:10:50 --> Output Class Initialized
INFO - 2024-11-04 04:10:50 --> Security Class Initialized
DEBUG - 2024-11-04 04:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:10:50 --> Input Class Initialized
INFO - 2024-11-04 04:10:50 --> Language Class Initialized
INFO - 2024-11-04 04:10:50 --> Loader Class Initialized
INFO - 2024-11-04 04:10:50 --> Helper loaded: url_helper
INFO - 2024-11-04 04:10:50 --> Database Driver Class Initialized
INFO - 2024-11-04 04:10:50 --> Controller Class Initialized
INFO - 2024-11-04 04:10:50 --> Model "Item_model" initialized
INFO - 2024-11-04 04:10:50 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:10:50 --> Final output sent to browser
DEBUG - 2024-11-04 04:10:50 --> Total execution time: 0.2613
INFO - 2024-11-04 04:10:56 --> Config Class Initialized
INFO - 2024-11-04 04:10:56 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:10:56 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:10:56 --> Utf8 Class Initialized
INFO - 2024-11-04 04:10:56 --> URI Class Initialized
DEBUG - 2024-11-04 04:10:56 --> No URI present. Default controller set.
INFO - 2024-11-04 04:10:56 --> Router Class Initialized
INFO - 2024-11-04 04:10:56 --> Output Class Initialized
INFO - 2024-11-04 04:10:56 --> Security Class Initialized
DEBUG - 2024-11-04 04:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:10:56 --> Input Class Initialized
INFO - 2024-11-04 04:10:56 --> Language Class Initialized
INFO - 2024-11-04 04:10:56 --> Loader Class Initialized
INFO - 2024-11-04 04:10:56 --> Helper loaded: url_helper
INFO - 2024-11-04 04:10:56 --> Database Driver Class Initialized
INFO - 2024-11-04 04:10:56 --> Controller Class Initialized
INFO - 2024-11-04 04:10:56 --> Model "Item_model" initialized
INFO - 2024-11-04 04:10:56 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:10:56 --> Final output sent to browser
DEBUG - 2024-11-04 04:10:56 --> Total execution time: 0.2624
INFO - 2024-11-04 04:11:25 --> Config Class Initialized
INFO - 2024-11-04 04:11:25 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:11:25 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:11:25 --> Utf8 Class Initialized
INFO - 2024-11-04 04:11:25 --> URI Class Initialized
DEBUG - 2024-11-04 04:11:25 --> No URI present. Default controller set.
INFO - 2024-11-04 04:11:25 --> Router Class Initialized
INFO - 2024-11-04 04:11:25 --> Output Class Initialized
INFO - 2024-11-04 04:11:25 --> Security Class Initialized
DEBUG - 2024-11-04 04:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:11:25 --> Input Class Initialized
INFO - 2024-11-04 04:11:25 --> Language Class Initialized
INFO - 2024-11-04 04:11:25 --> Loader Class Initialized
INFO - 2024-11-04 04:11:25 --> Helper loaded: url_helper
INFO - 2024-11-04 04:11:25 --> Database Driver Class Initialized
INFO - 2024-11-04 04:11:25 --> Controller Class Initialized
INFO - 2024-11-04 04:11:25 --> Model "Item_model" initialized
INFO - 2024-11-04 04:11:25 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:11:25 --> Final output sent to browser
DEBUG - 2024-11-04 04:11:25 --> Total execution time: 0.2003
INFO - 2024-11-04 04:11:57 --> Config Class Initialized
INFO - 2024-11-04 04:11:57 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:11:57 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:11:57 --> Utf8 Class Initialized
INFO - 2024-11-04 04:11:57 --> URI Class Initialized
DEBUG - 2024-11-04 04:11:57 --> No URI present. Default controller set.
INFO - 2024-11-04 04:11:57 --> Router Class Initialized
INFO - 2024-11-04 04:11:57 --> Output Class Initialized
INFO - 2024-11-04 04:11:57 --> Security Class Initialized
DEBUG - 2024-11-04 04:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:11:57 --> Input Class Initialized
INFO - 2024-11-04 04:11:57 --> Language Class Initialized
INFO - 2024-11-04 04:11:57 --> Loader Class Initialized
INFO - 2024-11-04 04:11:57 --> Helper loaded: url_helper
INFO - 2024-11-04 04:11:57 --> Database Driver Class Initialized
INFO - 2024-11-04 04:11:57 --> Controller Class Initialized
INFO - 2024-11-04 04:11:57 --> Model "Item_model" initialized
INFO - 2024-11-04 04:11:57 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:11:57 --> Final output sent to browser
DEBUG - 2024-11-04 04:11:57 --> Total execution time: 0.1185
INFO - 2024-11-04 04:12:41 --> Config Class Initialized
INFO - 2024-11-04 04:12:41 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:12:41 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:12:41 --> Utf8 Class Initialized
INFO - 2024-11-04 04:12:41 --> URI Class Initialized
DEBUG - 2024-11-04 04:12:41 --> No URI present. Default controller set.
INFO - 2024-11-04 04:12:41 --> Router Class Initialized
INFO - 2024-11-04 04:12:41 --> Output Class Initialized
INFO - 2024-11-04 04:12:41 --> Security Class Initialized
DEBUG - 2024-11-04 04:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:12:41 --> Input Class Initialized
INFO - 2024-11-04 04:12:41 --> Language Class Initialized
INFO - 2024-11-04 04:12:41 --> Loader Class Initialized
INFO - 2024-11-04 04:12:41 --> Helper loaded: url_helper
INFO - 2024-11-04 04:12:41 --> Database Driver Class Initialized
INFO - 2024-11-04 04:12:41 --> Controller Class Initialized
INFO - 2024-11-04 04:12:41 --> Model "Item_model" initialized
INFO - 2024-11-04 04:12:41 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:12:41 --> Final output sent to browser
DEBUG - 2024-11-04 04:12:41 --> Total execution time: 0.1680
INFO - 2024-11-04 04:12:41 --> Config Class Initialized
INFO - 2024-11-04 04:12:41 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:12:41 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:12:41 --> Utf8 Class Initialized
INFO - 2024-11-04 04:12:41 --> URI Class Initialized
INFO - 2024-11-04 04:12:41 --> Router Class Initialized
INFO - 2024-11-04 04:12:41 --> Output Class Initialized
INFO - 2024-11-04 04:12:41 --> Security Class Initialized
DEBUG - 2024-11-04 04:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:12:41 --> Input Class Initialized
INFO - 2024-11-04 04:12:41 --> Language Class Initialized
ERROR - 2024-11-04 04:12:41 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 04:12:57 --> Config Class Initialized
INFO - 2024-11-04 04:12:57 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:12:57 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:12:57 --> Utf8 Class Initialized
INFO - 2024-11-04 04:12:57 --> URI Class Initialized
DEBUG - 2024-11-04 04:12:57 --> No URI present. Default controller set.
INFO - 2024-11-04 04:12:57 --> Router Class Initialized
INFO - 2024-11-04 04:12:57 --> Output Class Initialized
INFO - 2024-11-04 04:12:57 --> Security Class Initialized
DEBUG - 2024-11-04 04:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:12:57 --> Input Class Initialized
INFO - 2024-11-04 04:12:57 --> Language Class Initialized
INFO - 2024-11-04 04:12:57 --> Loader Class Initialized
INFO - 2024-11-04 04:12:57 --> Helper loaded: url_helper
INFO - 2024-11-04 04:12:57 --> Database Driver Class Initialized
INFO - 2024-11-04 04:12:57 --> Controller Class Initialized
INFO - 2024-11-04 04:12:57 --> Model "Item_model" initialized
INFO - 2024-11-04 04:12:57 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 04:12:57 --> Final output sent to browser
DEBUG - 2024-11-04 04:12:57 --> Total execution time: 0.2027
INFO - 2024-11-04 04:12:57 --> Config Class Initialized
INFO - 2024-11-04 04:12:57 --> Hooks Class Initialized
DEBUG - 2024-11-04 04:12:57 --> UTF-8 Support Enabled
INFO - 2024-11-04 04:12:57 --> Utf8 Class Initialized
INFO - 2024-11-04 04:12:57 --> URI Class Initialized
INFO - 2024-11-04 04:12:57 --> Router Class Initialized
INFO - 2024-11-04 04:12:57 --> Output Class Initialized
INFO - 2024-11-04 04:12:57 --> Security Class Initialized
DEBUG - 2024-11-04 04:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 04:12:57 --> Input Class Initialized
INFO - 2024-11-04 04:12:57 --> Language Class Initialized
ERROR - 2024-11-04 04:12:57 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 11:38:06 --> Config Class Initialized
INFO - 2024-11-04 11:38:06 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:38:06 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:38:06 --> Utf8 Class Initialized
INFO - 2024-11-04 11:38:06 --> URI Class Initialized
DEBUG - 2024-11-04 11:38:06 --> No URI present. Default controller set.
INFO - 2024-11-04 11:38:07 --> Router Class Initialized
INFO - 2024-11-04 11:38:07 --> Output Class Initialized
INFO - 2024-11-04 11:38:07 --> Security Class Initialized
DEBUG - 2024-11-04 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:38:07 --> Input Class Initialized
INFO - 2024-11-04 11:38:07 --> Language Class Initialized
INFO - 2024-11-04 11:38:07 --> Loader Class Initialized
INFO - 2024-11-04 11:38:07 --> Helper loaded: url_helper
INFO - 2024-11-04 11:38:07 --> Database Driver Class Initialized
INFO - 2024-11-04 11:38:07 --> Controller Class Initialized
INFO - 2024-11-04 11:38:07 --> Model "Item_model" initialized
INFO - 2024-11-04 11:38:07 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:38:07 --> Final output sent to browser
DEBUG - 2024-11-04 11:38:07 --> Total execution time: 0.0666
INFO - 2024-11-04 11:38:07 --> Config Class Initialized
INFO - 2024-11-04 11:38:07 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:38:07 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:38:07 --> Utf8 Class Initialized
INFO - 2024-11-04 11:38:07 --> URI Class Initialized
INFO - 2024-11-04 11:38:07 --> Router Class Initialized
INFO - 2024-11-04 11:38:07 --> Output Class Initialized
INFO - 2024-11-04 11:38:07 --> Security Class Initialized
DEBUG - 2024-11-04 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:38:07 --> Input Class Initialized
INFO - 2024-11-04 11:38:07 --> Language Class Initialized
ERROR - 2024-11-04 11:38:07 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 11:39:02 --> Config Class Initialized
INFO - 2024-11-04 11:39:02 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:39:02 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:39:02 --> Utf8 Class Initialized
INFO - 2024-11-04 11:39:02 --> URI Class Initialized
DEBUG - 2024-11-04 11:39:02 --> No URI present. Default controller set.
INFO - 2024-11-04 11:39:02 --> Router Class Initialized
INFO - 2024-11-04 11:39:02 --> Output Class Initialized
INFO - 2024-11-04 11:39:02 --> Security Class Initialized
DEBUG - 2024-11-04 11:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:39:02 --> Input Class Initialized
INFO - 2024-11-04 11:39:02 --> Language Class Initialized
INFO - 2024-11-04 11:39:02 --> Loader Class Initialized
INFO - 2024-11-04 11:39:02 --> Helper loaded: url_helper
INFO - 2024-11-04 11:39:02 --> Database Driver Class Initialized
INFO - 2024-11-04 11:39:02 --> Controller Class Initialized
INFO - 2024-11-04 11:39:02 --> Model "Item_model" initialized
INFO - 2024-11-04 11:39:02 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:39:02 --> Final output sent to browser
DEBUG - 2024-11-04 11:39:02 --> Total execution time: 0.0738
INFO - 2024-11-04 11:39:29 --> Config Class Initialized
INFO - 2024-11-04 11:39:29 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:39:29 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:39:29 --> Utf8 Class Initialized
INFO - 2024-11-04 11:39:29 --> URI Class Initialized
DEBUG - 2024-11-04 11:39:29 --> No URI present. Default controller set.
INFO - 2024-11-04 11:39:29 --> Router Class Initialized
INFO - 2024-11-04 11:39:29 --> Output Class Initialized
INFO - 2024-11-04 11:39:29 --> Security Class Initialized
DEBUG - 2024-11-04 11:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:39:29 --> Input Class Initialized
INFO - 2024-11-04 11:39:29 --> Language Class Initialized
INFO - 2024-11-04 11:39:29 --> Loader Class Initialized
INFO - 2024-11-04 11:39:29 --> Helper loaded: url_helper
INFO - 2024-11-04 11:39:29 --> Database Driver Class Initialized
INFO - 2024-11-04 11:39:29 --> Controller Class Initialized
INFO - 2024-11-04 11:39:29 --> Model "Item_model" initialized
INFO - 2024-11-04 11:39:29 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:39:29 --> Final output sent to browser
DEBUG - 2024-11-04 11:39:29 --> Total execution time: 0.0674
INFO - 2024-11-04 11:39:45 --> Config Class Initialized
INFO - 2024-11-04 11:39:45 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:39:45 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:39:45 --> Utf8 Class Initialized
INFO - 2024-11-04 11:39:45 --> URI Class Initialized
DEBUG - 2024-11-04 11:39:45 --> No URI present. Default controller set.
INFO - 2024-11-04 11:39:45 --> Router Class Initialized
INFO - 2024-11-04 11:39:45 --> Output Class Initialized
INFO - 2024-11-04 11:39:45 --> Security Class Initialized
DEBUG - 2024-11-04 11:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:39:45 --> Input Class Initialized
INFO - 2024-11-04 11:39:45 --> Language Class Initialized
INFO - 2024-11-04 11:39:45 --> Loader Class Initialized
INFO - 2024-11-04 11:39:45 --> Helper loaded: url_helper
INFO - 2024-11-04 11:39:45 --> Database Driver Class Initialized
INFO - 2024-11-04 11:39:45 --> Controller Class Initialized
INFO - 2024-11-04 11:39:45 --> Model "Item_model" initialized
INFO - 2024-11-04 11:39:45 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:39:45 --> Final output sent to browser
DEBUG - 2024-11-04 11:39:45 --> Total execution time: 0.0740
INFO - 2024-11-04 11:40:32 --> Config Class Initialized
INFO - 2024-11-04 11:40:32 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:40:32 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:40:32 --> Utf8 Class Initialized
INFO - 2024-11-04 11:40:32 --> URI Class Initialized
DEBUG - 2024-11-04 11:40:32 --> No URI present. Default controller set.
INFO - 2024-11-04 11:40:32 --> Router Class Initialized
INFO - 2024-11-04 11:40:32 --> Output Class Initialized
INFO - 2024-11-04 11:40:32 --> Security Class Initialized
DEBUG - 2024-11-04 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:40:32 --> Input Class Initialized
INFO - 2024-11-04 11:40:32 --> Language Class Initialized
INFO - 2024-11-04 11:40:32 --> Loader Class Initialized
INFO - 2024-11-04 11:40:32 --> Helper loaded: url_helper
INFO - 2024-11-04 11:40:32 --> Database Driver Class Initialized
INFO - 2024-11-04 11:40:32 --> Controller Class Initialized
INFO - 2024-11-04 11:40:32 --> Model "Item_model" initialized
INFO - 2024-11-04 11:40:32 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:40:32 --> Final output sent to browser
DEBUG - 2024-11-04 11:40:32 --> Total execution time: 0.0701
INFO - 2024-11-04 11:40:54 --> Config Class Initialized
INFO - 2024-11-04 11:40:54 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:40:54 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:40:54 --> Utf8 Class Initialized
INFO - 2024-11-04 11:40:54 --> URI Class Initialized
DEBUG - 2024-11-04 11:40:54 --> No URI present. Default controller set.
INFO - 2024-11-04 11:40:54 --> Router Class Initialized
INFO - 2024-11-04 11:40:54 --> Output Class Initialized
INFO - 2024-11-04 11:40:54 --> Security Class Initialized
DEBUG - 2024-11-04 11:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:40:54 --> Input Class Initialized
INFO - 2024-11-04 11:40:54 --> Language Class Initialized
INFO - 2024-11-04 11:40:54 --> Loader Class Initialized
INFO - 2024-11-04 11:40:54 --> Helper loaded: url_helper
INFO - 2024-11-04 11:40:54 --> Database Driver Class Initialized
INFO - 2024-11-04 11:40:54 --> Controller Class Initialized
INFO - 2024-11-04 11:40:54 --> Model "Item_model" initialized
INFO - 2024-11-04 11:40:54 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:40:54 --> Final output sent to browser
DEBUG - 2024-11-04 11:40:54 --> Total execution time: 0.0713
INFO - 2024-11-04 11:41:06 --> Config Class Initialized
INFO - 2024-11-04 11:41:06 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:41:06 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:41:06 --> Utf8 Class Initialized
INFO - 2024-11-04 11:41:06 --> URI Class Initialized
INFO - 2024-11-04 11:41:06 --> Router Class Initialized
INFO - 2024-11-04 11:41:06 --> Output Class Initialized
INFO - 2024-11-04 11:41:06 --> Security Class Initialized
DEBUG - 2024-11-04 11:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:41:06 --> Input Class Initialized
INFO - 2024-11-04 11:41:06 --> Language Class Initialized
INFO - 2024-11-04 11:41:06 --> Loader Class Initialized
INFO - 2024-11-04 11:41:06 --> Helper loaded: url_helper
INFO - 2024-11-04 11:41:06 --> Database Driver Class Initialized
INFO - 2024-11-04 11:41:06 --> Controller Class Initialized
INFO - 2024-11-04 11:41:06 --> Model "Item_model" initialized
INFO - 2024-11-04 11:41:06 --> Config Class Initialized
INFO - 2024-11-04 11:41:06 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:41:06 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:41:06 --> Utf8 Class Initialized
INFO - 2024-11-04 11:41:06 --> URI Class Initialized
INFO - 2024-11-04 11:41:06 --> Router Class Initialized
INFO - 2024-11-04 11:41:06 --> Output Class Initialized
INFO - 2024-11-04 11:41:06 --> Security Class Initialized
DEBUG - 2024-11-04 11:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:41:06 --> Input Class Initialized
INFO - 2024-11-04 11:41:06 --> Language Class Initialized
INFO - 2024-11-04 11:41:06 --> Loader Class Initialized
INFO - 2024-11-04 11:41:06 --> Helper loaded: url_helper
INFO - 2024-11-04 11:41:06 --> Database Driver Class Initialized
INFO - 2024-11-04 11:41:06 --> Controller Class Initialized
INFO - 2024-11-04 11:41:06 --> Model "Item_model" initialized
INFO - 2024-11-04 11:41:06 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:41:06 --> Final output sent to browser
DEBUG - 2024-11-04 11:41:06 --> Total execution time: 0.0548
INFO - 2024-11-04 11:41:17 --> Config Class Initialized
INFO - 2024-11-04 11:41:17 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:41:17 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:41:17 --> Utf8 Class Initialized
INFO - 2024-11-04 11:41:17 --> URI Class Initialized
INFO - 2024-11-04 11:41:17 --> Router Class Initialized
INFO - 2024-11-04 11:41:17 --> Output Class Initialized
INFO - 2024-11-04 11:41:17 --> Security Class Initialized
DEBUG - 2024-11-04 11:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:41:17 --> Input Class Initialized
INFO - 2024-11-04 11:41:17 --> Language Class Initialized
INFO - 2024-11-04 11:41:17 --> Loader Class Initialized
INFO - 2024-11-04 11:41:17 --> Helper loaded: url_helper
INFO - 2024-11-04 11:41:17 --> Database Driver Class Initialized
INFO - 2024-11-04 11:41:17 --> Controller Class Initialized
INFO - 2024-11-04 11:41:17 --> Model "Item_model" initialized
INFO - 2024-11-04 11:41:17 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:41:17 --> Final output sent to browser
DEBUG - 2024-11-04 11:41:17 --> Total execution time: 0.0634
INFO - 2024-11-04 11:41:17 --> Config Class Initialized
INFO - 2024-11-04 11:41:17 --> Config Class Initialized
INFO - 2024-11-04 11:41:17 --> Hooks Class Initialized
INFO - 2024-11-04 11:41:17 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2024-11-04 11:41:17 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:41:17 --> Utf8 Class Initialized
INFO - 2024-11-04 11:41:17 --> Utf8 Class Initialized
INFO - 2024-11-04 11:41:17 --> URI Class Initialized
INFO - 2024-11-04 11:41:17 --> URI Class Initialized
INFO - 2024-11-04 11:41:17 --> Router Class Initialized
INFO - 2024-11-04 11:41:17 --> Router Class Initialized
INFO - 2024-11-04 11:41:17 --> Output Class Initialized
INFO - 2024-11-04 11:41:17 --> Output Class Initialized
INFO - 2024-11-04 11:41:17 --> Security Class Initialized
INFO - 2024-11-04 11:41:17 --> Security Class Initialized
DEBUG - 2024-11-04 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-04 11:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:41:17 --> Input Class Initialized
INFO - 2024-11-04 11:41:17 --> Input Class Initialized
INFO - 2024-11-04 11:41:17 --> Language Class Initialized
INFO - 2024-11-04 11:41:17 --> Language Class Initialized
ERROR - 2024-11-04 11:41:17 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-04 11:41:17 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-04 11:42:16 --> Config Class Initialized
INFO - 2024-11-04 11:42:16 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:42:16 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:42:16 --> Utf8 Class Initialized
INFO - 2024-11-04 11:42:16 --> URI Class Initialized
INFO - 2024-11-04 11:42:16 --> Router Class Initialized
INFO - 2024-11-04 11:42:16 --> Output Class Initialized
INFO - 2024-11-04 11:42:16 --> Security Class Initialized
DEBUG - 2024-11-04 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:42:16 --> Input Class Initialized
INFO - 2024-11-04 11:42:16 --> Language Class Initialized
INFO - 2024-11-04 11:42:16 --> Loader Class Initialized
INFO - 2024-11-04 11:42:16 --> Helper loaded: url_helper
INFO - 2024-11-04 11:42:16 --> Database Driver Class Initialized
INFO - 2024-11-04 11:42:16 --> Controller Class Initialized
INFO - 2024-11-04 11:42:16 --> Model "Item_model" initialized
INFO - 2024-11-04 11:42:16 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:42:16 --> Final output sent to browser
DEBUG - 2024-11-04 11:42:16 --> Total execution time: 0.0601
INFO - 2024-11-04 11:44:28 --> Config Class Initialized
INFO - 2024-11-04 11:44:28 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:44:28 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:44:28 --> Utf8 Class Initialized
INFO - 2024-11-04 11:44:28 --> URI Class Initialized
INFO - 2024-11-04 11:44:28 --> Router Class Initialized
INFO - 2024-11-04 11:44:28 --> Output Class Initialized
INFO - 2024-11-04 11:44:28 --> Security Class Initialized
DEBUG - 2024-11-04 11:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:44:28 --> Input Class Initialized
INFO - 2024-11-04 11:44:28 --> Language Class Initialized
INFO - 2024-11-04 11:44:28 --> Loader Class Initialized
INFO - 2024-11-04 11:44:28 --> Helper loaded: url_helper
INFO - 2024-11-04 11:44:28 --> Database Driver Class Initialized
INFO - 2024-11-04 11:44:28 --> Controller Class Initialized
INFO - 2024-11-04 11:44:28 --> Model "Item_model" initialized
INFO - 2024-11-04 11:44:28 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:44:28 --> Final output sent to browser
DEBUG - 2024-11-04 11:44:28 --> Total execution time: 0.0688
INFO - 2024-11-04 11:45:00 --> Config Class Initialized
INFO - 2024-11-04 11:45:00 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:45:00 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:45:00 --> Utf8 Class Initialized
INFO - 2024-11-04 11:45:00 --> URI Class Initialized
INFO - 2024-11-04 11:45:00 --> Router Class Initialized
INFO - 2024-11-04 11:45:00 --> Output Class Initialized
INFO - 2024-11-04 11:45:00 --> Security Class Initialized
DEBUG - 2024-11-04 11:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:45:00 --> Input Class Initialized
INFO - 2024-11-04 11:45:00 --> Language Class Initialized
INFO - 2024-11-04 11:45:00 --> Loader Class Initialized
INFO - 2024-11-04 11:45:00 --> Helper loaded: url_helper
INFO - 2024-11-04 11:45:00 --> Database Driver Class Initialized
INFO - 2024-11-04 11:45:00 --> Controller Class Initialized
INFO - 2024-11-04 11:45:00 --> Model "Item_model" initialized
INFO - 2024-11-04 11:45:00 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:45:00 --> Final output sent to browser
DEBUG - 2024-11-04 11:45:00 --> Total execution time: 0.0566
INFO - 2024-11-04 11:45:13 --> Config Class Initialized
INFO - 2024-11-04 11:45:13 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:45:13 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:45:13 --> Utf8 Class Initialized
INFO - 2024-11-04 11:45:13 --> URI Class Initialized
INFO - 2024-11-04 11:45:13 --> Router Class Initialized
INFO - 2024-11-04 11:45:13 --> Output Class Initialized
INFO - 2024-11-04 11:45:13 --> Security Class Initialized
DEBUG - 2024-11-04 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:45:13 --> Input Class Initialized
INFO - 2024-11-04 11:45:13 --> Language Class Initialized
INFO - 2024-11-04 11:45:13 --> Loader Class Initialized
INFO - 2024-11-04 11:45:13 --> Helper loaded: url_helper
INFO - 2024-11-04 11:45:13 --> Database Driver Class Initialized
INFO - 2024-11-04 11:45:13 --> Controller Class Initialized
INFO - 2024-11-04 11:45:13 --> Model "Item_model" initialized
INFO - 2024-11-04 11:45:13 --> Config Class Initialized
INFO - 2024-11-04 11:45:13 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:45:13 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:45:13 --> Utf8 Class Initialized
INFO - 2024-11-04 11:45:13 --> URI Class Initialized
INFO - 2024-11-04 11:45:13 --> Router Class Initialized
INFO - 2024-11-04 11:45:13 --> Output Class Initialized
INFO - 2024-11-04 11:45:13 --> Security Class Initialized
DEBUG - 2024-11-04 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:45:13 --> Input Class Initialized
INFO - 2024-11-04 11:45:13 --> Language Class Initialized
INFO - 2024-11-04 11:45:13 --> Loader Class Initialized
INFO - 2024-11-04 11:45:13 --> Helper loaded: url_helper
INFO - 2024-11-04 11:45:13 --> Database Driver Class Initialized
INFO - 2024-11-04 11:45:13 --> Controller Class Initialized
INFO - 2024-11-04 11:45:13 --> Model "Item_model" initialized
INFO - 2024-11-04 11:45:13 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:45:13 --> Final output sent to browser
DEBUG - 2024-11-04 11:45:13 --> Total execution time: 0.0679
INFO - 2024-11-04 11:45:54 --> Config Class Initialized
INFO - 2024-11-04 11:45:54 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:45:54 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:45:54 --> Utf8 Class Initialized
INFO - 2024-11-04 11:45:54 --> URI Class Initialized
INFO - 2024-11-04 11:45:54 --> Router Class Initialized
INFO - 2024-11-04 11:45:54 --> Output Class Initialized
INFO - 2024-11-04 11:45:54 --> Security Class Initialized
DEBUG - 2024-11-04 11:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:45:54 --> Input Class Initialized
INFO - 2024-11-04 11:45:54 --> Language Class Initialized
INFO - 2024-11-04 11:45:54 --> Loader Class Initialized
INFO - 2024-11-04 11:45:54 --> Helper loaded: url_helper
INFO - 2024-11-04 11:45:54 --> Database Driver Class Initialized
INFO - 2024-11-04 11:45:54 --> Controller Class Initialized
INFO - 2024-11-04 11:45:54 --> Model "Item_model" initialized
INFO - 2024-11-04 11:45:54 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:45:54 --> Final output sent to browser
DEBUG - 2024-11-04 11:45:54 --> Total execution time: 0.0734
INFO - 2024-11-04 11:46:11 --> Config Class Initialized
INFO - 2024-11-04 11:46:11 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:46:11 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:46:11 --> Utf8 Class Initialized
INFO - 2024-11-04 11:46:11 --> URI Class Initialized
INFO - 2024-11-04 11:46:11 --> Router Class Initialized
INFO - 2024-11-04 11:46:11 --> Output Class Initialized
INFO - 2024-11-04 11:46:11 --> Security Class Initialized
DEBUG - 2024-11-04 11:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:46:11 --> Input Class Initialized
INFO - 2024-11-04 11:46:11 --> Language Class Initialized
INFO - 2024-11-04 11:46:11 --> Loader Class Initialized
INFO - 2024-11-04 11:46:11 --> Helper loaded: url_helper
INFO - 2024-11-04 11:46:11 --> Database Driver Class Initialized
INFO - 2024-11-04 11:46:11 --> Controller Class Initialized
INFO - 2024-11-04 11:46:11 --> Model "Item_model" initialized
INFO - 2024-11-04 11:46:11 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:46:11 --> Final output sent to browser
DEBUG - 2024-11-04 11:46:11 --> Total execution time: 0.0638
INFO - 2024-11-04 11:46:30 --> Config Class Initialized
INFO - 2024-11-04 11:46:30 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:46:30 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:46:30 --> Utf8 Class Initialized
INFO - 2024-11-04 11:46:30 --> URI Class Initialized
INFO - 2024-11-04 11:46:30 --> Router Class Initialized
INFO - 2024-11-04 11:46:30 --> Output Class Initialized
INFO - 2024-11-04 11:46:30 --> Security Class Initialized
DEBUG - 2024-11-04 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:46:30 --> Input Class Initialized
INFO - 2024-11-04 11:46:30 --> Language Class Initialized
INFO - 2024-11-04 11:46:30 --> Loader Class Initialized
INFO - 2024-11-04 11:46:30 --> Helper loaded: url_helper
INFO - 2024-11-04 11:46:30 --> Database Driver Class Initialized
INFO - 2024-11-04 11:46:30 --> Controller Class Initialized
INFO - 2024-11-04 11:46:30 --> Model "Item_model" initialized
INFO - 2024-11-04 11:46:30 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:46:30 --> Final output sent to browser
DEBUG - 2024-11-04 11:46:30 --> Total execution time: 0.0652
INFO - 2024-11-04 11:47:05 --> Config Class Initialized
INFO - 2024-11-04 11:47:05 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:47:05 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:47:05 --> Utf8 Class Initialized
INFO - 2024-11-04 11:47:05 --> URI Class Initialized
INFO - 2024-11-04 11:47:05 --> Router Class Initialized
INFO - 2024-11-04 11:47:05 --> Output Class Initialized
INFO - 2024-11-04 11:47:05 --> Security Class Initialized
DEBUG - 2024-11-04 11:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:47:05 --> Input Class Initialized
INFO - 2024-11-04 11:47:05 --> Language Class Initialized
INFO - 2024-11-04 11:47:05 --> Loader Class Initialized
INFO - 2024-11-04 11:47:05 --> Helper loaded: url_helper
INFO - 2024-11-04 11:47:05 --> Database Driver Class Initialized
INFO - 2024-11-04 11:47:05 --> Controller Class Initialized
INFO - 2024-11-04 11:47:05 --> Model "Item_model" initialized
INFO - 2024-11-04 11:47:05 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:47:05 --> Final output sent to browser
DEBUG - 2024-11-04 11:47:05 --> Total execution time: 0.0659
INFO - 2024-11-04 11:49:34 --> Config Class Initialized
INFO - 2024-11-04 11:49:34 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:49:34 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:49:34 --> Utf8 Class Initialized
INFO - 2024-11-04 11:49:34 --> URI Class Initialized
INFO - 2024-11-04 11:49:34 --> Router Class Initialized
INFO - 2024-11-04 11:49:34 --> Output Class Initialized
INFO - 2024-11-04 11:49:34 --> Security Class Initialized
DEBUG - 2024-11-04 11:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:49:34 --> Input Class Initialized
INFO - 2024-11-04 11:49:34 --> Language Class Initialized
INFO - 2024-11-04 11:49:34 --> Loader Class Initialized
INFO - 2024-11-04 11:49:34 --> Helper loaded: url_helper
INFO - 2024-11-04 11:49:34 --> Database Driver Class Initialized
INFO - 2024-11-04 11:49:34 --> Controller Class Initialized
INFO - 2024-11-04 11:49:34 --> Model "Item_model" initialized
INFO - 2024-11-04 11:49:34 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:49:34 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:49:34 --> Final output sent to browser
DEBUG - 2024-11-04 11:49:34 --> Total execution time: 0.0687
INFO - 2024-11-04 11:50:07 --> Config Class Initialized
INFO - 2024-11-04 11:50:07 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:50:07 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:50:07 --> Utf8 Class Initialized
INFO - 2024-11-04 11:50:07 --> URI Class Initialized
INFO - 2024-11-04 11:50:07 --> Router Class Initialized
INFO - 2024-11-04 11:50:07 --> Output Class Initialized
INFO - 2024-11-04 11:50:07 --> Security Class Initialized
DEBUG - 2024-11-04 11:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:50:07 --> Input Class Initialized
INFO - 2024-11-04 11:50:07 --> Language Class Initialized
INFO - 2024-11-04 11:50:07 --> Loader Class Initialized
INFO - 2024-11-04 11:50:07 --> Helper loaded: url_helper
INFO - 2024-11-04 11:50:07 --> Database Driver Class Initialized
INFO - 2024-11-04 11:50:07 --> Controller Class Initialized
INFO - 2024-11-04 11:50:07 --> Model "Item_model" initialized
INFO - 2024-11-04 11:50:07 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:50:07 --> Final output sent to browser
DEBUG - 2024-11-04 11:50:07 --> Total execution time: 0.0583
INFO - 2024-11-04 11:50:40 --> Config Class Initialized
INFO - 2024-11-04 11:50:40 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:50:40 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:50:40 --> Utf8 Class Initialized
INFO - 2024-11-04 11:50:40 --> URI Class Initialized
INFO - 2024-11-04 11:50:40 --> Router Class Initialized
INFO - 2024-11-04 11:50:40 --> Output Class Initialized
INFO - 2024-11-04 11:50:40 --> Security Class Initialized
DEBUG - 2024-11-04 11:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:50:40 --> Input Class Initialized
INFO - 2024-11-04 11:50:40 --> Language Class Initialized
INFO - 2024-11-04 11:50:40 --> Loader Class Initialized
INFO - 2024-11-04 11:50:40 --> Helper loaded: url_helper
INFO - 2024-11-04 11:50:40 --> Database Driver Class Initialized
INFO - 2024-11-04 11:50:40 --> Controller Class Initialized
INFO - 2024-11-04 11:50:40 --> Model "Item_model" initialized
INFO - 2024-11-04 11:50:40 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:50:40 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:50:40 --> Final output sent to browser
DEBUG - 2024-11-04 11:50:40 --> Total execution time: 0.0660
INFO - 2024-11-04 11:51:09 --> Config Class Initialized
INFO - 2024-11-04 11:51:09 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:51:09 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:51:09 --> Utf8 Class Initialized
INFO - 2024-11-04 11:51:09 --> URI Class Initialized
INFO - 2024-11-04 11:51:09 --> Router Class Initialized
INFO - 2024-11-04 11:51:09 --> Output Class Initialized
INFO - 2024-11-04 11:51:09 --> Security Class Initialized
DEBUG - 2024-11-04 11:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:51:09 --> Input Class Initialized
INFO - 2024-11-04 11:51:09 --> Language Class Initialized
INFO - 2024-11-04 11:51:09 --> Loader Class Initialized
INFO - 2024-11-04 11:51:09 --> Helper loaded: url_helper
INFO - 2024-11-04 11:51:09 --> Database Driver Class Initialized
INFO - 2024-11-04 11:51:09 --> Controller Class Initialized
INFO - 2024-11-04 11:51:09 --> Model "Item_model" initialized
INFO - 2024-11-04 11:51:09 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:51:09 --> Final output sent to browser
DEBUG - 2024-11-04 11:51:09 --> Total execution time: 0.0657
INFO - 2024-11-04 11:51:22 --> Config Class Initialized
INFO - 2024-11-04 11:51:22 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:51:22 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:51:22 --> Utf8 Class Initialized
INFO - 2024-11-04 11:51:22 --> URI Class Initialized
INFO - 2024-11-04 11:51:22 --> Router Class Initialized
INFO - 2024-11-04 11:51:22 --> Output Class Initialized
INFO - 2024-11-04 11:51:22 --> Security Class Initialized
DEBUG - 2024-11-04 11:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:51:22 --> Input Class Initialized
INFO - 2024-11-04 11:51:22 --> Language Class Initialized
INFO - 2024-11-04 11:51:22 --> Loader Class Initialized
INFO - 2024-11-04 11:51:22 --> Helper loaded: url_helper
INFO - 2024-11-04 11:51:22 --> Database Driver Class Initialized
INFO - 2024-11-04 11:51:22 --> Controller Class Initialized
INFO - 2024-11-04 11:51:22 --> Model "Item_model" initialized
INFO - 2024-11-04 11:51:22 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:51:22 --> Final output sent to browser
DEBUG - 2024-11-04 11:51:22 --> Total execution time: 0.0675
INFO - 2024-11-04 11:51:33 --> Config Class Initialized
INFO - 2024-11-04 11:51:33 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:51:33 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:51:33 --> Utf8 Class Initialized
INFO - 2024-11-04 11:51:33 --> URI Class Initialized
INFO - 2024-11-04 11:51:33 --> Router Class Initialized
INFO - 2024-11-04 11:51:33 --> Output Class Initialized
INFO - 2024-11-04 11:51:33 --> Security Class Initialized
DEBUG - 2024-11-04 11:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:51:33 --> Input Class Initialized
INFO - 2024-11-04 11:51:33 --> Language Class Initialized
INFO - 2024-11-04 11:51:33 --> Loader Class Initialized
INFO - 2024-11-04 11:51:33 --> Helper loaded: url_helper
INFO - 2024-11-04 11:51:33 --> Database Driver Class Initialized
INFO - 2024-11-04 11:51:33 --> Controller Class Initialized
INFO - 2024-11-04 11:51:33 --> Model "Item_model" initialized
INFO - 2024-11-04 11:51:33 --> Config Class Initialized
INFO - 2024-11-04 11:51:33 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:51:33 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:51:33 --> Utf8 Class Initialized
INFO - 2024-11-04 11:51:33 --> URI Class Initialized
INFO - 2024-11-04 11:51:33 --> Router Class Initialized
INFO - 2024-11-04 11:51:33 --> Output Class Initialized
INFO - 2024-11-04 11:51:33 --> Security Class Initialized
DEBUG - 2024-11-04 11:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:51:33 --> Input Class Initialized
INFO - 2024-11-04 11:51:33 --> Language Class Initialized
INFO - 2024-11-04 11:51:33 --> Loader Class Initialized
INFO - 2024-11-04 11:51:33 --> Helper loaded: url_helper
INFO - 2024-11-04 11:51:33 --> Database Driver Class Initialized
INFO - 2024-11-04 11:51:33 --> Controller Class Initialized
INFO - 2024-11-04 11:51:33 --> Model "Item_model" initialized
INFO - 2024-11-04 11:51:33 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:51:33 --> Final output sent to browser
DEBUG - 2024-11-04 11:51:33 --> Total execution time: 0.0654
INFO - 2024-11-04 11:51:45 --> Config Class Initialized
INFO - 2024-11-04 11:51:45 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:51:45 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:51:45 --> Utf8 Class Initialized
INFO - 2024-11-04 11:51:45 --> URI Class Initialized
INFO - 2024-11-04 11:51:45 --> Router Class Initialized
INFO - 2024-11-04 11:51:45 --> Output Class Initialized
INFO - 2024-11-04 11:51:45 --> Security Class Initialized
DEBUG - 2024-11-04 11:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:51:45 --> Input Class Initialized
INFO - 2024-11-04 11:51:45 --> Language Class Initialized
INFO - 2024-11-04 11:51:45 --> Loader Class Initialized
INFO - 2024-11-04 11:51:45 --> Helper loaded: url_helper
INFO - 2024-11-04 11:51:45 --> Database Driver Class Initialized
INFO - 2024-11-04 11:51:45 --> Controller Class Initialized
INFO - 2024-11-04 11:51:45 --> Model "Item_model" initialized
INFO - 2024-11-04 11:51:45 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:51:45 --> Final output sent to browser
DEBUG - 2024-11-04 11:51:45 --> Total execution time: 0.0676
INFO - 2024-11-04 11:51:57 --> Config Class Initialized
INFO - 2024-11-04 11:51:57 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:51:57 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:51:57 --> Utf8 Class Initialized
INFO - 2024-11-04 11:51:57 --> URI Class Initialized
INFO - 2024-11-04 11:51:57 --> Router Class Initialized
INFO - 2024-11-04 11:51:57 --> Output Class Initialized
INFO - 2024-11-04 11:51:57 --> Security Class Initialized
DEBUG - 2024-11-04 11:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:51:57 --> Input Class Initialized
INFO - 2024-11-04 11:51:57 --> Language Class Initialized
INFO - 2024-11-04 11:51:57 --> Loader Class Initialized
INFO - 2024-11-04 11:51:57 --> Helper loaded: url_helper
INFO - 2024-11-04 11:51:57 --> Database Driver Class Initialized
INFO - 2024-11-04 11:51:57 --> Controller Class Initialized
INFO - 2024-11-04 11:51:57 --> Model "Item_model" initialized
INFO - 2024-11-04 11:51:57 --> Config Class Initialized
INFO - 2024-11-04 11:51:57 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:51:57 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:51:57 --> Utf8 Class Initialized
INFO - 2024-11-04 11:51:57 --> URI Class Initialized
INFO - 2024-11-04 11:51:57 --> Router Class Initialized
INFO - 2024-11-04 11:51:57 --> Output Class Initialized
INFO - 2024-11-04 11:51:57 --> Security Class Initialized
DEBUG - 2024-11-04 11:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:51:57 --> Input Class Initialized
INFO - 2024-11-04 11:51:57 --> Language Class Initialized
INFO - 2024-11-04 11:51:57 --> Loader Class Initialized
INFO - 2024-11-04 11:51:57 --> Helper loaded: url_helper
INFO - 2024-11-04 11:51:57 --> Database Driver Class Initialized
INFO - 2024-11-04 11:51:57 --> Controller Class Initialized
INFO - 2024-11-04 11:51:57 --> Model "Item_model" initialized
INFO - 2024-11-04 11:51:57 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:51:57 --> Final output sent to browser
DEBUG - 2024-11-04 11:51:57 --> Total execution time: 0.0685
INFO - 2024-11-04 11:52:00 --> Config Class Initialized
INFO - 2024-11-04 11:52:00 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:52:00 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:52:00 --> Utf8 Class Initialized
INFO - 2024-11-04 11:52:00 --> URI Class Initialized
INFO - 2024-11-04 11:52:00 --> Router Class Initialized
INFO - 2024-11-04 11:52:00 --> Output Class Initialized
INFO - 2024-11-04 11:52:00 --> Security Class Initialized
DEBUG - 2024-11-04 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:52:00 --> Input Class Initialized
INFO - 2024-11-04 11:52:00 --> Language Class Initialized
INFO - 2024-11-04 11:52:00 --> Loader Class Initialized
INFO - 2024-11-04 11:52:00 --> Helper loaded: url_helper
INFO - 2024-11-04 11:52:00 --> Database Driver Class Initialized
INFO - 2024-11-04 11:52:00 --> Controller Class Initialized
INFO - 2024-11-04 11:52:00 --> Model "Item_model" initialized
INFO - 2024-11-04 11:52:00 --> Config Class Initialized
INFO - 2024-11-04 11:52:00 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:52:00 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:52:00 --> Utf8 Class Initialized
INFO - 2024-11-04 11:52:00 --> URI Class Initialized
INFO - 2024-11-04 11:52:00 --> Router Class Initialized
INFO - 2024-11-04 11:52:00 --> Output Class Initialized
INFO - 2024-11-04 11:52:00 --> Security Class Initialized
DEBUG - 2024-11-04 11:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:52:00 --> Input Class Initialized
INFO - 2024-11-04 11:52:00 --> Language Class Initialized
INFO - 2024-11-04 11:52:00 --> Loader Class Initialized
INFO - 2024-11-04 11:52:00 --> Helper loaded: url_helper
INFO - 2024-11-04 11:52:00 --> Database Driver Class Initialized
INFO - 2024-11-04 11:52:00 --> Controller Class Initialized
INFO - 2024-11-04 11:52:00 --> Model "Item_model" initialized
INFO - 2024-11-04 11:52:00 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:52:00 --> Final output sent to browser
DEBUG - 2024-11-04 11:52:00 --> Total execution time: 0.0751
INFO - 2024-11-04 11:52:25 --> Config Class Initialized
INFO - 2024-11-04 11:52:25 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:52:25 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:52:25 --> Utf8 Class Initialized
INFO - 2024-11-04 11:52:25 --> URI Class Initialized
INFO - 2024-11-04 11:52:25 --> Router Class Initialized
INFO - 2024-11-04 11:52:25 --> Output Class Initialized
INFO - 2024-11-04 11:52:25 --> Security Class Initialized
DEBUG - 2024-11-04 11:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:52:25 --> Input Class Initialized
INFO - 2024-11-04 11:52:25 --> Language Class Initialized
INFO - 2024-11-04 11:52:25 --> Loader Class Initialized
INFO - 2024-11-04 11:52:25 --> Helper loaded: url_helper
INFO - 2024-11-04 11:52:25 --> Database Driver Class Initialized
INFO - 2024-11-04 11:52:25 --> Controller Class Initialized
INFO - 2024-11-04 11:52:25 --> Model "Item_model" initialized
INFO - 2024-11-04 11:52:25 --> Config Class Initialized
INFO - 2024-11-04 11:52:25 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:52:25 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:52:25 --> Utf8 Class Initialized
INFO - 2024-11-04 11:52:25 --> URI Class Initialized
INFO - 2024-11-04 11:52:25 --> Router Class Initialized
INFO - 2024-11-04 11:52:25 --> Output Class Initialized
INFO - 2024-11-04 11:52:25 --> Security Class Initialized
DEBUG - 2024-11-04 11:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:52:25 --> Input Class Initialized
INFO - 2024-11-04 11:52:25 --> Language Class Initialized
INFO - 2024-11-04 11:52:25 --> Loader Class Initialized
INFO - 2024-11-04 11:52:25 --> Helper loaded: url_helper
INFO - 2024-11-04 11:52:25 --> Database Driver Class Initialized
INFO - 2024-11-04 11:52:25 --> Controller Class Initialized
INFO - 2024-11-04 11:52:25 --> Model "Item_model" initialized
INFO - 2024-11-04 11:52:25 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:52:25 --> Final output sent to browser
DEBUG - 2024-11-04 11:52:25 --> Total execution time: 0.0635
INFO - 2024-11-04 11:52:33 --> Config Class Initialized
INFO - 2024-11-04 11:52:33 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:52:33 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:52:33 --> Utf8 Class Initialized
INFO - 2024-11-04 11:52:33 --> URI Class Initialized
INFO - 2024-11-04 11:52:33 --> Router Class Initialized
INFO - 2024-11-04 11:52:33 --> Output Class Initialized
INFO - 2024-11-04 11:52:33 --> Security Class Initialized
DEBUG - 2024-11-04 11:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:52:33 --> Input Class Initialized
INFO - 2024-11-04 11:52:33 --> Language Class Initialized
INFO - 2024-11-04 11:52:33 --> Loader Class Initialized
INFO - 2024-11-04 11:52:33 --> Helper loaded: url_helper
INFO - 2024-11-04 11:52:33 --> Database Driver Class Initialized
INFO - 2024-11-04 11:52:33 --> Controller Class Initialized
INFO - 2024-11-04 11:52:33 --> Model "Item_model" initialized
INFO - 2024-11-04 11:52:33 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 11:52:33 --> Final output sent to browser
DEBUG - 2024-11-04 11:52:33 --> Total execution time: 0.0640
INFO - 2024-11-04 11:52:43 --> Config Class Initialized
INFO - 2024-11-04 11:52:43 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:52:43 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:52:43 --> Utf8 Class Initialized
INFO - 2024-11-04 11:52:43 --> URI Class Initialized
INFO - 2024-11-04 11:52:43 --> Router Class Initialized
INFO - 2024-11-04 11:52:43 --> Output Class Initialized
INFO - 2024-11-04 11:52:43 --> Security Class Initialized
DEBUG - 2024-11-04 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:52:43 --> Input Class Initialized
INFO - 2024-11-04 11:52:43 --> Language Class Initialized
INFO - 2024-11-04 11:52:43 --> Loader Class Initialized
INFO - 2024-11-04 11:52:43 --> Helper loaded: url_helper
INFO - 2024-11-04 11:52:43 --> Database Driver Class Initialized
INFO - 2024-11-04 11:52:43 --> Controller Class Initialized
INFO - 2024-11-04 11:52:43 --> Model "Item_model" initialized
INFO - 2024-11-04 11:52:43 --> Config Class Initialized
INFO - 2024-11-04 11:52:43 --> Hooks Class Initialized
DEBUG - 2024-11-04 11:52:43 --> UTF-8 Support Enabled
INFO - 2024-11-04 11:52:43 --> Utf8 Class Initialized
INFO - 2024-11-04 11:52:43 --> URI Class Initialized
INFO - 2024-11-04 11:52:43 --> Router Class Initialized
INFO - 2024-11-04 11:52:43 --> Output Class Initialized
INFO - 2024-11-04 11:52:43 --> Security Class Initialized
DEBUG - 2024-11-04 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 11:52:43 --> Input Class Initialized
INFO - 2024-11-04 11:52:43 --> Language Class Initialized
INFO - 2024-11-04 11:52:43 --> Loader Class Initialized
INFO - 2024-11-04 11:52:43 --> Helper loaded: url_helper
INFO - 2024-11-04 11:52:43 --> Database Driver Class Initialized
INFO - 2024-11-04 11:52:43 --> Controller Class Initialized
INFO - 2024-11-04 11:52:43 --> Model "Item_model" initialized
INFO - 2024-11-04 11:52:43 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 11:52:43 --> Final output sent to browser
DEBUG - 2024-11-04 11:52:43 --> Total execution time: 0.0556
INFO - 2024-11-04 12:03:08 --> Config Class Initialized
INFO - 2024-11-04 12:03:08 --> Hooks Class Initialized
DEBUG - 2024-11-04 12:03:08 --> UTF-8 Support Enabled
INFO - 2024-11-04 12:03:08 --> Utf8 Class Initialized
INFO - 2024-11-04 12:03:08 --> URI Class Initialized
INFO - 2024-11-04 12:03:08 --> Router Class Initialized
INFO - 2024-11-04 12:03:08 --> Output Class Initialized
INFO - 2024-11-04 12:03:08 --> Security Class Initialized
DEBUG - 2024-11-04 12:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 12:03:08 --> Input Class Initialized
INFO - 2024-11-04 12:03:08 --> Language Class Initialized
INFO - 2024-11-04 12:03:08 --> Loader Class Initialized
INFO - 2024-11-04 12:03:08 --> Helper loaded: url_helper
INFO - 2024-11-04 12:03:08 --> Database Driver Class Initialized
INFO - 2024-11-04 12:03:08 --> Controller Class Initialized
INFO - 2024-11-04 12:03:08 --> Model "Item_model" initialized
INFO - 2024-11-04 12:03:08 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 12:03:08 --> Final output sent to browser
DEBUG - 2024-11-04 12:03:08 --> Total execution time: 0.0590
INFO - 2024-11-04 13:32:34 --> Config Class Initialized
INFO - 2024-11-04 13:32:34 --> Hooks Class Initialized
DEBUG - 2024-11-04 13:32:34 --> UTF-8 Support Enabled
INFO - 2024-11-04 13:32:34 --> Utf8 Class Initialized
INFO - 2024-11-04 13:32:34 --> URI Class Initialized
INFO - 2024-11-04 13:32:34 --> Router Class Initialized
INFO - 2024-11-04 13:32:34 --> Output Class Initialized
INFO - 2024-11-04 13:32:34 --> Security Class Initialized
DEBUG - 2024-11-04 13:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 13:32:34 --> Input Class Initialized
INFO - 2024-11-04 13:32:34 --> Language Class Initialized
INFO - 2024-11-04 13:32:34 --> Loader Class Initialized
INFO - 2024-11-04 13:32:34 --> Helper loaded: url_helper
INFO - 2024-11-04 13:32:34 --> Database Driver Class Initialized
INFO - 2024-11-04 13:32:34 --> Controller Class Initialized
INFO - 2024-11-04 13:32:34 --> Model "Item_model" initialized
INFO - 2024-11-04 13:32:34 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 13:32:34 --> Final output sent to browser
DEBUG - 2024-11-04 13:32:34 --> Total execution time: 0.1603
INFO - 2024-11-04 13:32:40 --> Config Class Initialized
INFO - 2024-11-04 13:32:40 --> Hooks Class Initialized
DEBUG - 2024-11-04 13:32:40 --> UTF-8 Support Enabled
INFO - 2024-11-04 13:32:40 --> Utf8 Class Initialized
INFO - 2024-11-04 13:32:40 --> URI Class Initialized
INFO - 2024-11-04 13:32:40 --> Router Class Initialized
INFO - 2024-11-04 13:32:40 --> Output Class Initialized
INFO - 2024-11-04 13:32:40 --> Security Class Initialized
DEBUG - 2024-11-04 13:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 13:32:40 --> Input Class Initialized
INFO - 2024-11-04 13:32:40 --> Language Class Initialized
INFO - 2024-11-04 13:32:40 --> Loader Class Initialized
INFO - 2024-11-04 13:32:40 --> Helper loaded: url_helper
INFO - 2024-11-04 13:32:40 --> Database Driver Class Initialized
INFO - 2024-11-04 13:32:40 --> Controller Class Initialized
INFO - 2024-11-04 13:32:40 --> Model "Item_model" initialized
INFO - 2024-11-04 13:32:40 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 13:32:40 --> Final output sent to browser
DEBUG - 2024-11-04 13:32:40 --> Total execution time: 0.1288
INFO - 2024-11-04 13:34:00 --> Config Class Initialized
INFO - 2024-11-04 13:34:00 --> Hooks Class Initialized
DEBUG - 2024-11-04 13:34:00 --> UTF-8 Support Enabled
INFO - 2024-11-04 13:34:00 --> Utf8 Class Initialized
INFO - 2024-11-04 13:34:00 --> URI Class Initialized
INFO - 2024-11-04 13:34:00 --> Router Class Initialized
INFO - 2024-11-04 13:34:00 --> Output Class Initialized
INFO - 2024-11-04 13:34:00 --> Security Class Initialized
DEBUG - 2024-11-04 13:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 13:34:00 --> Input Class Initialized
INFO - 2024-11-04 13:34:00 --> Language Class Initialized
INFO - 2024-11-04 13:34:00 --> Loader Class Initialized
INFO - 2024-11-04 13:34:00 --> Helper loaded: url_helper
INFO - 2024-11-04 13:34:00 --> Database Driver Class Initialized
INFO - 2024-11-04 13:34:00 --> Controller Class Initialized
INFO - 2024-11-04 13:34:00 --> Model "Item_model" initialized
ERROR - 2024-11-04 13:34:00 --> Severity: Notice --> Undefined index: apellido C:\wamp64\www\crud_1\application\views\items\edit.php 24
ERROR - 2024-11-04 13:34:00 --> Severity: Notice --> Undefined index: cedula C:\wamp64\www\crud_1\application\views\items\edit.php 28
INFO - 2024-11-04 13:34:00 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 13:34:00 --> Final output sent to browser
DEBUG - 2024-11-04 13:34:00 --> Total execution time: 0.3254
INFO - 2024-11-04 14:50:16 --> Config Class Initialized
INFO - 2024-11-04 14:50:16 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:50:16 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:50:16 --> Utf8 Class Initialized
INFO - 2024-11-04 14:50:16 --> URI Class Initialized
INFO - 2024-11-04 14:50:16 --> Router Class Initialized
INFO - 2024-11-04 14:50:16 --> Output Class Initialized
INFO - 2024-11-04 14:50:16 --> Security Class Initialized
DEBUG - 2024-11-04 14:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:50:16 --> Input Class Initialized
INFO - 2024-11-04 14:50:16 --> Language Class Initialized
INFO - 2024-11-04 14:50:16 --> Loader Class Initialized
INFO - 2024-11-04 14:50:16 --> Helper loaded: url_helper
INFO - 2024-11-04 14:50:16 --> Database Driver Class Initialized
INFO - 2024-11-04 14:50:16 --> Controller Class Initialized
INFO - 2024-11-04 14:50:16 --> Model "Item_model" initialized
ERROR - 2024-11-04 14:50:16 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 33
ERROR - 2024-11-04 14:50:16 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 56
INFO - 2024-11-04 14:50:16 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:50:16 --> Final output sent to browser
DEBUG - 2024-11-04 14:50:16 --> Total execution time: 0.2594
INFO - 2024-11-04 14:50:41 --> Config Class Initialized
INFO - 2024-11-04 14:50:41 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:50:41 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:50:41 --> Utf8 Class Initialized
INFO - 2024-11-04 14:50:41 --> URI Class Initialized
INFO - 2024-11-04 14:50:41 --> Router Class Initialized
INFO - 2024-11-04 14:50:41 --> Output Class Initialized
INFO - 2024-11-04 14:50:41 --> Security Class Initialized
DEBUG - 2024-11-04 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:50:41 --> Input Class Initialized
INFO - 2024-11-04 14:50:41 --> Language Class Initialized
INFO - 2024-11-04 14:50:41 --> Loader Class Initialized
INFO - 2024-11-04 14:50:41 --> Helper loaded: url_helper
INFO - 2024-11-04 14:50:41 --> Database Driver Class Initialized
INFO - 2024-11-04 14:50:41 --> Controller Class Initialized
INFO - 2024-11-04 14:50:41 --> Model "Item_model" initialized
ERROR - 2024-11-04 14:50:42 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 33
ERROR - 2024-11-04 14:50:42 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 56
INFO - 2024-11-04 14:50:42 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:50:42 --> Final output sent to browser
DEBUG - 2024-11-04 14:50:42 --> Total execution time: 0.2647
INFO - 2024-11-04 14:51:16 --> Config Class Initialized
INFO - 2024-11-04 14:51:16 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:51:16 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:51:16 --> Utf8 Class Initialized
INFO - 2024-11-04 14:51:16 --> URI Class Initialized
INFO - 2024-11-04 14:51:16 --> Router Class Initialized
INFO - 2024-11-04 14:51:16 --> Output Class Initialized
INFO - 2024-11-04 14:51:16 --> Security Class Initialized
DEBUG - 2024-11-04 14:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:51:16 --> Input Class Initialized
INFO - 2024-11-04 14:51:16 --> Language Class Initialized
INFO - 2024-11-04 14:51:16 --> Loader Class Initialized
INFO - 2024-11-04 14:51:16 --> Helper loaded: url_helper
INFO - 2024-11-04 14:51:16 --> Database Driver Class Initialized
INFO - 2024-11-04 14:51:16 --> Controller Class Initialized
INFO - 2024-11-04 14:51:16 --> Model "Item_model" initialized
ERROR - 2024-11-04 14:51:16 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 33
ERROR - 2024-11-04 14:51:16 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 56
INFO - 2024-11-04 14:51:16 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:51:16 --> Final output sent to browser
DEBUG - 2024-11-04 14:51:16 --> Total execution time: 0.2747
INFO - 2024-11-04 14:51:29 --> Config Class Initialized
INFO - 2024-11-04 14:51:29 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:51:29 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:51:29 --> Utf8 Class Initialized
INFO - 2024-11-04 14:51:29 --> URI Class Initialized
INFO - 2024-11-04 14:51:29 --> Router Class Initialized
INFO - 2024-11-04 14:51:29 --> Output Class Initialized
INFO - 2024-11-04 14:51:29 --> Security Class Initialized
DEBUG - 2024-11-04 14:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:51:29 --> Input Class Initialized
INFO - 2024-11-04 14:51:29 --> Language Class Initialized
INFO - 2024-11-04 14:51:29 --> Loader Class Initialized
INFO - 2024-11-04 14:51:29 --> Helper loaded: url_helper
INFO - 2024-11-04 14:51:29 --> Database Driver Class Initialized
INFO - 2024-11-04 14:51:29 --> Controller Class Initialized
INFO - 2024-11-04 14:51:29 --> Model "Item_model" initialized
ERROR - 2024-11-04 14:51:29 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 33
ERROR - 2024-11-04 14:51:29 --> Severity: Notice --> Undefined index: description C:\wamp64\www\crud_1\application\views\items\edit.php 56
INFO - 2024-11-04 14:51:29 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:51:29 --> Final output sent to browser
DEBUG - 2024-11-04 14:51:29 --> Total execution time: 0.1659
INFO - 2024-11-04 14:51:40 --> Config Class Initialized
INFO - 2024-11-04 14:51:40 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:51:40 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:51:40 --> Utf8 Class Initialized
INFO - 2024-11-04 14:51:40 --> URI Class Initialized
DEBUG - 2024-11-04 14:51:40 --> No URI present. Default controller set.
INFO - 2024-11-04 14:51:40 --> Router Class Initialized
INFO - 2024-11-04 14:51:40 --> Output Class Initialized
INFO - 2024-11-04 14:51:40 --> Security Class Initialized
DEBUG - 2024-11-04 14:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:51:40 --> Input Class Initialized
INFO - 2024-11-04 14:51:41 --> Language Class Initialized
INFO - 2024-11-04 14:51:41 --> Loader Class Initialized
INFO - 2024-11-04 14:51:41 --> Helper loaded: url_helper
INFO - 2024-11-04 14:51:41 --> Database Driver Class Initialized
INFO - 2024-11-04 14:51:41 --> Controller Class Initialized
INFO - 2024-11-04 14:51:41 --> Model "Item_model" initialized
INFO - 2024-11-04 14:51:41 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:51:41 --> Final output sent to browser
DEBUG - 2024-11-04 14:51:41 --> Total execution time: 0.2334
INFO - 2024-11-04 14:52:50 --> Config Class Initialized
INFO - 2024-11-04 14:52:50 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:52:50 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:52:50 --> Utf8 Class Initialized
INFO - 2024-11-04 14:52:50 --> URI Class Initialized
DEBUG - 2024-11-04 14:52:50 --> No URI present. Default controller set.
INFO - 2024-11-04 14:52:50 --> Router Class Initialized
INFO - 2024-11-04 14:52:50 --> Output Class Initialized
INFO - 2024-11-04 14:52:50 --> Security Class Initialized
DEBUG - 2024-11-04 14:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:52:50 --> Input Class Initialized
INFO - 2024-11-04 14:52:50 --> Language Class Initialized
INFO - 2024-11-04 14:52:50 --> Loader Class Initialized
INFO - 2024-11-04 14:52:50 --> Helper loaded: url_helper
INFO - 2024-11-04 14:52:50 --> Database Driver Class Initialized
INFO - 2024-11-04 14:52:50 --> Controller Class Initialized
INFO - 2024-11-04 14:52:50 --> Model "Item_model" initialized
INFO - 2024-11-04 14:52:50 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:52:50 --> Final output sent to browser
DEBUG - 2024-11-04 14:52:50 --> Total execution time: 0.2236
INFO - 2024-11-04 14:52:53 --> Config Class Initialized
INFO - 2024-11-04 14:52:53 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:52:53 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:52:53 --> Utf8 Class Initialized
INFO - 2024-11-04 14:52:53 --> URI Class Initialized
INFO - 2024-11-04 14:52:53 --> Router Class Initialized
INFO - 2024-11-04 14:52:53 --> Output Class Initialized
INFO - 2024-11-04 14:52:53 --> Security Class Initialized
DEBUG - 2024-11-04 14:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:52:53 --> Input Class Initialized
INFO - 2024-11-04 14:52:53 --> Language Class Initialized
INFO - 2024-11-04 14:52:53 --> Loader Class Initialized
INFO - 2024-11-04 14:52:53 --> Helper loaded: url_helper
INFO - 2024-11-04 14:52:53 --> Database Driver Class Initialized
INFO - 2024-11-04 14:52:53 --> Controller Class Initialized
INFO - 2024-11-04 14:52:53 --> Model "Item_model" initialized
INFO - 2024-11-04 14:52:53 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:52:53 --> Final output sent to browser
DEBUG - 2024-11-04 14:52:53 --> Total execution time: 0.1612
INFO - 2024-11-04 14:53:02 --> Config Class Initialized
INFO - 2024-11-04 14:53:02 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:02 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:02 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:02 --> URI Class Initialized
INFO - 2024-11-04 14:53:02 --> Router Class Initialized
INFO - 2024-11-04 14:53:02 --> Output Class Initialized
INFO - 2024-11-04 14:53:02 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:02 --> Input Class Initialized
INFO - 2024-11-04 14:53:02 --> Language Class Initialized
INFO - 2024-11-04 14:53:02 --> Loader Class Initialized
INFO - 2024-11-04 14:53:02 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:02 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:02 --> Controller Class Initialized
INFO - 2024-11-04 14:53:02 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:02 --> Config Class Initialized
INFO - 2024-11-04 14:53:02 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:02 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:02 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:02 --> URI Class Initialized
INFO - 2024-11-04 14:53:02 --> Router Class Initialized
INFO - 2024-11-04 14:53:02 --> Output Class Initialized
INFO - 2024-11-04 14:53:02 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:02 --> Input Class Initialized
INFO - 2024-11-04 14:53:02 --> Language Class Initialized
INFO - 2024-11-04 14:53:02 --> Loader Class Initialized
INFO - 2024-11-04 14:53:02 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:02 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:02 --> Controller Class Initialized
INFO - 2024-11-04 14:53:02 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:02 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:53:02 --> Final output sent to browser
DEBUG - 2024-11-04 14:53:02 --> Total execution time: 0.2245
INFO - 2024-11-04 14:53:07 --> Config Class Initialized
INFO - 2024-11-04 14:53:07 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:07 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:07 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:07 --> URI Class Initialized
INFO - 2024-11-04 14:53:07 --> Router Class Initialized
INFO - 2024-11-04 14:53:07 --> Output Class Initialized
INFO - 2024-11-04 14:53:07 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:07 --> Input Class Initialized
INFO - 2024-11-04 14:53:07 --> Language Class Initialized
INFO - 2024-11-04 14:53:07 --> Loader Class Initialized
INFO - 2024-11-04 14:53:07 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:07 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:07 --> Controller Class Initialized
INFO - 2024-11-04 14:53:07 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:07 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:53:07 --> Final output sent to browser
DEBUG - 2024-11-04 14:53:07 --> Total execution time: 0.1473
INFO - 2024-11-04 14:53:18 --> Config Class Initialized
INFO - 2024-11-04 14:53:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:18 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:18 --> URI Class Initialized
INFO - 2024-11-04 14:53:18 --> Router Class Initialized
INFO - 2024-11-04 14:53:18 --> Output Class Initialized
INFO - 2024-11-04 14:53:18 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:18 --> Input Class Initialized
INFO - 2024-11-04 14:53:18 --> Language Class Initialized
INFO - 2024-11-04 14:53:18 --> Loader Class Initialized
INFO - 2024-11-04 14:53:18 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:18 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:18 --> Controller Class Initialized
INFO - 2024-11-04 14:53:18 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:18 --> Config Class Initialized
INFO - 2024-11-04 14:53:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:18 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:18 --> URI Class Initialized
INFO - 2024-11-04 14:53:18 --> Router Class Initialized
INFO - 2024-11-04 14:53:18 --> Output Class Initialized
INFO - 2024-11-04 14:53:18 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:18 --> Input Class Initialized
INFO - 2024-11-04 14:53:18 --> Language Class Initialized
INFO - 2024-11-04 14:53:18 --> Loader Class Initialized
INFO - 2024-11-04 14:53:18 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:18 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:18 --> Controller Class Initialized
INFO - 2024-11-04 14:53:18 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:18 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:53:18 --> Final output sent to browser
DEBUG - 2024-11-04 14:53:18 --> Total execution time: 0.2288
INFO - 2024-11-04 14:53:45 --> Config Class Initialized
INFO - 2024-11-04 14:53:45 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:45 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:45 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:45 --> URI Class Initialized
INFO - 2024-11-04 14:53:45 --> Router Class Initialized
INFO - 2024-11-04 14:53:45 --> Output Class Initialized
INFO - 2024-11-04 14:53:45 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:45 --> Input Class Initialized
INFO - 2024-11-04 14:53:45 --> Language Class Initialized
INFO - 2024-11-04 14:53:45 --> Loader Class Initialized
INFO - 2024-11-04 14:53:45 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:45 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:45 --> Controller Class Initialized
INFO - 2024-11-04 14:53:45 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:45 --> Config Class Initialized
INFO - 2024-11-04 14:53:45 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:45 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:45 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:45 --> URI Class Initialized
INFO - 2024-11-04 14:53:45 --> Router Class Initialized
INFO - 2024-11-04 14:53:45 --> Output Class Initialized
INFO - 2024-11-04 14:53:45 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:45 --> Input Class Initialized
INFO - 2024-11-04 14:53:45 --> Language Class Initialized
INFO - 2024-11-04 14:53:45 --> Loader Class Initialized
INFO - 2024-11-04 14:53:45 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:45 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:45 --> Controller Class Initialized
INFO - 2024-11-04 14:53:45 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:46 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:53:46 --> Final output sent to browser
DEBUG - 2024-11-04 14:53:46 --> Total execution time: 0.2322
INFO - 2024-11-04 14:53:58 --> Config Class Initialized
INFO - 2024-11-04 14:53:58 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:53:58 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:53:58 --> Utf8 Class Initialized
INFO - 2024-11-04 14:53:58 --> URI Class Initialized
INFO - 2024-11-04 14:53:58 --> Router Class Initialized
INFO - 2024-11-04 14:53:58 --> Output Class Initialized
INFO - 2024-11-04 14:53:58 --> Security Class Initialized
DEBUG - 2024-11-04 14:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:53:58 --> Input Class Initialized
INFO - 2024-11-04 14:53:58 --> Language Class Initialized
INFO - 2024-11-04 14:53:58 --> Loader Class Initialized
INFO - 2024-11-04 14:53:58 --> Helper loaded: url_helper
INFO - 2024-11-04 14:53:59 --> Database Driver Class Initialized
INFO - 2024-11-04 14:53:59 --> Controller Class Initialized
INFO - 2024-11-04 14:53:59 --> Model "Item_model" initialized
INFO - 2024-11-04 14:53:59 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:53:59 --> Final output sent to browser
DEBUG - 2024-11-04 14:53:59 --> Total execution time: 0.1475
INFO - 2024-11-04 14:54:13 --> Config Class Initialized
INFO - 2024-11-04 14:54:13 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:54:13 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:54:13 --> Utf8 Class Initialized
INFO - 2024-11-04 14:54:13 --> URI Class Initialized
INFO - 2024-11-04 14:54:13 --> Router Class Initialized
INFO - 2024-11-04 14:54:13 --> Output Class Initialized
INFO - 2024-11-04 14:54:13 --> Security Class Initialized
DEBUG - 2024-11-04 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:54:13 --> Input Class Initialized
INFO - 2024-11-04 14:54:13 --> Language Class Initialized
INFO - 2024-11-04 14:54:13 --> Loader Class Initialized
INFO - 2024-11-04 14:54:13 --> Helper loaded: url_helper
INFO - 2024-11-04 14:54:13 --> Database Driver Class Initialized
INFO - 2024-11-04 14:54:13 --> Controller Class Initialized
INFO - 2024-11-04 14:54:13 --> Model "Item_model" initialized
INFO - 2024-11-04 14:54:13 --> Config Class Initialized
INFO - 2024-11-04 14:54:13 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:54:13 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:54:13 --> Utf8 Class Initialized
INFO - 2024-11-04 14:54:13 --> URI Class Initialized
INFO - 2024-11-04 14:54:13 --> Router Class Initialized
INFO - 2024-11-04 14:54:13 --> Output Class Initialized
INFO - 2024-11-04 14:54:13 --> Security Class Initialized
DEBUG - 2024-11-04 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:54:13 --> Input Class Initialized
INFO - 2024-11-04 14:54:13 --> Language Class Initialized
INFO - 2024-11-04 14:54:13 --> Loader Class Initialized
INFO - 2024-11-04 14:54:13 --> Helper loaded: url_helper
INFO - 2024-11-04 14:54:13 --> Database Driver Class Initialized
INFO - 2024-11-04 14:54:13 --> Controller Class Initialized
INFO - 2024-11-04 14:54:13 --> Model "Item_model" initialized
INFO - 2024-11-04 14:54:13 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:54:13 --> Final output sent to browser
DEBUG - 2024-11-04 14:54:13 --> Total execution time: 0.1417
INFO - 2024-11-04 14:54:18 --> Config Class Initialized
INFO - 2024-11-04 14:54:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:54:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:54:18 --> Utf8 Class Initialized
INFO - 2024-11-04 14:54:18 --> URI Class Initialized
INFO - 2024-11-04 14:54:18 --> Router Class Initialized
INFO - 2024-11-04 14:54:18 --> Output Class Initialized
INFO - 2024-11-04 14:54:18 --> Security Class Initialized
DEBUG - 2024-11-04 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:54:18 --> Input Class Initialized
INFO - 2024-11-04 14:54:18 --> Language Class Initialized
INFO - 2024-11-04 14:54:18 --> Loader Class Initialized
INFO - 2024-11-04 14:54:18 --> Helper loaded: url_helper
INFO - 2024-11-04 14:54:18 --> Database Driver Class Initialized
INFO - 2024-11-04 14:54:18 --> Controller Class Initialized
INFO - 2024-11-04 14:54:18 --> Model "Item_model" initialized
INFO - 2024-11-04 14:54:18 --> Config Class Initialized
INFO - 2024-11-04 14:54:18 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:54:18 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:54:18 --> Utf8 Class Initialized
INFO - 2024-11-04 14:54:18 --> URI Class Initialized
INFO - 2024-11-04 14:54:18 --> Router Class Initialized
INFO - 2024-11-04 14:54:18 --> Output Class Initialized
INFO - 2024-11-04 14:54:18 --> Security Class Initialized
DEBUG - 2024-11-04 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:54:18 --> Input Class Initialized
INFO - 2024-11-04 14:54:18 --> Language Class Initialized
INFO - 2024-11-04 14:54:18 --> Loader Class Initialized
INFO - 2024-11-04 14:54:18 --> Helper loaded: url_helper
INFO - 2024-11-04 14:54:18 --> Database Driver Class Initialized
INFO - 2024-11-04 14:54:18 --> Controller Class Initialized
INFO - 2024-11-04 14:54:18 --> Model "Item_model" initialized
INFO - 2024-11-04 14:54:18 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:54:18 --> Final output sent to browser
DEBUG - 2024-11-04 14:54:18 --> Total execution time: 0.1356
INFO - 2024-11-04 14:54:21 --> Config Class Initialized
INFO - 2024-11-04 14:54:21 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:54:21 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:54:21 --> Utf8 Class Initialized
INFO - 2024-11-04 14:54:21 --> URI Class Initialized
INFO - 2024-11-04 14:54:21 --> Router Class Initialized
INFO - 2024-11-04 14:54:21 --> Output Class Initialized
INFO - 2024-11-04 14:54:21 --> Security Class Initialized
DEBUG - 2024-11-04 14:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:54:21 --> Input Class Initialized
INFO - 2024-11-04 14:54:21 --> Language Class Initialized
INFO - 2024-11-04 14:54:21 --> Loader Class Initialized
INFO - 2024-11-04 14:54:21 --> Helper loaded: url_helper
INFO - 2024-11-04 14:54:21 --> Database Driver Class Initialized
INFO - 2024-11-04 14:54:21 --> Controller Class Initialized
INFO - 2024-11-04 14:54:21 --> Model "Item_model" initialized
INFO - 2024-11-04 14:54:21 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-04 14:54:21 --> Final output sent to browser
DEBUG - 2024-11-04 14:54:21 --> Total execution time: 0.1512
INFO - 2024-11-04 14:54:23 --> Config Class Initialized
INFO - 2024-11-04 14:54:23 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:54:23 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:54:23 --> Utf8 Class Initialized
INFO - 2024-11-04 14:54:23 --> URI Class Initialized
INFO - 2024-11-04 14:54:23 --> Router Class Initialized
INFO - 2024-11-04 14:54:23 --> Output Class Initialized
INFO - 2024-11-04 14:54:23 --> Security Class Initialized
DEBUG - 2024-11-04 14:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:54:23 --> Input Class Initialized
INFO - 2024-11-04 14:54:23 --> Language Class Initialized
INFO - 2024-11-04 14:54:23 --> Loader Class Initialized
INFO - 2024-11-04 14:54:23 --> Helper loaded: url_helper
INFO - 2024-11-04 14:54:23 --> Database Driver Class Initialized
INFO - 2024-11-04 14:54:23 --> Controller Class Initialized
INFO - 2024-11-04 14:54:23 --> Model "Item_model" initialized
INFO - 2024-11-04 14:54:23 --> Config Class Initialized
INFO - 2024-11-04 14:54:23 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:54:23 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:54:24 --> Utf8 Class Initialized
INFO - 2024-11-04 14:54:24 --> URI Class Initialized
INFO - 2024-11-04 14:54:24 --> Router Class Initialized
INFO - 2024-11-04 14:54:24 --> Output Class Initialized
INFO - 2024-11-04 14:54:24 --> Security Class Initialized
DEBUG - 2024-11-04 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:54:24 --> Input Class Initialized
INFO - 2024-11-04 14:54:24 --> Language Class Initialized
INFO - 2024-11-04 14:54:24 --> Loader Class Initialized
INFO - 2024-11-04 14:54:24 --> Helper loaded: url_helper
INFO - 2024-11-04 14:54:24 --> Database Driver Class Initialized
INFO - 2024-11-04 14:54:24 --> Controller Class Initialized
INFO - 2024-11-04 14:54:24 --> Model "Item_model" initialized
INFO - 2024-11-04 14:54:24 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:54:24 --> Final output sent to browser
DEBUG - 2024-11-04 14:54:24 --> Total execution time: 0.2231
INFO - 2024-11-04 14:55:46 --> Config Class Initialized
INFO - 2024-11-04 14:55:46 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:55:46 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:55:46 --> Utf8 Class Initialized
INFO - 2024-11-04 14:55:46 --> URI Class Initialized
INFO - 2024-11-04 14:55:46 --> Router Class Initialized
INFO - 2024-11-04 14:55:46 --> Output Class Initialized
INFO - 2024-11-04 14:55:46 --> Security Class Initialized
DEBUG - 2024-11-04 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:55:46 --> Input Class Initialized
INFO - 2024-11-04 14:55:46 --> Language Class Initialized
INFO - 2024-11-04 14:55:46 --> Loader Class Initialized
INFO - 2024-11-04 14:55:46 --> Helper loaded: url_helper
INFO - 2024-11-04 14:55:46 --> Database Driver Class Initialized
INFO - 2024-11-04 14:55:46 --> Controller Class Initialized
INFO - 2024-11-04 14:55:46 --> Model "Item_model" initialized
INFO - 2024-11-04 14:55:46 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:55:46 --> Final output sent to browser
DEBUG - 2024-11-04 14:55:46 --> Total execution time: 0.1436
INFO - 2024-11-04 14:56:36 --> Config Class Initialized
INFO - 2024-11-04 14:56:36 --> Hooks Class Initialized
DEBUG - 2024-11-04 14:56:36 --> UTF-8 Support Enabled
INFO - 2024-11-04 14:56:36 --> Utf8 Class Initialized
INFO - 2024-11-04 14:56:36 --> URI Class Initialized
INFO - 2024-11-04 14:56:36 --> Router Class Initialized
INFO - 2024-11-04 14:56:36 --> Output Class Initialized
INFO - 2024-11-04 14:56:36 --> Security Class Initialized
DEBUG - 2024-11-04 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 14:56:36 --> Input Class Initialized
INFO - 2024-11-04 14:56:36 --> Language Class Initialized
INFO - 2024-11-04 14:56:36 --> Loader Class Initialized
INFO - 2024-11-04 14:56:36 --> Helper loaded: url_helper
INFO - 2024-11-04 14:56:36 --> Database Driver Class Initialized
INFO - 2024-11-04 14:56:36 --> Controller Class Initialized
INFO - 2024-11-04 14:56:36 --> Model "Item_model" initialized
INFO - 2024-11-04 14:56:36 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-04 14:56:36 --> Final output sent to browser
DEBUG - 2024-11-04 14:56:36 --> Total execution time: 0.1247
