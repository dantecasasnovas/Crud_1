<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-03 21:14:02 --> Config Class Initialized
INFO - 2024-11-03 21:14:02 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:14:02 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:14:02 --> Utf8 Class Initialized
INFO - 2024-11-03 21:14:02 --> URI Class Initialized
DEBUG - 2024-11-03 21:14:02 --> No URI present. Default controller set.
INFO - 2024-11-03 21:14:02 --> Router Class Initialized
INFO - 2024-11-03 21:14:02 --> Output Class Initialized
INFO - 2024-11-03 21:14:02 --> Security Class Initialized
DEBUG - 2024-11-03 21:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:14:02 --> Input Class Initialized
INFO - 2024-11-03 21:14:02 --> Language Class Initialized
INFO - 2024-11-03 21:14:02 --> Loader Class Initialized
INFO - 2024-11-03 21:14:02 --> Helper loaded: url_helper
INFO - 2024-11-03 21:14:02 --> Controller Class Initialized
INFO - 2024-11-03 21:14:02 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 21:14:02 --> Final output sent to browser
DEBUG - 2024-11-03 21:14:02 --> Total execution time: 0.1457
INFO - 2024-11-03 21:14:02 --> Config Class Initialized
INFO - 2024-11-03 21:14:02 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:14:02 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:14:02 --> Utf8 Class Initialized
INFO - 2024-11-03 21:14:02 --> URI Class Initialized
INFO - 2024-11-03 21:14:02 --> Router Class Initialized
INFO - 2024-11-03 21:14:02 --> Output Class Initialized
INFO - 2024-11-03 21:14:02 --> Security Class Initialized
DEBUG - 2024-11-03 21:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:14:02 --> Input Class Initialized
INFO - 2024-11-03 21:14:02 --> Language Class Initialized
ERROR - 2024-11-03 21:14:02 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 21:14:22 --> Config Class Initialized
INFO - 2024-11-03 21:14:22 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:14:22 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:14:22 --> Utf8 Class Initialized
INFO - 2024-11-03 21:14:22 --> URI Class Initialized
DEBUG - 2024-11-03 21:14:22 --> No URI present. Default controller set.
INFO - 2024-11-03 21:14:22 --> Router Class Initialized
INFO - 2024-11-03 21:14:22 --> Output Class Initialized
INFO - 2024-11-03 21:14:22 --> Security Class Initialized
DEBUG - 2024-11-03 21:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:14:22 --> Input Class Initialized
INFO - 2024-11-03 21:14:22 --> Language Class Initialized
INFO - 2024-11-03 21:14:22 --> Loader Class Initialized
INFO - 2024-11-03 21:14:22 --> Helper loaded: url_helper
INFO - 2024-11-03 21:14:22 --> Controller Class Initialized
INFO - 2024-11-03 21:14:22 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 21:14:22 --> Final output sent to browser
DEBUG - 2024-11-03 21:14:22 --> Total execution time: 0.1415
INFO - 2024-11-03 21:14:22 --> Config Class Initialized
INFO - 2024-11-03 21:14:22 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:14:22 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:14:22 --> Utf8 Class Initialized
INFO - 2024-11-03 21:14:22 --> URI Class Initialized
INFO - 2024-11-03 21:14:22 --> Router Class Initialized
INFO - 2024-11-03 21:14:22 --> Output Class Initialized
INFO - 2024-11-03 21:14:22 --> Security Class Initialized
DEBUG - 2024-11-03 21:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:14:22 --> Input Class Initialized
INFO - 2024-11-03 21:14:22 --> Language Class Initialized
ERROR - 2024-11-03 21:14:22 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 21:17:55 --> Config Class Initialized
INFO - 2024-11-03 21:17:55 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:17:55 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:17:55 --> Utf8 Class Initialized
INFO - 2024-11-03 21:17:55 --> URI Class Initialized
INFO - 2024-11-03 21:17:55 --> Router Class Initialized
INFO - 2024-11-03 21:17:55 --> Output Class Initialized
INFO - 2024-11-03 21:17:55 --> Security Class Initialized
DEBUG - 2024-11-03 21:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:17:55 --> Input Class Initialized
INFO - 2024-11-03 21:17:55 --> Language Class Initialized
ERROR - 2024-11-03 21:17:55 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 21:17:56 --> Config Class Initialized
INFO - 2024-11-03 21:17:56 --> Config Class Initialized
INFO - 2024-11-03 21:17:56 --> Hooks Class Initialized
INFO - 2024-11-03 21:17:56 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:17:56 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 21:17:56 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:17:56 --> Utf8 Class Initialized
INFO - 2024-11-03 21:17:56 --> Utf8 Class Initialized
INFO - 2024-11-03 21:17:56 --> URI Class Initialized
INFO - 2024-11-03 21:17:56 --> URI Class Initialized
INFO - 2024-11-03 21:17:56 --> Router Class Initialized
INFO - 2024-11-03 21:17:56 --> Router Class Initialized
INFO - 2024-11-03 21:17:56 --> Output Class Initialized
INFO - 2024-11-03 21:17:56 --> Output Class Initialized
INFO - 2024-11-03 21:17:56 --> Security Class Initialized
INFO - 2024-11-03 21:17:56 --> Security Class Initialized
DEBUG - 2024-11-03 21:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 21:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:17:56 --> Input Class Initialized
INFO - 2024-11-03 21:17:56 --> Input Class Initialized
INFO - 2024-11-03 21:17:56 --> Language Class Initialized
INFO - 2024-11-03 21:17:56 --> Language Class Initialized
ERROR - 2024-11-03 21:17:56 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 21:17:56 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 21:19:40 --> Config Class Initialized
INFO - 2024-11-03 21:19:40 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:19:40 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:19:40 --> Utf8 Class Initialized
INFO - 2024-11-03 21:19:40 --> URI Class Initialized
DEBUG - 2024-11-03 21:19:40 --> No URI present. Default controller set.
INFO - 2024-11-03 21:19:40 --> Router Class Initialized
INFO - 2024-11-03 21:19:40 --> Output Class Initialized
INFO - 2024-11-03 21:19:40 --> Security Class Initialized
DEBUG - 2024-11-03 21:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:19:40 --> Input Class Initialized
INFO - 2024-11-03 21:19:40 --> Language Class Initialized
INFO - 2024-11-03 21:19:40 --> Loader Class Initialized
INFO - 2024-11-03 21:19:40 --> Helper loaded: url_helper
INFO - 2024-11-03 21:19:40 --> Controller Class Initialized
INFO - 2024-11-03 21:19:40 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 21:19:40 --> Final output sent to browser
DEBUG - 2024-11-03 21:19:40 --> Total execution time: 0.2011
INFO - 2024-11-03 21:19:41 --> Config Class Initialized
INFO - 2024-11-03 21:19:41 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:19:41 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:19:41 --> Utf8 Class Initialized
INFO - 2024-11-03 21:19:41 --> URI Class Initialized
INFO - 2024-11-03 21:19:41 --> Router Class Initialized
INFO - 2024-11-03 21:19:41 --> Output Class Initialized
INFO - 2024-11-03 21:19:41 --> Security Class Initialized
DEBUG - 2024-11-03 21:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:19:41 --> Input Class Initialized
INFO - 2024-11-03 21:19:41 --> Language Class Initialized
ERROR - 2024-11-03 21:19:41 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 21:19:53 --> Config Class Initialized
INFO - 2024-11-03 21:19:53 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:19:53 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:19:53 --> Utf8 Class Initialized
INFO - 2024-11-03 21:19:53 --> URI Class Initialized
DEBUG - 2024-11-03 21:19:53 --> No URI present. Default controller set.
INFO - 2024-11-03 21:19:53 --> Router Class Initialized
INFO - 2024-11-03 21:19:53 --> Output Class Initialized
INFO - 2024-11-03 21:19:53 --> Security Class Initialized
DEBUG - 2024-11-03 21:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:19:53 --> Input Class Initialized
INFO - 2024-11-03 21:19:53 --> Language Class Initialized
INFO - 2024-11-03 21:19:53 --> Loader Class Initialized
INFO - 2024-11-03 21:19:53 --> Helper loaded: url_helper
INFO - 2024-11-03 21:19:53 --> Controller Class Initialized
INFO - 2024-11-03 21:19:54 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 21:19:54 --> Final output sent to browser
DEBUG - 2024-11-03 21:19:54 --> Total execution time: 0.2231
INFO - 2024-11-03 21:19:54 --> Config Class Initialized
INFO - 2024-11-03 21:19:54 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:19:54 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:19:54 --> Utf8 Class Initialized
INFO - 2024-11-03 21:19:54 --> URI Class Initialized
INFO - 2024-11-03 21:19:54 --> Router Class Initialized
INFO - 2024-11-03 21:19:54 --> Output Class Initialized
INFO - 2024-11-03 21:19:54 --> Security Class Initialized
DEBUG - 2024-11-03 21:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:19:54 --> Input Class Initialized
INFO - 2024-11-03 21:19:54 --> Language Class Initialized
ERROR - 2024-11-03 21:19:54 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 21:21:08 --> Config Class Initialized
INFO - 2024-11-03 21:21:08 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:21:08 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:21:08 --> Utf8 Class Initialized
INFO - 2024-11-03 21:21:08 --> URI Class Initialized
DEBUG - 2024-11-03 21:21:08 --> No URI present. Default controller set.
INFO - 2024-11-03 21:21:08 --> Router Class Initialized
INFO - 2024-11-03 21:21:08 --> Output Class Initialized
INFO - 2024-11-03 21:21:08 --> Security Class Initialized
DEBUG - 2024-11-03 21:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:21:08 --> Input Class Initialized
INFO - 2024-11-03 21:21:08 --> Language Class Initialized
INFO - 2024-11-03 21:21:08 --> Loader Class Initialized
INFO - 2024-11-03 21:21:08 --> Helper loaded: url_helper
INFO - 2024-11-03 21:21:08 --> Controller Class Initialized
INFO - 2024-11-03 21:21:08 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 21:21:08 --> Final output sent to browser
DEBUG - 2024-11-03 21:21:08 --> Total execution time: 0.1865
INFO - 2024-11-03 21:21:08 --> Config Class Initialized
INFO - 2024-11-03 21:21:08 --> Config Class Initialized
INFO - 2024-11-03 21:21:08 --> Hooks Class Initialized
INFO - 2024-11-03 21:21:08 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:21:08 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 21:21:08 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:21:08 --> Utf8 Class Initialized
INFO - 2024-11-03 21:21:08 --> Utf8 Class Initialized
INFO - 2024-11-03 21:21:08 --> URI Class Initialized
INFO - 2024-11-03 21:21:08 --> URI Class Initialized
INFO - 2024-11-03 21:21:08 --> Router Class Initialized
INFO - 2024-11-03 21:21:08 --> Router Class Initialized
INFO - 2024-11-03 21:21:08 --> Output Class Initialized
INFO - 2024-11-03 21:21:08 --> Output Class Initialized
INFO - 2024-11-03 21:21:08 --> Security Class Initialized
INFO - 2024-11-03 21:21:08 --> Security Class Initialized
DEBUG - 2024-11-03 21:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 21:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:21:08 --> Input Class Initialized
INFO - 2024-11-03 21:21:08 --> Input Class Initialized
INFO - 2024-11-03 21:21:08 --> Language Class Initialized
INFO - 2024-11-03 21:21:08 --> Language Class Initialized
ERROR - 2024-11-03 21:21:09 --> 404 Page Not Found: Bootstrap/js
ERROR - 2024-11-03 21:21:09 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 21:24:15 --> Config Class Initialized
INFO - 2024-11-03 21:24:15 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:24:15 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:24:15 --> Utf8 Class Initialized
INFO - 2024-11-03 21:24:15 --> URI Class Initialized
DEBUG - 2024-11-03 21:24:15 --> No URI present. Default controller set.
INFO - 2024-11-03 21:24:15 --> Router Class Initialized
INFO - 2024-11-03 21:24:15 --> Output Class Initialized
INFO - 2024-11-03 21:24:15 --> Security Class Initialized
DEBUG - 2024-11-03 21:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:24:15 --> Input Class Initialized
INFO - 2024-11-03 21:24:15 --> Language Class Initialized
INFO - 2024-11-03 21:24:15 --> Loader Class Initialized
INFO - 2024-11-03 21:24:15 --> Helper loaded: url_helper
INFO - 2024-11-03 21:24:15 --> Controller Class Initialized
INFO - 2024-11-03 21:24:15 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 21:24:15 --> Final output sent to browser
DEBUG - 2024-11-03 21:24:15 --> Total execution time: 0.2224
INFO - 2024-11-03 21:24:16 --> Config Class Initialized
INFO - 2024-11-03 21:24:16 --> Config Class Initialized
INFO - 2024-11-03 21:24:16 --> Hooks Class Initialized
INFO - 2024-11-03 21:24:16 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:24:16 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 21:24:16 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:24:16 --> Utf8 Class Initialized
INFO - 2024-11-03 21:24:16 --> Utf8 Class Initialized
INFO - 2024-11-03 21:24:16 --> URI Class Initialized
INFO - 2024-11-03 21:24:16 --> URI Class Initialized
INFO - 2024-11-03 21:24:16 --> Router Class Initialized
INFO - 2024-11-03 21:24:16 --> Router Class Initialized
INFO - 2024-11-03 21:24:16 --> Output Class Initialized
INFO - 2024-11-03 21:24:16 --> Output Class Initialized
INFO - 2024-11-03 21:24:16 --> Security Class Initialized
INFO - 2024-11-03 21:24:16 --> Security Class Initialized
DEBUG - 2024-11-03 21:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 21:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:24:16 --> Input Class Initialized
INFO - 2024-11-03 21:24:16 --> Input Class Initialized
INFO - 2024-11-03 21:24:16 --> Language Class Initialized
INFO - 2024-11-03 21:24:16 --> Language Class Initialized
ERROR - 2024-11-03 21:24:16 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 21:24:16 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 21:24:20 --> Config Class Initialized
INFO - 2024-11-03 21:24:20 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:24:20 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:24:20 --> Utf8 Class Initialized
INFO - 2024-11-03 21:24:20 --> URI Class Initialized
DEBUG - 2024-11-03 21:24:20 --> No URI present. Default controller set.
INFO - 2024-11-03 21:24:20 --> Router Class Initialized
INFO - 2024-11-03 21:24:20 --> Output Class Initialized
INFO - 2024-11-03 21:24:20 --> Security Class Initialized
DEBUG - 2024-11-03 21:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:24:20 --> Input Class Initialized
INFO - 2024-11-03 21:24:20 --> Language Class Initialized
INFO - 2024-11-03 21:24:20 --> Loader Class Initialized
INFO - 2024-11-03 21:24:20 --> Helper loaded: url_helper
INFO - 2024-11-03 21:24:20 --> Controller Class Initialized
INFO - 2024-11-03 21:24:20 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 21:24:20 --> Final output sent to browser
DEBUG - 2024-11-03 21:24:20 --> Total execution time: 0.1583
INFO - 2024-11-03 21:24:20 --> Config Class Initialized
INFO - 2024-11-03 21:24:20 --> Config Class Initialized
INFO - 2024-11-03 21:24:20 --> Hooks Class Initialized
INFO - 2024-11-03 21:24:20 --> Hooks Class Initialized
DEBUG - 2024-11-03 21:24:20 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 21:24:20 --> UTF-8 Support Enabled
INFO - 2024-11-03 21:24:20 --> Utf8 Class Initialized
INFO - 2024-11-03 21:24:20 --> Utf8 Class Initialized
INFO - 2024-11-03 21:24:20 --> URI Class Initialized
INFO - 2024-11-03 21:24:20 --> URI Class Initialized
INFO - 2024-11-03 21:24:20 --> Router Class Initialized
INFO - 2024-11-03 21:24:20 --> Router Class Initialized
INFO - 2024-11-03 21:24:20 --> Output Class Initialized
INFO - 2024-11-03 21:24:20 --> Output Class Initialized
INFO - 2024-11-03 21:24:20 --> Security Class Initialized
INFO - 2024-11-03 21:24:20 --> Security Class Initialized
DEBUG - 2024-11-03 21:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 21:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 21:24:20 --> Input Class Initialized
INFO - 2024-11-03 21:24:20 --> Input Class Initialized
INFO - 2024-11-03 21:24:20 --> Language Class Initialized
INFO - 2024-11-03 21:24:20 --> Language Class Initialized
ERROR - 2024-11-03 21:24:20 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 21:24:20 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:04:00 --> Config Class Initialized
INFO - 2024-11-03 22:04:00 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:04:00 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:04:00 --> Utf8 Class Initialized
INFO - 2024-11-03 22:04:00 --> URI Class Initialized
DEBUG - 2024-11-03 22:04:00 --> No URI present. Default controller set.
INFO - 2024-11-03 22:04:00 --> Router Class Initialized
INFO - 2024-11-03 22:04:00 --> Output Class Initialized
INFO - 2024-11-03 22:04:00 --> Security Class Initialized
DEBUG - 2024-11-03 22:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:04:00 --> Input Class Initialized
INFO - 2024-11-03 22:04:00 --> Language Class Initialized
INFO - 2024-11-03 22:04:00 --> Loader Class Initialized
INFO - 2024-11-03 22:04:00 --> Helper loaded: url_helper
INFO - 2024-11-03 22:04:00 --> Controller Class Initialized
INFO - 2024-11-03 22:04:00 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:04:00 --> Final output sent to browser
DEBUG - 2024-11-03 22:04:00 --> Total execution time: 0.0479
INFO - 2024-11-03 22:04:00 --> Config Class Initialized
INFO - 2024-11-03 22:04:00 --> Config Class Initialized
INFO - 2024-11-03 22:04:00 --> Hooks Class Initialized
INFO - 2024-11-03 22:04:00 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:04:00 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:04:00 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:04:00 --> Utf8 Class Initialized
INFO - 2024-11-03 22:04:00 --> Utf8 Class Initialized
INFO - 2024-11-03 22:04:00 --> URI Class Initialized
INFO - 2024-11-03 22:04:00 --> URI Class Initialized
INFO - 2024-11-03 22:04:00 --> Router Class Initialized
INFO - 2024-11-03 22:04:00 --> Router Class Initialized
INFO - 2024-11-03 22:04:00 --> Output Class Initialized
INFO - 2024-11-03 22:04:00 --> Output Class Initialized
INFO - 2024-11-03 22:04:00 --> Security Class Initialized
INFO - 2024-11-03 22:04:00 --> Security Class Initialized
DEBUG - 2024-11-03 22:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:04:00 --> Input Class Initialized
INFO - 2024-11-03 22:04:00 --> Input Class Initialized
INFO - 2024-11-03 22:04:00 --> Language Class Initialized
INFO - 2024-11-03 22:04:00 --> Language Class Initialized
ERROR - 2024-11-03 22:04:00 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:04:00 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:35:48 --> Config Class Initialized
INFO - 2024-11-03 22:35:48 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:35:48 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:35:48 --> Utf8 Class Initialized
INFO - 2024-11-03 22:35:48 --> URI Class Initialized
DEBUG - 2024-11-03 22:35:48 --> No URI present. Default controller set.
INFO - 2024-11-03 22:35:48 --> Router Class Initialized
INFO - 2024-11-03 22:35:48 --> Output Class Initialized
INFO - 2024-11-03 22:35:48 --> Security Class Initialized
DEBUG - 2024-11-03 22:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:35:48 --> Input Class Initialized
INFO - 2024-11-03 22:35:48 --> Language Class Initialized
INFO - 2024-11-03 22:35:48 --> Loader Class Initialized
INFO - 2024-11-03 22:35:48 --> Helper loaded: url_helper
INFO - 2024-11-03 22:35:48 --> Database Driver Class Initialized
INFO - 2024-11-03 22:35:48 --> Controller Class Initialized
INFO - 2024-11-03 22:35:48 --> Model "Item_model" initialized
INFO - 2024-11-03 22:35:48 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:35:48 --> Final output sent to browser
DEBUG - 2024-11-03 22:35:48 --> Total execution time: 0.3004
INFO - 2024-11-03 22:35:48 --> Config Class Initialized
INFO - 2024-11-03 22:35:48 --> Config Class Initialized
INFO - 2024-11-03 22:35:48 --> Hooks Class Initialized
INFO - 2024-11-03 22:35:48 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:35:48 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:35:48 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:35:48 --> Utf8 Class Initialized
INFO - 2024-11-03 22:35:48 --> Utf8 Class Initialized
INFO - 2024-11-03 22:35:48 --> URI Class Initialized
INFO - 2024-11-03 22:35:48 --> URI Class Initialized
INFO - 2024-11-03 22:35:48 --> Router Class Initialized
INFO - 2024-11-03 22:35:48 --> Router Class Initialized
INFO - 2024-11-03 22:35:48 --> Output Class Initialized
INFO - 2024-11-03 22:35:48 --> Output Class Initialized
INFO - 2024-11-03 22:35:48 --> Security Class Initialized
INFO - 2024-11-03 22:35:48 --> Security Class Initialized
DEBUG - 2024-11-03 22:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:35:48 --> Input Class Initialized
INFO - 2024-11-03 22:35:48 --> Input Class Initialized
INFO - 2024-11-03 22:35:48 --> Language Class Initialized
INFO - 2024-11-03 22:35:48 --> Language Class Initialized
ERROR - 2024-11-03 22:35:48 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:35:48 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:35:57 --> Config Class Initialized
INFO - 2024-11-03 22:35:57 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:35:57 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:35:57 --> Utf8 Class Initialized
INFO - 2024-11-03 22:35:57 --> URI Class Initialized
INFO - 2024-11-03 22:35:57 --> Router Class Initialized
INFO - 2024-11-03 22:35:57 --> Output Class Initialized
INFO - 2024-11-03 22:35:57 --> Security Class Initialized
DEBUG - 2024-11-03 22:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:35:57 --> Input Class Initialized
INFO - 2024-11-03 22:35:57 --> Language Class Initialized
INFO - 2024-11-03 22:35:57 --> Loader Class Initialized
INFO - 2024-11-03 22:35:57 --> Helper loaded: url_helper
INFO - 2024-11-03 22:35:57 --> Database Driver Class Initialized
INFO - 2024-11-03 22:35:57 --> Controller Class Initialized
INFO - 2024-11-03 22:35:57 --> Model "Item_model" initialized
INFO - 2024-11-03 22:35:57 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-03 22:35:57 --> Final output sent to browser
DEBUG - 2024-11-03 22:35:57 --> Total execution time: 0.1995
INFO - 2024-11-03 22:35:58 --> Config Class Initialized
INFO - 2024-11-03 22:35:58 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:35:58 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:35:58 --> Utf8 Class Initialized
INFO - 2024-11-03 22:35:58 --> URI Class Initialized
INFO - 2024-11-03 22:35:58 --> Router Class Initialized
INFO - 2024-11-03 22:35:58 --> Output Class Initialized
INFO - 2024-11-03 22:35:58 --> Security Class Initialized
DEBUG - 2024-11-03 22:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:35:58 --> Input Class Initialized
INFO - 2024-11-03 22:35:58 --> Language Class Initialized
ERROR - 2024-11-03 22:35:58 --> 404 Page Not Found: Items/bootstrap
INFO - 2024-11-03 22:36:04 --> Config Class Initialized
INFO - 2024-11-03 22:36:04 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:36:04 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:36:04 --> Utf8 Class Initialized
INFO - 2024-11-03 22:36:04 --> URI Class Initialized
INFO - 2024-11-03 22:36:04 --> Router Class Initialized
INFO - 2024-11-03 22:36:04 --> Output Class Initialized
INFO - 2024-11-03 22:36:04 --> Security Class Initialized
DEBUG - 2024-11-03 22:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:36:04 --> Input Class Initialized
INFO - 2024-11-03 22:36:04 --> Language Class Initialized
INFO - 2024-11-03 22:36:04 --> Loader Class Initialized
INFO - 2024-11-03 22:36:04 --> Helper loaded: url_helper
INFO - 2024-11-03 22:36:04 --> Database Driver Class Initialized
INFO - 2024-11-03 22:36:04 --> Controller Class Initialized
INFO - 2024-11-03 22:36:04 --> Model "Item_model" initialized
INFO - 2024-11-03 22:36:05 --> Config Class Initialized
INFO - 2024-11-03 22:36:05 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:36:05 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:36:05 --> Utf8 Class Initialized
INFO - 2024-11-03 22:36:05 --> URI Class Initialized
DEBUG - 2024-11-03 22:36:05 --> No URI present. Default controller set.
INFO - 2024-11-03 22:36:05 --> Router Class Initialized
INFO - 2024-11-03 22:36:05 --> Output Class Initialized
INFO - 2024-11-03 22:36:05 --> Security Class Initialized
DEBUG - 2024-11-03 22:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:36:05 --> Input Class Initialized
INFO - 2024-11-03 22:36:05 --> Language Class Initialized
INFO - 2024-11-03 22:36:05 --> Loader Class Initialized
INFO - 2024-11-03 22:36:05 --> Helper loaded: url_helper
INFO - 2024-11-03 22:36:05 --> Database Driver Class Initialized
INFO - 2024-11-03 22:36:05 --> Controller Class Initialized
INFO - 2024-11-03 22:36:05 --> Model "Item_model" initialized
INFO - 2024-11-03 22:36:05 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:36:05 --> Final output sent to browser
DEBUG - 2024-11-03 22:36:05 --> Total execution time: 0.3054
INFO - 2024-11-03 22:36:05 --> Config Class Initialized
INFO - 2024-11-03 22:36:05 --> Config Class Initialized
INFO - 2024-11-03 22:36:05 --> Hooks Class Initialized
INFO - 2024-11-03 22:36:05 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:36:05 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:36:05 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:36:05 --> Utf8 Class Initialized
INFO - 2024-11-03 22:36:05 --> Utf8 Class Initialized
INFO - 2024-11-03 22:36:05 --> URI Class Initialized
INFO - 2024-11-03 22:36:05 --> URI Class Initialized
INFO - 2024-11-03 22:36:05 --> Router Class Initialized
INFO - 2024-11-03 22:36:05 --> Router Class Initialized
INFO - 2024-11-03 22:36:05 --> Output Class Initialized
INFO - 2024-11-03 22:36:05 --> Output Class Initialized
INFO - 2024-11-03 22:36:05 --> Security Class Initialized
INFO - 2024-11-03 22:36:05 --> Security Class Initialized
DEBUG - 2024-11-03 22:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:36:05 --> Input Class Initialized
INFO - 2024-11-03 22:36:05 --> Input Class Initialized
INFO - 2024-11-03 22:36:05 --> Language Class Initialized
INFO - 2024-11-03 22:36:05 --> Language Class Initialized
ERROR - 2024-11-03 22:36:05 --> 404 Page Not Found: Bootstrap/js
ERROR - 2024-11-03 22:36:05 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 22:36:12 --> Config Class Initialized
INFO - 2024-11-03 22:36:12 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:36:12 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:36:12 --> Utf8 Class Initialized
INFO - 2024-11-03 22:36:12 --> URI Class Initialized
INFO - 2024-11-03 22:36:12 --> Router Class Initialized
INFO - 2024-11-03 22:36:12 --> Output Class Initialized
INFO - 2024-11-03 22:36:12 --> Security Class Initialized
DEBUG - 2024-11-03 22:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:36:12 --> Input Class Initialized
INFO - 2024-11-03 22:36:12 --> Language Class Initialized
INFO - 2024-11-03 22:36:12 --> Loader Class Initialized
INFO - 2024-11-03 22:36:12 --> Helper loaded: url_helper
INFO - 2024-11-03 22:36:12 --> Database Driver Class Initialized
INFO - 2024-11-03 22:36:12 --> Controller Class Initialized
INFO - 2024-11-03 22:36:12 --> Model "Item_model" initialized
INFO - 2024-11-03 22:36:13 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-03 22:36:13 --> Final output sent to browser
DEBUG - 2024-11-03 22:36:13 --> Total execution time: 0.2660
INFO - 2024-11-03 22:36:13 --> Config Class Initialized
INFO - 2024-11-03 22:36:13 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:36:13 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:36:13 --> Utf8 Class Initialized
INFO - 2024-11-03 22:36:13 --> URI Class Initialized
INFO - 2024-11-03 22:36:13 --> Router Class Initialized
INFO - 2024-11-03 22:36:13 --> Output Class Initialized
INFO - 2024-11-03 22:36:13 --> Security Class Initialized
DEBUG - 2024-11-03 22:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:36:13 --> Input Class Initialized
INFO - 2024-11-03 22:36:13 --> Language Class Initialized
ERROR - 2024-11-03 22:36:13 --> 404 Page Not Found: Items/bootstrap
INFO - 2024-11-03 22:48:11 --> Config Class Initialized
INFO - 2024-11-03 22:48:11 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:48:11 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:48:11 --> Utf8 Class Initialized
INFO - 2024-11-03 22:48:11 --> URI Class Initialized
INFO - 2024-11-03 22:48:11 --> Router Class Initialized
INFO - 2024-11-03 22:48:11 --> Output Class Initialized
INFO - 2024-11-03 22:48:11 --> Security Class Initialized
DEBUG - 2024-11-03 22:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:48:11 --> Input Class Initialized
INFO - 2024-11-03 22:48:11 --> Language Class Initialized
INFO - 2024-11-03 22:48:12 --> Loader Class Initialized
INFO - 2024-11-03 22:48:12 --> Helper loaded: url_helper
INFO - 2024-11-03 22:48:12 --> Database Driver Class Initialized
INFO - 2024-11-03 22:48:12 --> Controller Class Initialized
INFO - 2024-11-03 22:48:12 --> Model "Item_model" initialized
INFO - 2024-11-03 22:48:12 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-03 22:48:12 --> Final output sent to browser
DEBUG - 2024-11-03 22:48:12 --> Total execution time: 0.3028
INFO - 2024-11-03 22:48:12 --> Config Class Initialized
INFO - 2024-11-03 22:48:12 --> Config Class Initialized
INFO - 2024-11-03 22:48:12 --> Hooks Class Initialized
INFO - 2024-11-03 22:48:12 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:48:12 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:48:12 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:48:12 --> Utf8 Class Initialized
INFO - 2024-11-03 22:48:12 --> Utf8 Class Initialized
INFO - 2024-11-03 22:48:12 --> URI Class Initialized
INFO - 2024-11-03 22:48:12 --> URI Class Initialized
INFO - 2024-11-03 22:48:12 --> Router Class Initialized
INFO - 2024-11-03 22:48:12 --> Router Class Initialized
INFO - 2024-11-03 22:48:12 --> Output Class Initialized
INFO - 2024-11-03 22:48:12 --> Output Class Initialized
INFO - 2024-11-03 22:48:12 --> Security Class Initialized
INFO - 2024-11-03 22:48:12 --> Security Class Initialized
DEBUG - 2024-11-03 22:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:48:12 --> Input Class Initialized
INFO - 2024-11-03 22:48:12 --> Input Class Initialized
INFO - 2024-11-03 22:48:12 --> Language Class Initialized
INFO - 2024-11-03 22:48:12 --> Language Class Initialized
ERROR - 2024-11-03 22:48:12 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:48:12 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:48:18 --> Config Class Initialized
INFO - 2024-11-03 22:48:18 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:48:18 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:48:18 --> Utf8 Class Initialized
INFO - 2024-11-03 22:48:18 --> URI Class Initialized
DEBUG - 2024-11-03 22:48:18 --> No URI present. Default controller set.
INFO - 2024-11-03 22:48:18 --> Router Class Initialized
INFO - 2024-11-03 22:48:18 --> Output Class Initialized
INFO - 2024-11-03 22:48:18 --> Security Class Initialized
DEBUG - 2024-11-03 22:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:48:19 --> Input Class Initialized
INFO - 2024-11-03 22:48:19 --> Language Class Initialized
INFO - 2024-11-03 22:48:19 --> Loader Class Initialized
INFO - 2024-11-03 22:48:19 --> Helper loaded: url_helper
INFO - 2024-11-03 22:48:19 --> Database Driver Class Initialized
INFO - 2024-11-03 22:48:19 --> Controller Class Initialized
INFO - 2024-11-03 22:48:19 --> Model "Item_model" initialized
ERROR - 2024-11-03 22:48:19 --> Severity: error --> Exception: Call to undefined method Item_model::get_items() C:\wamp64\www\crud_1\application\controllers\Items.php 15
INFO - 2024-11-03 22:51:56 --> Config Class Initialized
INFO - 2024-11-03 22:51:56 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:51:57 --> Utf8 Class Initialized
INFO - 2024-11-03 22:51:57 --> URI Class Initialized
DEBUG - 2024-11-03 22:51:57 --> No URI present. Default controller set.
INFO - 2024-11-03 22:51:57 --> Router Class Initialized
INFO - 2024-11-03 22:51:57 --> Output Class Initialized
INFO - 2024-11-03 22:51:57 --> Security Class Initialized
DEBUG - 2024-11-03 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:51:57 --> Input Class Initialized
INFO - 2024-11-03 22:51:57 --> Language Class Initialized
INFO - 2024-11-03 22:51:57 --> Loader Class Initialized
INFO - 2024-11-03 22:51:57 --> Helper loaded: url_helper
INFO - 2024-11-03 22:51:57 --> Database Driver Class Initialized
INFO - 2024-11-03 22:51:57 --> Controller Class Initialized
INFO - 2024-11-03 22:51:57 --> Model "Item_model" initialized
INFO - 2024-11-03 22:51:57 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:51:57 --> Final output sent to browser
DEBUG - 2024-11-03 22:51:57 --> Total execution time: 0.3193
INFO - 2024-11-03 22:51:57 --> Config Class Initialized
INFO - 2024-11-03 22:51:57 --> Config Class Initialized
INFO - 2024-11-03 22:51:57 --> Hooks Class Initialized
INFO - 2024-11-03 22:51:57 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:51:57 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:51:57 --> Utf8 Class Initialized
INFO - 2024-11-03 22:51:57 --> Utf8 Class Initialized
INFO - 2024-11-03 22:51:57 --> URI Class Initialized
INFO - 2024-11-03 22:51:57 --> URI Class Initialized
INFO - 2024-11-03 22:51:57 --> Router Class Initialized
INFO - 2024-11-03 22:51:57 --> Router Class Initialized
INFO - 2024-11-03 22:51:57 --> Output Class Initialized
INFO - 2024-11-03 22:51:57 --> Output Class Initialized
INFO - 2024-11-03 22:51:57 --> Security Class Initialized
INFO - 2024-11-03 22:51:57 --> Security Class Initialized
DEBUG - 2024-11-03 22:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:51:57 --> Input Class Initialized
INFO - 2024-11-03 22:51:57 --> Input Class Initialized
INFO - 2024-11-03 22:51:57 --> Language Class Initialized
INFO - 2024-11-03 22:51:57 --> Language Class Initialized
ERROR - 2024-11-03 22:51:57 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:51:57 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:52:01 --> Config Class Initialized
INFO - 2024-11-03 22:52:01 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:01 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:01 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:01 --> URI Class Initialized
DEBUG - 2024-11-03 22:52:01 --> No URI present. Default controller set.
INFO - 2024-11-03 22:52:01 --> Router Class Initialized
INFO - 2024-11-03 22:52:01 --> Output Class Initialized
INFO - 2024-11-03 22:52:01 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:01 --> Input Class Initialized
INFO - 2024-11-03 22:52:01 --> Language Class Initialized
INFO - 2024-11-03 22:52:01 --> Loader Class Initialized
INFO - 2024-11-03 22:52:01 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:01 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:01 --> Controller Class Initialized
INFO - 2024-11-03 22:52:01 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:01 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:52:01 --> Final output sent to browser
DEBUG - 2024-11-03 22:52:01 --> Total execution time: 0.1808
INFO - 2024-11-03 22:52:01 --> Config Class Initialized
INFO - 2024-11-03 22:52:01 --> Config Class Initialized
INFO - 2024-11-03 22:52:01 --> Hooks Class Initialized
INFO - 2024-11-03 22:52:01 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:01 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:52:01 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:01 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:01 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:01 --> URI Class Initialized
INFO - 2024-11-03 22:52:01 --> URI Class Initialized
INFO - 2024-11-03 22:52:01 --> Router Class Initialized
INFO - 2024-11-03 22:52:01 --> Router Class Initialized
INFO - 2024-11-03 22:52:01 --> Output Class Initialized
INFO - 2024-11-03 22:52:01 --> Output Class Initialized
INFO - 2024-11-03 22:52:01 --> Security Class Initialized
INFO - 2024-11-03 22:52:01 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:01 --> Input Class Initialized
INFO - 2024-11-03 22:52:01 --> Input Class Initialized
INFO - 2024-11-03 22:52:01 --> Language Class Initialized
INFO - 2024-11-03 22:52:01 --> Language Class Initialized
ERROR - 2024-11-03 22:52:01 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:52:01 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:52:04 --> Config Class Initialized
INFO - 2024-11-03 22:52:04 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:04 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:04 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:04 --> URI Class Initialized
INFO - 2024-11-03 22:52:04 --> Router Class Initialized
INFO - 2024-11-03 22:52:04 --> Output Class Initialized
INFO - 2024-11-03 22:52:04 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:04 --> Input Class Initialized
INFO - 2024-11-03 22:52:04 --> Language Class Initialized
INFO - 2024-11-03 22:52:04 --> Loader Class Initialized
INFO - 2024-11-03 22:52:04 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:04 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:04 --> Controller Class Initialized
INFO - 2024-11-03 22:52:04 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:04 --> File loaded: C:\wamp64\www\crud_1\application\views\items/edit.php
INFO - 2024-11-03 22:52:04 --> Final output sent to browser
DEBUG - 2024-11-03 22:52:04 --> Total execution time: 0.3651
INFO - 2024-11-03 22:52:04 --> Config Class Initialized
INFO - 2024-11-03 22:52:04 --> Config Class Initialized
INFO - 2024-11-03 22:52:04 --> Hooks Class Initialized
INFO - 2024-11-03 22:52:04 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:04 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:52:04 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:04 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:04 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:04 --> URI Class Initialized
INFO - 2024-11-03 22:52:04 --> URI Class Initialized
INFO - 2024-11-03 22:52:04 --> Router Class Initialized
INFO - 2024-11-03 22:52:04 --> Router Class Initialized
INFO - 2024-11-03 22:52:04 --> Output Class Initialized
INFO - 2024-11-03 22:52:04 --> Output Class Initialized
INFO - 2024-11-03 22:52:05 --> Security Class Initialized
INFO - 2024-11-03 22:52:05 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:05 --> Input Class Initialized
INFO - 2024-11-03 22:52:05 --> Input Class Initialized
INFO - 2024-11-03 22:52:05 --> Language Class Initialized
INFO - 2024-11-03 22:52:05 --> Language Class Initialized
ERROR - 2024-11-03 22:52:05 --> 404 Page Not Found: Bootstrap/js
ERROR - 2024-11-03 22:52:05 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 22:52:16 --> Config Class Initialized
INFO - 2024-11-03 22:52:16 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:16 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:16 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:16 --> URI Class Initialized
INFO - 2024-11-03 22:52:16 --> Router Class Initialized
INFO - 2024-11-03 22:52:16 --> Output Class Initialized
INFO - 2024-11-03 22:52:16 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:16 --> Input Class Initialized
INFO - 2024-11-03 22:52:16 --> Language Class Initialized
INFO - 2024-11-03 22:52:16 --> Loader Class Initialized
INFO - 2024-11-03 22:52:16 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:16 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:16 --> Controller Class Initialized
INFO - 2024-11-03 22:52:16 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:16 --> Config Class Initialized
INFO - 2024-11-03 22:52:16 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:16 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:16 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:16 --> URI Class Initialized
INFO - 2024-11-03 22:52:16 --> Router Class Initialized
INFO - 2024-11-03 22:52:16 --> Output Class Initialized
INFO - 2024-11-03 22:52:16 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:16 --> Input Class Initialized
INFO - 2024-11-03 22:52:16 --> Language Class Initialized
INFO - 2024-11-03 22:52:16 --> Loader Class Initialized
INFO - 2024-11-03 22:52:16 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:16 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:16 --> Controller Class Initialized
INFO - 2024-11-03 22:52:16 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:16 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:52:16 --> Final output sent to browser
DEBUG - 2024-11-03 22:52:16 --> Total execution time: 0.2617
INFO - 2024-11-03 22:52:17 --> Config Class Initialized
INFO - 2024-11-03 22:52:17 --> Config Class Initialized
INFO - 2024-11-03 22:52:17 --> Hooks Class Initialized
INFO - 2024-11-03 22:52:17 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:52:17 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:17 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:17 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:17 --> URI Class Initialized
INFO - 2024-11-03 22:52:17 --> URI Class Initialized
INFO - 2024-11-03 22:52:17 --> Router Class Initialized
INFO - 2024-11-03 22:52:17 --> Router Class Initialized
INFO - 2024-11-03 22:52:17 --> Output Class Initialized
INFO - 2024-11-03 22:52:17 --> Output Class Initialized
INFO - 2024-11-03 22:52:17 --> Security Class Initialized
INFO - 2024-11-03 22:52:17 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:17 --> Input Class Initialized
INFO - 2024-11-03 22:52:17 --> Input Class Initialized
INFO - 2024-11-03 22:52:17 --> Language Class Initialized
INFO - 2024-11-03 22:52:17 --> Language Class Initialized
ERROR - 2024-11-03 22:52:17 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:52:17 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:52:22 --> Config Class Initialized
INFO - 2024-11-03 22:52:22 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:22 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:22 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:22 --> URI Class Initialized
INFO - 2024-11-03 22:52:22 --> Router Class Initialized
INFO - 2024-11-03 22:52:22 --> Output Class Initialized
INFO - 2024-11-03 22:52:22 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:22 --> Input Class Initialized
INFO - 2024-11-03 22:52:22 --> Language Class Initialized
INFO - 2024-11-03 22:52:22 --> Loader Class Initialized
INFO - 2024-11-03 22:52:22 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:22 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:22 --> Controller Class Initialized
INFO - 2024-11-03 22:52:22 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:22 --> File loaded: C:\wamp64\www\crud_1\application\views\items/create.php
INFO - 2024-11-03 22:52:22 --> Final output sent to browser
DEBUG - 2024-11-03 22:52:22 --> Total execution time: 0.1406
INFO - 2024-11-03 22:52:22 --> Config Class Initialized
INFO - 2024-11-03 22:52:22 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:22 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:23 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:23 --> URI Class Initialized
INFO - 2024-11-03 22:52:23 --> Router Class Initialized
INFO - 2024-11-03 22:52:23 --> Output Class Initialized
INFO - 2024-11-03 22:52:23 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:23 --> Input Class Initialized
INFO - 2024-11-03 22:52:23 --> Language Class Initialized
ERROR - 2024-11-03 22:52:23 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 22:52:39 --> Config Class Initialized
INFO - 2024-11-03 22:52:39 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:39 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:39 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:39 --> URI Class Initialized
INFO - 2024-11-03 22:52:39 --> Router Class Initialized
INFO - 2024-11-03 22:52:40 --> Output Class Initialized
INFO - 2024-11-03 22:52:40 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:40 --> Input Class Initialized
INFO - 2024-11-03 22:52:40 --> Language Class Initialized
INFO - 2024-11-03 22:52:40 --> Loader Class Initialized
INFO - 2024-11-03 22:52:40 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:40 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:40 --> Controller Class Initialized
INFO - 2024-11-03 22:52:40 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:40 --> Config Class Initialized
INFO - 2024-11-03 22:52:40 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:40 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:40 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:40 --> URI Class Initialized
INFO - 2024-11-03 22:52:40 --> Router Class Initialized
INFO - 2024-11-03 22:52:40 --> Output Class Initialized
INFO - 2024-11-03 22:52:40 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:40 --> Input Class Initialized
INFO - 2024-11-03 22:52:40 --> Language Class Initialized
INFO - 2024-11-03 22:52:40 --> Loader Class Initialized
INFO - 2024-11-03 22:52:40 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:40 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:40 --> Controller Class Initialized
INFO - 2024-11-03 22:52:40 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:40 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:52:40 --> Final output sent to browser
DEBUG - 2024-11-03 22:52:40 --> Total execution time: 0.2953
INFO - 2024-11-03 22:52:40 --> Config Class Initialized
INFO - 2024-11-03 22:52:40 --> Config Class Initialized
INFO - 2024-11-03 22:52:40 --> Hooks Class Initialized
INFO - 2024-11-03 22:52:40 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:40 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:52:41 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:41 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:41 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:41 --> URI Class Initialized
INFO - 2024-11-03 22:52:41 --> URI Class Initialized
INFO - 2024-11-03 22:52:41 --> Router Class Initialized
INFO - 2024-11-03 22:52:41 --> Router Class Initialized
INFO - 2024-11-03 22:52:41 --> Output Class Initialized
INFO - 2024-11-03 22:52:41 --> Output Class Initialized
INFO - 2024-11-03 22:52:41 --> Security Class Initialized
INFO - 2024-11-03 22:52:41 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:41 --> Input Class Initialized
INFO - 2024-11-03 22:52:41 --> Input Class Initialized
INFO - 2024-11-03 22:52:41 --> Language Class Initialized
INFO - 2024-11-03 22:52:41 --> Language Class Initialized
ERROR - 2024-11-03 22:52:41 --> 404 Page Not Found: Bootstrap/js
ERROR - 2024-11-03 22:52:41 --> 404 Page Not Found: Bootstrap/css
INFO - 2024-11-03 22:52:54 --> Config Class Initialized
INFO - 2024-11-03 22:52:54 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:54 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:54 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:54 --> URI Class Initialized
INFO - 2024-11-03 22:52:54 --> Router Class Initialized
INFO - 2024-11-03 22:52:54 --> Output Class Initialized
INFO - 2024-11-03 22:52:54 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:54 --> Input Class Initialized
INFO - 2024-11-03 22:52:54 --> Language Class Initialized
INFO - 2024-11-03 22:52:54 --> Loader Class Initialized
INFO - 2024-11-03 22:52:54 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:54 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:54 --> Controller Class Initialized
INFO - 2024-11-03 22:52:54 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:54 --> Config Class Initialized
INFO - 2024-11-03 22:52:55 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:55 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:55 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:55 --> URI Class Initialized
INFO - 2024-11-03 22:52:55 --> Router Class Initialized
INFO - 2024-11-03 22:52:55 --> Output Class Initialized
INFO - 2024-11-03 22:52:55 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:55 --> Input Class Initialized
INFO - 2024-11-03 22:52:55 --> Language Class Initialized
INFO - 2024-11-03 22:52:55 --> Loader Class Initialized
INFO - 2024-11-03 22:52:55 --> Helper loaded: url_helper
INFO - 2024-11-03 22:52:55 --> Database Driver Class Initialized
INFO - 2024-11-03 22:52:55 --> Controller Class Initialized
INFO - 2024-11-03 22:52:55 --> Model "Item_model" initialized
INFO - 2024-11-03 22:52:55 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:52:55 --> Final output sent to browser
DEBUG - 2024-11-03 22:52:55 --> Total execution time: 0.2960
INFO - 2024-11-03 22:52:55 --> Config Class Initialized
INFO - 2024-11-03 22:52:55 --> Config Class Initialized
INFO - 2024-11-03 22:52:55 --> Hooks Class Initialized
INFO - 2024-11-03 22:52:55 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:52:55 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:52:55 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:52:55 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:55 --> Utf8 Class Initialized
INFO - 2024-11-03 22:52:55 --> URI Class Initialized
INFO - 2024-11-03 22:52:55 --> URI Class Initialized
INFO - 2024-11-03 22:52:55 --> Router Class Initialized
INFO - 2024-11-03 22:52:55 --> Router Class Initialized
INFO - 2024-11-03 22:52:55 --> Output Class Initialized
INFO - 2024-11-03 22:52:55 --> Output Class Initialized
INFO - 2024-11-03 22:52:55 --> Security Class Initialized
INFO - 2024-11-03 22:52:55 --> Security Class Initialized
DEBUG - 2024-11-03 22:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:52:55 --> Input Class Initialized
INFO - 2024-11-03 22:52:55 --> Input Class Initialized
INFO - 2024-11-03 22:52:55 --> Language Class Initialized
INFO - 2024-11-03 22:52:55 --> Language Class Initialized
ERROR - 2024-11-03 22:52:55 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:52:55 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:53:02 --> Config Class Initialized
INFO - 2024-11-03 22:53:02 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:53:02 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:53:02 --> Utf8 Class Initialized
INFO - 2024-11-03 22:53:02 --> URI Class Initialized
INFO - 2024-11-03 22:53:02 --> Router Class Initialized
INFO - 2024-11-03 22:53:02 --> Output Class Initialized
INFO - 2024-11-03 22:53:02 --> Security Class Initialized
DEBUG - 2024-11-03 22:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:53:02 --> Input Class Initialized
INFO - 2024-11-03 22:53:02 --> Language Class Initialized
INFO - 2024-11-03 22:53:02 --> Loader Class Initialized
INFO - 2024-11-03 22:53:02 --> Helper loaded: url_helper
INFO - 2024-11-03 22:53:02 --> Database Driver Class Initialized
INFO - 2024-11-03 22:53:02 --> Controller Class Initialized
INFO - 2024-11-03 22:53:02 --> Model "Item_model" initialized
INFO - 2024-11-03 22:53:02 --> Config Class Initialized
INFO - 2024-11-03 22:53:02 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:53:02 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:53:02 --> Utf8 Class Initialized
INFO - 2024-11-03 22:53:02 --> URI Class Initialized
INFO - 2024-11-03 22:53:02 --> Router Class Initialized
INFO - 2024-11-03 22:53:02 --> Output Class Initialized
INFO - 2024-11-03 22:53:02 --> Security Class Initialized
DEBUG - 2024-11-03 22:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:53:02 --> Input Class Initialized
INFO - 2024-11-03 22:53:02 --> Language Class Initialized
INFO - 2024-11-03 22:53:02 --> Loader Class Initialized
INFO - 2024-11-03 22:53:02 --> Helper loaded: url_helper
INFO - 2024-11-03 22:53:02 --> Database Driver Class Initialized
INFO - 2024-11-03 22:53:03 --> Controller Class Initialized
INFO - 2024-11-03 22:53:03 --> Model "Item_model" initialized
INFO - 2024-11-03 22:53:03 --> File loaded: C:\wamp64\www\crud_1\application\views\index.php
INFO - 2024-11-03 22:53:03 --> Final output sent to browser
DEBUG - 2024-11-03 22:53:03 --> Total execution time: 0.2760
INFO - 2024-11-03 22:53:03 --> Config Class Initialized
INFO - 2024-11-03 22:53:03 --> Config Class Initialized
INFO - 2024-11-03 22:53:03 --> Hooks Class Initialized
INFO - 2024-11-03 22:53:03 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:53:03 --> UTF-8 Support Enabled
DEBUG - 2024-11-03 22:53:03 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:53:03 --> Utf8 Class Initialized
INFO - 2024-11-03 22:53:03 --> Utf8 Class Initialized
INFO - 2024-11-03 22:53:03 --> URI Class Initialized
INFO - 2024-11-03 22:53:03 --> URI Class Initialized
INFO - 2024-11-03 22:53:03 --> Router Class Initialized
INFO - 2024-11-03 22:53:03 --> Router Class Initialized
INFO - 2024-11-03 22:53:03 --> Output Class Initialized
INFO - 2024-11-03 22:53:03 --> Output Class Initialized
INFO - 2024-11-03 22:53:03 --> Security Class Initialized
INFO - 2024-11-03 22:53:03 --> Security Class Initialized
DEBUG - 2024-11-03 22:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-03 22:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:53:03 --> Input Class Initialized
INFO - 2024-11-03 22:53:03 --> Input Class Initialized
INFO - 2024-11-03 22:53:03 --> Language Class Initialized
INFO - 2024-11-03 22:53:03 --> Language Class Initialized
ERROR - 2024-11-03 22:53:03 --> 404 Page Not Found: Bootstrap/css
ERROR - 2024-11-03 22:53:03 --> 404 Page Not Found: Bootstrap/js
INFO - 2024-11-03 22:53:13 --> Config Class Initialized
INFO - 2024-11-03 22:53:13 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:53:13 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:53:13 --> Utf8 Class Initialized
INFO - 2024-11-03 22:53:13 --> URI Class Initialized
INFO - 2024-11-03 22:53:13 --> Router Class Initialized
INFO - 2024-11-03 22:53:13 --> Output Class Initialized
INFO - 2024-11-03 22:53:13 --> Security Class Initialized
DEBUG - 2024-11-03 22:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:53:13 --> Input Class Initialized
INFO - 2024-11-03 22:53:13 --> Language Class Initialized
INFO - 2024-11-03 22:53:13 --> Loader Class Initialized
INFO - 2024-11-03 22:53:13 --> Helper loaded: url_helper
INFO - 2024-11-03 22:53:13 --> Database Driver Class Initialized
INFO - 2024-11-03 22:53:13 --> Controller Class Initialized
INFO - 2024-11-03 22:53:13 --> Model "Item_model" initialized
INFO - 2024-11-03 22:53:13 --> File loaded: C:\wamp64\www\crud_1\application\views\items/create.php
INFO - 2024-11-03 22:53:13 --> Final output sent to browser
DEBUG - 2024-11-03 22:53:13 --> Total execution time: 0.1862
INFO - 2024-11-03 22:53:13 --> Config Class Initialized
INFO - 2024-11-03 22:53:13 --> Hooks Class Initialized
DEBUG - 2024-11-03 22:53:13 --> UTF-8 Support Enabled
INFO - 2024-11-03 22:53:13 --> Utf8 Class Initialized
INFO - 2024-11-03 22:53:13 --> URI Class Initialized
INFO - 2024-11-03 22:53:13 --> Router Class Initialized
INFO - 2024-11-03 22:53:13 --> Output Class Initialized
INFO - 2024-11-03 22:53:13 --> Security Class Initialized
DEBUG - 2024-11-03 22:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 22:53:13 --> Input Class Initialized
INFO - 2024-11-03 22:53:13 --> Language Class Initialized
ERROR - 2024-11-03 22:53:13 --> 404 Page Not Found: Bootstrap/css
