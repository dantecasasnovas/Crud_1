<?php
include('script/conn.php');

$pdo = getConnexion();

if(isset($_POST['query'])) {
    $query = $_POST['query'];
    $stmt = $pdo->prepare("SELECT * FROM login_prensa WHERE tituloPrensa LIKE ?");
    $stmt->execute(array("%$query%"));
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo '<div class="d-flex rounded overflow-hidden mb-3">';
        echo '<img class="img-fluid" src="img/prensa/'.$row['imgPrensa_1'].'" style="width: 100px; height: 100px; object-fit: cover;" alt="">';
        echo '<a href="noticias.php?mas='.$row['id_prensa'].'" class="h5 fw-semi-bold d-flex align-items-center bg-light px-3 mb-0">'.$row['tituloPrensa'].'</a>';
        echo '</div>';
    }
}
?>
