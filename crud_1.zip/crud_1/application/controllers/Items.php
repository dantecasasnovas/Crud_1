<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); // Esto asegura que el script no se ejecute directamente

class Items extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Item_model'); // Carga el modelo 'Item_model'
        $this->load->helper('url'); // Carga el helper de URL para usar funciones como 'site_url' y 'base_url'
    }

    public function index()
    {
        $data['items'] = $this->Item_model->get_items(); // Obtiene todos los ítems del modelo
        $this->load->view('index', $data); // Carga la vista 'index' y le pasa los datos de los ítems
    }

    public function create()
    {
        $this->load->view('items/create'); // Carga la vista 'create' para crear un nuevo ítem
    }

    public function store()
    {
        // Recoge los datos del formulario a través de POST
        $data = array(
            'name' => $this->input->post('name'), 
            'apellido' => $this->input->post('apellido'),
            'cedula' => $this->input->post('cedula'),
            'direccion' => $this->input->post('direccion')
        );
        $this->Item_model->insert_item($data); // Inserta el nuevo ítem en la base de datos
        redirect('items'); // Redirige de vuelta al índice de ítems
    }

    public function edit($id)
    {
        $data['items'] = $this->Item_model->get_items(); // Obtiene todos los ítems (si es necesario en la vista)
        $data['item'] = $this->Item_model->get_item($id); // Obtiene el ítem específico a editar
        if(empty($data['item'])) {
            show_404(); // Muestra un error 404 si no se encuentra el ítem
        }
        $this->load->view('items/edit', $data); // Carga la vista 'edit' con los datos del ítem
    }

    public function update($id)
    {
        // Recoge los datos del formulario a través de POST
        $data = array(
            'name' => $this->input->post('name'),
            'apellido' => $this->input->post('apellido'),
            'cedula' => $this->input->post('cedula'),
            'direccion' => $this->input->post('direccion')
        );
        $this->Item_model->update_item($id, $data); // Actualiza el ítem en la base de datos
        redirect('items'); // Redirige de vuelta al índice de ítems
    }

    public function delete($id)
    {
        $this->Item_model->delete_item($id); // Elimina el ítem de la base de datos
        redirect('items'); // Redirige de vuelta al índice de ítems
    }
}
?>
